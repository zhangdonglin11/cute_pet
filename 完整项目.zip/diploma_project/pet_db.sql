/*
 Navicat Premium Data Transfer

 Source Server         : mySQL
 Source Server Type    : MySQL
 Source Server Version : 80035
 Source Host           : localhost:3306
 Source Schema         : pet_db

 Target Server Type    : MySQL
 Target Server Version : 80035
 File Encoding         : 65001

 Date: 18/04/2024 23:14:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '聊天主表id',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `another_id` int NULL DEFAULT NULL COMMENT '目标id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat
-- ----------------------------
INSERT INTO `chat` VALUES (8, 31, 1);

-- ----------------------------
-- Table structure for chat_comment
-- ----------------------------
DROP TABLE IF EXISTS `chat_comment`;
CREATE TABLE `chat_comment`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '聊天内容id',
  `chat_id` int NULL DEFAULT NULL COMMENT '主表聊天id',
  `user_id` int NULL DEFAULT NULL COMMENT '消息所有者id',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '聊天内容',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '发送时间',
  `type` int NULL DEFAULT NULL COMMENT '消息类型 0文字 1图片 2宠物',
  `is_latest` int NULL DEFAULT NULL COMMENT '是不是最后一条消息（默认1）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 83 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat_comment
-- ----------------------------
INSERT INTO `chat_comment` VALUES (78, 8, 31, 'Hi~', '2024-04-17 14:55:15', 0, 0);
INSERT INTO `chat_comment` VALUES (79, 8, 1, '你好呀，很高兴认识你！', '2024-04-17 14:55:15', 0, 0);
INSERT INTO `chat_comment` VALUES (80, 8, 1, '{\"pic\":[\"http://localhost:8088/image/20240310e0f275ae-c001-4635-b3df-633e79215ea4.jpg\",\"http://localhost:8088/image/20240310b3c5f2b4-5518-4edf-a743-b3ec0d379d8f.png\"],\"petLike\":{\"isLike\":true,\"count\":2},\"pet\":{\"id\":43,\"petType\":2,\"petVariety\":\"日本柴犬\",\"petNick\":\"小八嘎\",\"petSex\":\"弟弟\",\"petAge\":\"1-3岁\",\"petAddress\":\"广东省·广州市·荔湾区\",\"petStatus\":\"找朋友\",\"experience\":null,\"petOwner\":\"嘿嘿嘿！交个朋友。\",\"userId\":1,\"status\":1,\"createTime\":\"2024-03-10T15:37:33.000+00:00\"}}', '2024-04-17 14:55:25', 2, 0);
INSERT INTO `chat_comment` VALUES (81, 8, 1, '123', '2024-04-17 14:55:30', 0, 0);
INSERT INTO `chat_comment` VALUES (82, 8, 1, 'http://localhost:8088/image/20240417665d064a-825f-4f4b-a846-6bae4d82dd9d.png', '2024-04-17 14:55:35', 1, 0);

-- ----------------------------
-- Table structure for chat_list
-- ----------------------------
DROP TABLE IF EXISTS `chat_list`;
CREATE TABLE `chat_list`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '聊天列表表id',
  `chat_id` int NULL DEFAULT NULL COMMENT '聊天主表id',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `another_id` int NULL DEFAULT NULL COMMENT '对方用户id',
  `unread` int NULL DEFAULT NULL COMMENT '未读数',
  `status` int NULL DEFAULT NULL COMMENT '正常0，删除1，拉黑2，举报3，举报加拉黑4',
  `is_online` int NULL DEFAULT NULL COMMENT '是否显示在用户对话列表\r\n',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of chat_list
-- ----------------------------
INSERT INTO `chat_list` VALUES (9, 8, 31, 1, 8, 0, 1);
INSERT INTO `chat_list` VALUES (10, 8, 1, 31, 0, 0, 1);

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '评论表主键id',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '评论内容',
  `topic_id` int NULL DEFAULT NULL COMMENT '话题id',
  `pet_id` int NULL DEFAULT NULL COMMENT '宠物id',
  `user_id` int NULL DEFAULT NULL COMMENT '发表评论的用户id',
  `level` int NULL DEFAULT NULL COMMENT '评论层级，分三层，0为针对博文的评论，1为针对0的评论，2为针对1的评论，',
  `parent_id` int NULL DEFAULT NULL COMMENT '回复的评论id，没有为null',
  `root_id` int NULL DEFAULT NULL COMMENT '根评论id，没有为null，根评论的作用是为了方便归类',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '评论创建时间',
  `status` int NULL DEFAULT NULL COMMENT '0正常，2审核屏蔽',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 87 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (73, '觉得合适的朋友可以联系我', NULL, 44, 1, 0, NULL, NULL, '2024-03-11 15:48:58', 2);
INSERT INTO `comment` VALUES (76, '小狗好可爱，我是大学生，可以给我一只小狗吗', 12, NULL, 1, 0, NULL, NULL, '2024-03-12 17:26:37', 0);
INSERT INTO `comment` VALUES (77, '好呀', NULL, 44, 31, 1, 1, 73, '2024-03-13 19:30:31', 0);
INSERT INTO `comment` VALUES (78, '好好看呀', NULL, 47, 32, 0, NULL, NULL, '2024-03-14 19:36:31', 0);
INSERT INTO `comment` VALUES (79, '太萌了，赶紧给小狗喂吃的。', 12, NULL, 32, 0, NULL, NULL, '2024-03-14 19:36:33', 0);
INSERT INTO `comment` VALUES (80, '我也要', 12, NULL, 32, 1, 1, 76, '2024-03-14 00:01:47', 0);
INSERT INTO `comment` VALUES (81, '有点意思', 11, NULL, 1, 0, NULL, NULL, '2024-03-14 19:38:30', NULL);
INSERT INTO `comment` VALUES (82, '有点调皮的样子', NULL, 43, 1, 0, NULL, NULL, '2024-03-14 19:39:18', NULL);
INSERT INTO `comment` VALUES (83, '梦中情狗', NULL, 47, 1, 0, NULL, NULL, '2024-03-14 19:40:59', NULL);
INSERT INTO `comment` VALUES (84, '哈哈哈，有点憨憨的', NULL, 41, 1, 0, NULL, NULL, '2024-03-15 18:31:20', NULL);
INSERT INTO `comment` VALUES (85, '好狗狗。哈哈哈哈', 11, NULL, 31, 0, NULL, NULL, '2024-04-14 16:01:34', NULL);
INSERT INTO `comment` VALUES (86, '123', NULL, 41, 1, 0, NULL, NULL, '2024-04-17 13:46:24', NULL);

-- ----------------------------
-- Table structure for pet
-- ----------------------------
DROP TABLE IF EXISTS `pet`;
CREATE TABLE `pet`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `pet_type` int NULL DEFAULT NULL COMMENT '宠物类别 1猫,2狗',
  `pet_variety` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物品种',
  `pet_nick` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物昵称',
  `pet_sex` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物性别 弟弟 妹妹',
  `pet_age` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物年龄',
  `pet_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物地址',
  `pet_status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物状态',
  `experience` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '配种宠物经验',
  `pet_owner` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '铲屎官的话',
  `user_id` int NULL DEFAULT NULL COMMENT '宠物主人',
  `status` int NULL DEFAULT NULL COMMENT '显示状态 0 草稿 1·2显示 3审核',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 55 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pet
-- ----------------------------
INSERT INTO `pet` VALUES (41, 2, '哈士奇', '闪电哈', '弟弟', '一岁以内', '广东省·广州市·荔湾区', '找朋友', NULL, '在家好无聊，买了只二哈，感觉好傻。', 1, 1, '2024-02-01 00:10:13');
INSERT INTO `pet` VALUES (43, 2, '日本柴犬', '小八嘎', '弟弟', '1-3岁', '广东省·广州市·荔湾区', '找朋友', NULL, '嘿嘿嘿！交个朋友。', 1, 1, '2024-03-10 23:37:33');
INSERT INTO `pet` VALUES (44, 1, '布偶猫', '咪咪', '妹妹', '1-3岁', '上海·上海市·黄浦区', '找对象', '无经验', '我家咪咪太可爱了，找同类的猫猫把基因发扬光大。。', 1, 1, '2024-03-11 14:24:42');
INSERT INTO `pet` VALUES (47, 2, '萨摩耶', '沫沫', '妹妹', '1-3岁', '广东省·广州市·越秀区', '找代溜', NULL, '最近工作繁忙，找个附近朋友帮忙溜溜狗子。', 31, 1, '2024-03-13 00:18:25');
INSERT INTO `pet` VALUES (48, 1, '英国短毛猫', '虾球', '妹妹', '1-3岁', '天津·天津市·和平区', '找代溜', NULL, '最近上班忙，找个朋友代代猫咪去玩', 31, 1, '2024-03-13 17:29:59');
INSERT INTO `pet` VALUES (51, 1, '中华田园猫', '三只小猫', '弟弟', '一岁以内', '重庆·重庆市·万州区', '找领养', NULL, '家里养不了三只小猫咪，找户好人家领养。', 31, 1, '2024-04-17 12:22:09');
INSERT INTO `pet` VALUES (54, 2, '柯基犬', '半拉柯基', '弟弟', '一岁以内', '北京·北京市·东城区', '找朋友', NULL, NULL, 1, 1, '2024-04-17 14:52:41');

-- ----------------------------
-- Table structure for phone_code
-- ----------------------------
DROP TABLE IF EXISTS `phone_code`;
CREATE TABLE `phone_code`  (
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '手机号',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '验证码',
  PRIMARY KEY (`phone`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of phone_code
-- ----------------------------

-- ----------------------------
-- Table structure for picture
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `topic_id` int NULL DEFAULT NULL COMMENT '话题id',
  `pet_id` int NULL DEFAULT NULL COMMENT '宠物的id',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `pic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宠物照片？？？',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 184 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES (120, 1, NULL, 1, 'http://localhost:8088/image/20240122619385e8-e542-439d-8eaa-23b6a008a518.jpg');
INSERT INTO `picture` VALUES (121, 1, NULL, 1, 'http://localhost:8088/image/20240122480884e9-f5b2-4315-a682-aad9f7ac5f2f.jpg');
INSERT INTO `picture` VALUES (147, NULL, 41, 1, 'http://localhost:8088/image/202403102464d2fe-6af5-48d6-8ca6-b57e3ffa1d8a.png');
INSERT INTO `picture` VALUES (148, NULL, 41, 1, 'http://localhost:8088/image/20240310f0909ca8-f994-44a2-9bca-f776dbe913a3.jfif');
INSERT INTO `picture` VALUES (149, NULL, 43, 1, 'http://localhost:8088/image/20240310e0f275ae-c001-4635-b3df-633e79215ea4.jpg');
INSERT INTO `picture` VALUES (150, NULL, 43, 1, 'http://localhost:8088/image/20240310b3c5f2b4-5518-4edf-a743-b3ec0d379d8f.png');
INSERT INTO `picture` VALUES (151, NULL, 44, 1, 'http://localhost:8088/image/20240311e06dffc3-ef97-49df-a00d-404d40208930.png');
INSERT INTO `picture` VALUES (152, 9, NULL, 1, 'http://localhost:8088/image/20240311fc4dc59a-c35d-4da1-87b6-847820c0fe08.png');
INSERT INTO `picture` VALUES (153, 10, NULL, 1, 'http://localhost:8088/image/202403114f2288bb-0aa9-4505-8a74-f13f45c4f09e.png');
INSERT INTO `picture` VALUES (154, 11, NULL, 1, 'http://localhost:8088/image/202403115f7599e4-929a-475a-bd17-725945a61a69.jpg');
INSERT INTO `picture` VALUES (155, 12, NULL, 31, 'http://localhost:8088/image/20240312be61760e-4f14-4bfe-9e46-9190fa60a9a0.jpg');
INSERT INTO `picture` VALUES (156, 12, NULL, 31, 'http://localhost:8088/image/20240312e7fab0a0-c8d5-48fd-9090-8bd1d05f5eff.jpg');
INSERT INTO `picture` VALUES (160, NULL, 47, 31, 'http://localhost:8088/image/20240313a5486562-cd4d-42f7-adbb-39d800fad8e1.png');
INSERT INTO `picture` VALUES (161, NULL, 47, 31, 'http://localhost:8088/image/20240313f208436d-cfbc-44ef-adc8-baf90cc65995.png');
INSERT INTO `picture` VALUES (162, NULL, 47, 31, 'http://localhost:8088/image/202403137924bcbc-5708-4b1f-97e0-ec4894762bbb.png');
INSERT INTO `picture` VALUES (165, 14, NULL, 1, 'http://localhost:8088/image/2024031573503bd2-126c-4fd3-994b-49e96c97a6fe.png');
INSERT INTO `picture` VALUES (166, NULL, 48, 31, 'http://localhost:8088/image/2024041790f2893b-8c68-4ea4-bc71-8ea2e1d08ec7.png');
INSERT INTO `picture` VALUES (167, NULL, 51, 31, 'http://localhost:8088/image/2024041794b6094c-971a-4628-bc0f-8efa1e470b15.png');
INSERT INTO `picture` VALUES (182, NULL, 54, 1, 'http://localhost:8088/image/202404178a19b658-b3a8-44f8-ab74-ca4abcd7713b.webp');
INSERT INTO `picture` VALUES (183, NULL, 54, 1, 'http://localhost:8088/image/20240417198f52b0-9ab8-48b5-8f22-f6403f114907.png');

-- ----------------------------
-- Table structure for thumb
-- ----------------------------
DROP TABLE IF EXISTS `thumb`;
CREATE TABLE `thumb`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '收藏表id',
  `topic_id` int NULL DEFAULT NULL COMMENT '话题id',
  `pet_id` int NULL DEFAULT NULL COMMENT '宠物id',
  `user_id` int NULL DEFAULT NULL COMMENT '用户id',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 93 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of thumb
-- ----------------------------
INSERT INTO `thumb` VALUES (15, NULL, 35, 1, '2024-02-07 23:13:53');
INSERT INTO `thumb` VALUES (68, 11, NULL, 31, '2024-03-11 23:14:19');
INSERT INTO `thumb` VALUES (69, 12, NULL, 31, '2024-03-12 16:12:25');
INSERT INTO `thumb` VALUES (75, NULL, 41, 32, '2024-03-13 23:47:36');
INSERT INTO `thumb` VALUES (76, NULL, 43, 32, '2024-03-13 23:47:37');
INSERT INTO `thumb` VALUES (77, NULL, 44, 32, '2024-03-13 23:47:39');
INSERT INTO `thumb` VALUES (78, NULL, 47, 32, '2024-03-13 23:47:41');
INSERT INTO `thumb` VALUES (79, 12, NULL, 32, '2024-03-13 23:48:52');
INSERT INTO `thumb` VALUES (80, 10, NULL, 1, '2024-03-14 19:38:37');
INSERT INTO `thumb` VALUES (81, NULL, 43, 1, '2024-03-14 19:40:25');
INSERT INTO `thumb` VALUES (86, NULL, 44, 31, '2024-04-14 15:57:13');

-- ----------------------------
-- Table structure for topic
-- ----------------------------
DROP TABLE IF EXISTS `topic`;
CREATE TABLE `topic`  (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '话题id',
  `user_id` int NULL DEFAULT NULL COMMENT '话题用户id',
  `title` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '话题内容',
  `classify` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '话题类型',
  `allow` int NULL DEFAULT NULL COMMENT '是否允许评论 0,1',
  `viewed` int NULL DEFAULT NULL COMMENT '浏览次数',
  `status` int NULL DEFAULT NULL COMMENT '状态 0 1 3',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of topic
-- ----------------------------
INSERT INTO `topic` VALUES (9, 1, '猫咪饮食', '不要给猫瞎吃东西，有的人可以食用，猫不行，比如巧克力，洋葱，严重了会致命。猫禁食高盐份，猫对盐没有需求，过量会导致肾负担，引起肾脏和泌尿系统问题。火腿肠不要喂，除了高盐，还有防腐剂。葡萄，葡萄干，鸡骨头，这些都不能让猫接触。管状骨骼会扎伤猫的肠胃。打个广告。', '养宠经验', 1, 2, 3, '2024-03-14 19:23:24');
INSERT INTO `topic` VALUES (10, 1, '想养狗狗来看看', '家里养过5只狗，看到挺多人想养狗却无从下手，分享一下自己的经验和想法吧，如果有不对的，大家也可以指正补充。\n1.提前准备狗粮，狗笼，尿垫，食碗，水碗等，幼犬肠胃很脆弱，家中要常备益生菌或肠胃宝。\n2.按时打疫苗，按时驱虫（体内外都要做）。\n3.训练：。。。。。', '养宠经验', 1, 8, 1, '2024-03-11 17:35:49');
INSERT INTO `topic` VALUES (11, 1, '快来看看呀', '在公园看到一只柴犬好猥琐呀。', '日常', 1, 6, 1, '2024-03-11 17:27:47');
INSERT INTO `topic` VALUES (12, 31, '小狗们在看什么呢？', '哇~~！原来是看爷爷吃饭耶。', '日常', 1, 33, 1, '2024-03-11 23:56:25');
INSERT INTO `topic` VALUES (13, 31, NULL, NULL, NULL, 1, 0, 0, '2024-03-12 00:37:23');
INSERT INTO `topic` VALUES (14, 1, '看把狗子吓的', '', '日常', 1, 0, 3, '2024-03-15 17:36:07');
INSERT INTO `topic` VALUES (15, 1, NULL, NULL, NULL, 1, 0, 0, '2024-04-17 12:32:48');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户昵称',
  `pic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像图片地址',
  `sex` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '性别',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户手机号（登录账号）',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户密码',
  `role` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户角色(ADMIN:管理员，USER:普通用户)',
  `status` int NULL DEFAULT NULL COMMENT '用户状态（0：正常，2：审核，3：禁用）',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '渐行渐远', 'http://localhost:8088/image/20240417bd2c34f5-6fe2-4f95-98f5-d9f133abfe4c.png', '男', '13169197359', 'a123456', 'USER', 0, '2024-04-17 14:58:35');
INSERT INTO `user` VALUES (31, '天真可爱', 'http://localhost:8088/image/20240312fe2626e9-7c3a-4288-9cdb-f3cac6c1aff2.jpeg', '女', '15360785076', 'a123456', 'USER', 0, '2024-04-17 13:49:29');
INSERT INTO `user` VALUES (32, '铲屎官5346', 'http://localhost:8088/image/20240313798a3594-b79c-48c0-aa51-dd0d96f3bc60.jpg', '男', '13112345671', 'a123456', 'USER', 0, '2024-03-14 00:47:52');
INSERT INTO `user` VALUES (33, '铲屎官9474', 'http://localhost:8088/image/202403134b3986ab-4150-4072-9822-35dcb187f439.png', '女', '13112345672', 'a123456', 'USER', 1, '2024-03-13 22:12:56');
INSERT INTO `user` VALUES (34, '铲屎官2963', 'http://localhost:8088/image/20240313b9e57143-4cdc-4c08-a5bd-d5b9693d3218.png', '男', '13112345673', 'a123456', 'USER', 0, '2024-03-13 22:09:52');
INSERT INTO `user` VALUES (35, '铲屎官7131', 'http://localhost:8088/image/20240313219b5383-01c0-4337-8b14-bb2e4fed1ded.png', '女', '13112345674', 'a123456', 'USER', 1, '2024-03-13 22:12:53');
INSERT INTO `user` VALUES (36, '铲屎官9182', 'http://localhost:8088/image/20240313511c8990-848d-4052-8872-d879cc5e04ca.png', '男', '13112345675', 'a123456', 'USER', 0, '2024-03-13 22:10:14');
INSERT INTO `user` VALUES (37, '铲屎官6507', 'http://localhost:8088/image/20240313826672e7-22d3-4880-b93b-7bc88bc40ed6.png', '女', '13112345676', 'a123456', 'USER', 1, '2024-03-13 22:10:47');
INSERT INTO `user` VALUES (38, '铲屎官9791', 'http://localhost:8088/image/20240313c39727e6-7aca-41e5-902f-d0115828ef13.png', '男', '13112345677', 'a123456', 'USER', 2, '2024-03-13 22:10:51');

SET FOREIGN_KEY_CHECKS = 1;
