//引入 axios
import axios from "axios";

import config from '../config/index'
import { ElMessage } from 'element-plus';
// import router from '@/router/index';

const NETWORK_ERROR = '网络请求异常，请稍后重试'
const http = axios.create({
  baseURL: config.baseApi,
  headers: {
    'token': 'token'||'' // 设置自定义的请求头信息
  }
})

// 数据请求拦截
http.interceptors.request.use((req) => {
  return req;
}, (req) => {
  return Promise.reject(req);
});

// 返回响应数据拦截
http.interceptors.response.use((res) => {
  const data = res.data;
  // 状态码为 2xx 范围时都会调用该函数，处理响应数据
  if (res.status === 200) {
    // const code = data.code;
    return data
  }
},
  (error) => {
    if (error.response.status) {
      // 状态码超过 2xx 范围时都会调用该函数，处理错误响应
      switch (error.response.status) {
        case 400:
          ElMessage({
            message: "发出的请求有错误，服务器没有进行新建或修改数据的操作==>" + error.response.status,
            type: "error"
          })
          break;

        // 401: 未登录
        // 未登录则跳转登录页面，并携带当前页面的路径
        // 在登录成功后返回当前页面，这一步需要在登录页操作。                
        case 401: //重定向
          ElMessage({
            message: "token:登录失效==>" + error.response.status + ":",
            type: "error"
          })
          router.replace({
            path: '/Login',
          });
          break;
        // 403 token过期
        // 登录过期对用户进行提示
        // 清除本地token和清空vuex中token对象
        // 跳转登录页面                
        case 403:
          ElMessage({
            message: "用户得到授权，但是访问是被禁止的==>" + error.response.status,
            type: "error"
          })
          break;
        case 404:
          ElMessage({
            message: "网络请求不存在==>" + error.response.status,
            type: "error"
          })
          break;
        case 500:
          ElMessage({
            message: "服务器发生错误，请检查服务器==>" + error.response.status,
            type: "error"
          })
          break;
        default:
          ElMessage({
            message: "其他错误错误==>" + error.response.status,
            type: "error"
          })
      }
    }
    return Promise.reject(error);
  }
);
//这是一位大佬指点的方法，更加简单

export default http;

// 请求方法
// 导入当前文件
// request({
//   method: 'get',
//   data: {
//     name:1
//   },
//   isMock:true  // 可选
// })
