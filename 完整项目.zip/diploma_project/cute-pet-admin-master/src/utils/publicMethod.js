export const getTimer = (ot) => {
  let newtime = new Date();
  let oldtime = new Date(ot);
  let diff = newtime.getTime() - oldtime.getTime();
  let diffInMinutes = diff / (1000 * 60); // 将毫秒转换为分钟
  let diffInHour = diff / (1000 * 60 * 60);
  let diffInDay = diff / (1000 * 60 * 60 * 24);
  if (diffInMinutes.toFixed(2) < 60) {
    return Math.floor(diffInMinutes) + '分钟前';
  } else if (diffInHour < 24) {
    return Math.floor(diffInHour) + '小时前';
  } else {
    return Math.floor(diffInDay) + '天前';
  }
}