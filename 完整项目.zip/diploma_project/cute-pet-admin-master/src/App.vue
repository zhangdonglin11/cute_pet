<template>
  <router-view />
</template>

<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

* {
  margin: 0;
  padding: 0;
}

.flx-center {
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 滚动条所在容器 */
.scroll-container {


  /* 滚动条整体 */
  &::-webkit-scrollbar {
    width: 2px;
    height: 2px;
  }

  /* 两个滚动条交接处 -- x轴和y轴 */
  &::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  /* 滚动条滑块 */
  &::-webkit-scrollbar-thumb {
    background-color: #a3a7af;
    border-radius: 1px;
  }

  /* 滚动条轨道 */
  &::-webkit-scrollbar-track {}

  /* 滚动条两端按钮 */
  .scroll-container::-webkit-scrollbar-button {
    display: none;
  }
}
</style>
