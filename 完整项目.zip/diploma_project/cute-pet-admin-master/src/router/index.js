import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'layout',
      component: () => import('../layout/LayoutView.vue'),
      redirect: "/index",
      children: [
        { path: '/index', component: () => import("@/views/index/IndexView.vue") },
        { path: '/user', component: () => import("@/views/user/UserView.vue") },
        { path: '/pet', component: () => import("@/views/pet/PetListView.vue") },
        { path: '/topic', component: () => import("@/views/topic/TopicView.vue") },
        { path: '/comment', component: () => import("@/views/comment/CommentView.vue") },
        { path: '/dialogue', component: () => import("@/views/dialogue/DialogueView.vue") },
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../views/login/LoginView.vue')
    }
  ]
})

export default router
