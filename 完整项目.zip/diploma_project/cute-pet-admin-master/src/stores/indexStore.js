import { ref, computed } from 'vue'
//定义的文件单独使用，不和index.js产生任何关系。
//定义属于counter的store
import { defineStore } from "pinia";//表示要定义store
//通过defineStore定义store,内部会自动管理store
export const useIndexStore = defineStore('index', () => {
  const currentMenu = ref(0)
  const current = computed(() => {
    return currentMenu.value
  })
  const selectMenu = (val) => {
    val.name == 'index' ? currentMenu.value = null : currentMenu.value = val
  }

  const pieData = ref([
    { value: 1, name: "宠物活跃度" },
    { value: 1, name: "话题活跃度" }
  ])
  const setPieData = (val) => {
    pieData.value = val
  }

  const isCollapse = ref(false)
  const setIsCollapse = () => {
    isCollapse.value = !isCollapse.value
  }


  return {
    currentMenu,
    current,
    selectMenu,

    pieData,
    setPieData,

    isCollapse,
    setIsCollapse,

  }
}
)
