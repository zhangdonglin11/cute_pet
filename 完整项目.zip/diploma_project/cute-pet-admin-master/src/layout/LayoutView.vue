<!-- 纵向布局 -->
<template>
  <el-container class="layout">
    <el-aside>
      <div class="aside-box" :style="{ width: isCollapse ? '65px' : '210px' }">
        <div class="logo flx-center">
          <img class="logo-img" src="../assets/logo.svg" alt="logo" />
          <span v-show="!isCollapse" class="logo-text">宠物萌后台管理</span>
        </div>
        <el-scrollbar>
          <el-menu :collapse="isCollapse">
            <!-- 遍历菜单按钮 -->
            <template v-for="item1 in MenuList" :key="item1.label">
              <!-- 没有子选项 -->
              <el-menu-item @click="clickMenu(item1)" v-if="!item1?.children" :index="item1.label">
                <component class="icon" :is="item1.icon"></component>
                <span>{{ item1.label }}</span>
              </el-menu-item>
              <!-- 有子选项 -->
              <el-sub-menu v-else :index="item1.label">
                <template #title>
                  <component class="icon" :is="item1.icon"></component>
                  <span>{{ item1.label }}</span>
                </template>
                <el-menu-item-group>
                  <!-- 遍历子选项 -->
                  <el-menu-item @click="clickMenu(item2)" v-for="item2 in item1.children" :key="item2.label"
                    :index="item2.label">
                    <component class="icon" :is="item1.icon"></component>
                    <span>{{ item2.label }}</span>
                  </el-menu-item>
                </el-menu-item-group>
              </el-sub-menu>
            </template>
          </el-menu>
        </el-scrollbar>
      </div>
    </el-aside>

    <el-container class="layout-right-box">
      <el-header>
        <!-- 左 -->
        <div class="tool-bar-left flx-center">
          <!-- 菜单状态控制 -->
          <component @click="setMenuState()" class="collapse-icon" :is="isCollapse ? 'expand' : 'fold'">
          </component>
          <!-- 面包屑 -->
          <el-breadcrumb :separator-icon="ArrowRight">
            <el-breadcrumb-item :to="{ path: '/' }"
              @click="indexStore.selectMenu({ name: 'index' })">首页</el-breadcrumb-item>
            <el-breadcrumb-item v-if="indexStore.current" :to="indexStore.current?.path">{{ indexStore.current.label }}
            </el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <!-- 右 -->
        <div class="tool-bar-right flx-center">
          <span>admin</span>
          <img src="../assets/admin.png" alt="" style="width: 40px;height: 40px;border-radius: 20px;margin: 0 20px;">
          <a href="/login" style="font-size: 12px;margin: 0 20px 0 0;">退出登录</a>
        </div>
      </el-header>
      <!-- tags -->

      <!-- main -->
      <el-main class="scroll-container">
        <router-view></router-view>
      </el-main>
      <!-- footer -->
      <el-footer class="flx-center">Footer</el-footer>
    </el-container>
  </el-container>
</template>

<script setup name="layoutClassic">
import { ArrowRight } from '@element-plus/icons-vue'
import { computed, ref } from "vue";
import { useRouter } from 'vue-router';
import { useIndexStore } from '@/stores/indexStore.js'


const router = useRouter()
// 菜单导航数据
const MenuList = ref([{
  path: '/',
  name: 'index',
  label: '首页',
  icon: 'HomeFilled',
}, {
  path: '/user',
  name: 'user',
  label: '用户管理',
  icon: 'UserFilled',
}, {
  path: '/pet',
  name: 'pet',
  label: '宠物管理',
  icon: 'PictureFilled',
}, {
  path: '/topic',
  name: 'topic',
  label: '话题管理',
  icon: 'Share',
},
{
  path: '/comment',
  name: 'comment',
  label: '评论管理',
  icon: 'Comment',
},
{
  path: '/dialogue',
  name: 'dialogue',
  label: '对话管理',
  icon: 'InfoFilled',
},//  {label: '宠物管理',icon: 'user',children: [{path: '/pet1',name: 'user',label: '宠物列表',icon: 'user', url: 'user/UserView'}]}
])
const clickMenu = (item) => {
  router.push(item.path)
  indexStore.selectMenu(item)
}

const indexStore = useIndexStore()
const isCollapse = ref()
isCollapse.value = indexStore.isCollapse
const setMenuState = () => {
  indexStore.setIsCollapse()
  isCollapse.value = indexStore.isCollapse

}

</script>

<style scoped lang="scss">
.el-container {
  display: flex;
  width: 100%;
  height: 100%;
  background-color: #eff0f2;

  :deep(.el-aside) {
    height: 100vh;
    width: auto;
    background-color: #ffffff;
    border-right: 1px solid #e4e7ed;

    .aside-box {
      display: flex;
      flex-direction: column;
      height: 100%;
      transition: width 0.3s ease;

      .el-scrollbar {
        height: calc(100% - 55px);

        .el-menu {
          width: 100%;
          overflow-x: hidden;
          border-right: none;
        }

        // 菜单选中颜色

      }

      .logo {
        box-sizing: border-box;
        height: 55px;

        .logo-img {
          width: 28px;
          object-fit: contain;
          margin-right: 6px;
        }

        .logo-text {
          font-size: 21.5px;
          font-weight: bold;
          color: #303133;
          white-space: nowrap;
        }
      }
    }
  }

  .layout-right-box {
    flex: 1;
    display: flex;
    height: 100vh;
    flex-direction: column;
    box-sizing: border-box;
  }

  .el-header {
    top: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 55px;
    padding: 0 15px;
    background-color: #ffffff;
    border-bottom: 1px solid #e4e7ed;
    box-sizing: border-box;

    .tool-bar-left {
      overflow: hidden;
      white-space: nowrap;
      cursor: pointer;

      .collapse-icon {
        width: 22px;
        height: 22px;
        margin-right: 20px;
        font-size: 22px;
      }
    }

    .tool-bar-right {
      .el-avatar {
        margin: 0 20px;
      }
    }
  }

  .tags-box {
    display: flex;
    align-items: center;
    width: 100%;
    height: 40px;
    box-sizing: border-box;
    background-color: #ffffff;
    border-bottom: 1px solid #e4e7ed;

    .el-tag {
      margin-left: 20px;
    }
  }

  .el-main {
    flex: 1;
    padding: 10px 12px;
    text-align: left;
    overflow: auto;

    div {
      background-color: #ffffff
    }
  }

  .el-footer {
    bottom: 0;
    height: 30px;
    width: 100%;
    background-color: #ffffff;
    border-top: 1px solid #e4e7ed;
  }
}


// 菜单样式
.el-menu-item {
  &:hover {
    color: #333333;
    background: #cccccc;
  }

  &.is-active {
    position: relative;
    color: #009688 !important;
    background-color: #e6f5f3 !important;

    &::before {
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      content: "";
      background-color: #009688;
    }
  }
}

// 自定义图标大小
.icon {
  width: 20px;
  height: 20px;
  margin-right: 8px;
}
</style>
