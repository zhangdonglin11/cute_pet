/**
 * 配置开发环境
 * 开发环境
 * 测试环境
 * 线上环境
 */
// 当前环境
const env = 'development'

const EnvConfig = {
  development:{
    baseApi:'http://localhost:8088/api',
  },
  test:{
    baseApi:'//test.com/api',

  },
  pro:{
    baseApi:'//none.com.api',

  }
}

export default{
  env,
 ...EnvConfig[env]
}