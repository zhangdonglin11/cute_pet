import './assets/main.css'

import { createApp } from 'vue'

import App from './App.vue'
import router from './router'

// pinia + 持久化
import { createPinia } from 'pinia'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate' //引入持久化插件
const pinia = createPinia()
pinia.use(piniaPluginPersistedstate) //将插件添加到 pinia 实例上

const app = createApp(App)

// el icon
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component);
}

app.use(router)
app.use(pinia)
app.mount('#app')
