import http from '../utils/http';
// 获取宠物列表
export const getPetList = (condition) => {
  return http.post('/admin/audit-pet', condition)
}

// 宠物审核
export const auditPet = (pid, type) => {
  return http.post('/admin/audit-pet/pet', {
    pid, type
  })
}
