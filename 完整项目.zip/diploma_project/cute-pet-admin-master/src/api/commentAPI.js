import http from '../utils/http';
// 获取评论列表
export const getComment = (condition) => {
  return http.post('/admin/audit-comment', condition)
}

// 对话审核
export const auditComment = (cid, type) => {
  return http.post('/admin/audit-comment/update', {
    cid, type
  })
}