import http from '../utils/http';
// 登录
export const loginAPI = (loginFrom) => {
  return http.post('/admin/login', loginFrom)
}
// 创建一个业务接口对象
export const getUserList = (condition) => {
  return http.post('/admin/audit-user', condition)
}
// 重置用户头像
export const resetUserImg = (id) => {
  return http.get('/admin/audit-user/remove-img', {
    params: {
      id
    }
  })
}
// 修改用户
export const updateUser = (fromData) => {
  return http.post('/admin/audit-user/upload', fromData)
}
// 删除用户
export const delUserById = (id) => {
  return http.get('/admin/audit-user/del', {
    params: {
      id
    }
  })
}
// 添加用户
export const saveUser = (fromData) => {
  return http.post('/admin/audit-user/add', fromData)
}
// 评论审核
export const auditComment = (cid, type) => {
  return http.post('/admin/audit-pet/comment', {
    cid, type
  })
}
// 修改用户状态
export const forbidUser = (uid) => {
  return http.post('/admin/audit-pet/user', {
    uid
  })
}