<template>
  <div class="login-container flx-center">
    <div class="login-box">
      <div class="login-left">
        <img class="login-left-img" src="../../assets/猫狗背景.png" alt="login" />
      </div>
      <div class="login-form">
        <div class="login-logo">
          <img class="login-icon" style="" src="../../assets/logo.svg" alt="" />
          <h2 class="logo-text">宠物萌后台管理</h2>
        </div>
        <LoginForm />
      </div>
    </div>
  </div>
</template>

<script setup name="login">
import LoginForm from "./components/LoginForm.vue";
</script>

<style scoped lang="scss">
@import './index.scss';
</style>
