<script setup>
import { Delete, Check, UserFilled } from '@element-plus/icons-vue'
import { ref } from 'vue'
import { auditDialogue } from '@/api/dialogueAPI';
const prop = defineProps({
  chatList: Object
})
const emit = defineEmits(['childEventTopic', 'childEventDialog']);

const tapAuditDialogue = async (chatListId, type) => {
  const result = await auditDialogue(chatListId, type)
  if (result.code == 1) {
    emit('childEventTopic')
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

</script>

<template>
  <div class="d-box">
    <span @click="emit('childEventDialog')" class="user" style="cursor: pointer;">
      <el-avatar :size="40" :src="prop.chatList.userPic" />
      <span>{{ prop.chatList.userName }}</span>
    </span>
    <span @click="emit('childEventDialog')" v-if="prop.chatList.status >= 3"
      style="padding: 5px 10px;background-color: #f56c6c;color: #fff; border-radius: 4px;cursor: pointer;">
      举报
    </span>
    <span @click="emit('childEventDialog')" class="user" style="cursor: pointer;">
      <el-avatar :size="40" :src="prop.chatList.anotherPic" />
      <span>{{ prop.chatList.anotherName }}</span>
    </span>

    <span>
      <el-button @click="tapAuditDialogue(prop.chatList.id, 1)" title="通过" style="margin: 0 2px;" size="small"
        type="success" :icon="Check" circle />
      <el-button @click="tapAuditDialogue(prop.chatList.id, 2)" title="删除" style="margin: 0 2px;" size="small"
        type="danger" :icon="Delete" circle />
    </span>
  </div>
</template>

<style lang="scss">
.d-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 30px;
  width: 49%;
  height: 60px;
  border: 5px;
  background-color: #f9f9f9;
  box-shadow: rgba(#000000, 0.2) 0 0 5px 0px;

  &:nth-child(2n) {
    margin-left: 2%;
  }

  &:nth-child(n+3) {
    margin-top: 2%;
  }

  .user {
    display: flex;
    align-items: center;

    span {
      margin-left: 5px;
    }
  }
}



.clearfix::after {
  content: "";
  display: table;
  clear: both;
}

.scrollbar {
  overflow-y: auto;

  /* 滚动条整体 */
  &::-webkit-scrollbar {
    width: 3px;
    height: 3px;
  }

  /* 两个滚动条交接处 -- x轴和y轴 */
  &::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  /* 滚动条滑块 */
  &::-webkit-scrollbar-thumb {
    background-color: #a3a7af;
    border-radius: 1px;
  }
}
</style>
