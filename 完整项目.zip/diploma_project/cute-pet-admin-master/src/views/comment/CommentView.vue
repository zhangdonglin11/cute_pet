<!-- 用户管理 -->

<script setup>
// ElConfigProvider 组件
import { ElConfigProvider } from 'element-plus';
// 引入中文包
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import { Search } from '@element-plus/icons-vue'
import { onMounted, ref } from 'vue'
import { getComment, auditComment } from '@/api/commentAPI'
import { forbidUser } from '@/api/userAPI.js'
import { Delete, Check, UserFilled } from '@element-plus/icons-vue'
const condition = ref({
  audit: 0, // null/audit 所有用户或者待审核用户
  current: 1, // 查询页数
  size: 9, // 查询条数
  pages: 10, //总页数
  total: 100, //总条数
})
const commentData = ref([{
  id: 1,
  nickname: "蛋蛋的忧伤",
  comment: "喀什地方教会神父开始反抗撒旦解放拉萨的",
  status: 12,
  createTime: "2024-3-14"
}])

// 处理时间 
const handleTime = (originalDateStr) => {
  const date = new Date(originalDateStr);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const formattedDateStr = `${year}-${month}-${day} ${hours}:${minutes}`;
  return formattedDateStr; // 输出 "2024-02-21-07:50"
}

const infoCommentList = async () => {
  const result = await getComment(condition.value)
  if (result.code == 1) {
    console.log(result);
    commentData.value = result.data.commentArr
    condition.value.current = result.data.current
    condition.value.pages = result.data.pages
    condition.value.total = result.data.total
  } else {
    ElMessage.error("数据请求失败！")
  }
}

const tapAuditComment = async (cid, type) => {
  const result = await auditComment(cid, type)
  if (result.code == 1) {
    infoCommentList()
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}
const tapForbidUser = async (uid) => {
  const result = await forbidUser(uid)
  if (result.code == 1) {
    infoCommentList()
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

onMounted(() => {
  infoCommentList()
})
</script>

<template>
  <div class="pet-view-box">
    <!-- 列表/待审核 -->
    <el-tabs v-model="condition.audit" @tab-change="infoCommentList()">
      <el-tab-pane label="评论列表" :name="0"></el-tab-pane>
      <el-tab-pane label="待审核" :name="1"></el-tab-pane>
    </el-tabs>
    <!-- 表格 -->
    <div class="petList-box">
      <el-table :data="commentData" style="width: 100%">
        <el-table-column label="#" type="index" width="40" />
        <el-table-column prop="userId" label="用户id" width="80" />
        <el-table-column label="头像" width="60">
          <template #default="scope">
            <el-avatar shape="square" :size="30" :src="scope.row?.pic" />
          </template>
        </el-table-column>
        <el-table-column prop="nickname" label="用户昵称" width="100" />
        <el-table-column prop="content" label="评论内容" width="500" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag v-if="scope.row.status > 0" type="warning" style="width: 60px;">待审核</el-tag>
            <el-tag v-else type="success" style="width: 60px;">正常</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="评论时间" width="140">
          <template #default="scope">
            {{ handleTime(scope.row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="280">
          <template #default="scope">
            <el-button :disabled="!scope.row.status > 0" @click="tapAuditComment(scope.row.id, 1)"
              style="margin: 0 2px;" size="small" type="success" :icon="Check">通过</el-button>
            <el-button @click="tapForbidUser(scope.row.userId)" title="" style="margin: 0 2px;" size="small"
              type="danger" :icon="UserFilled">禁用</el-button>
            <el-button @click="tapAuditComment(scope.row.id, 2)" title="删除" style="margin: 0 2px;" size="small"
              type="danger" :icon="Delete"></el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="page-box">
      <el-config-provider :locale="zhCn">
        <el-pagination v-model:current-page="condition.current" v-model:page-size="condition.size"
          layout="total, prev, pager, next, jumper" :total="condition.total" @current-change="infoCommentList()"
          background="#409eff" />
      </el-config-provider>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.pet-view-box {
  position: relative;
  height: 100%;
  padding: 20px 30px 60px;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .box-hander {

    .el-input {
      width: 400px;

      .el-input-group__append {
        padding: 0 20;

        .el-button {
          background-color: #409eff !important;
          color: #fff;
        }
      }
    }

    .btn {
      margin-left: 20px;
    }
  }

  .petList-box {
    flex: 1;
    display: flex;

  }

  .page-box {
    position: absolute;
    padding-bottom: 10px;
    bottom: 0px;
    background: #fff;
  }
}
</style>
