<script setup>
import { Delete, Check, UserFilled } from '@element-plus/icons-vue'
import { ElConfigProvider } from 'element-plus';
import { forbidUser } from '@/api/userAPI.js'
import { auditTopic } from '@/api/topicAPI'
import { getTimer } from '@/utils/publicMethod';
// ElMessage.success()
// ElMessage.error()
// import { defineProps, defineEmits } from 'vue';
const prop = defineProps({
  topic: Object
})
const emit = defineEmits(['childEventTopic']);
const tapAuditTopic = async (tid, type) => {
  const result = await auditTopic(tid, type)
  if (result.code == 1) {
    emit('childEventTopic')
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

const tapForbidUser = async (uid) => {
  const result = await forbidUser(uid)
  if (result.code == 1) {
    emit('childEventTopic')
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

</script>

<template>
  <div class="topic-card-box">
    <div v-if="prop.topic.status == 3" class="tips">待审核</div>
    <div style="height: 100%;" class="scrollbar">
      <div class="topic-box">
        <div class="left">
          <el-avatar :size="30" :src="prop.topic.userPic" />
        </div>
        <div class="right">
          <div class="header">
            <span>{{ prop.topic.userName }}</span>
            <span>
              <el-button v-if="prop.topic.status > 2" @click="tapAuditTopic(prop.topic.id, 1)" title="审核通过"
                style="margin: 0 2px;" size="small" type="success" :icon="Check" circle />
              <el-button @click="tapForbidUser(prop.topic.userId)" title="禁止用户" style="margin: 0 2px;" size="small"
                type="danger" :icon="UserFilled" circle />
              <el-button @click="tapAuditTopic(prop.topic.id, 2)" title="删除话题" style="margin: 0 2px;" size="small"
                type="danger" :icon="Delete" circle />
            </span>
          </div>
          <div class="title">{{ prop.topic.title }}</div>
          <div class="content">
            <span style="color: darkturquoise;">
              #{{ prop.topic.classify }}&nbsp;
            </span>
            {{ prop.topic.content }}
          </div>
          <div class="topic-pic">
            <el-image v-for="item in prop.topic.topicPic" :src="item" :zoom-rate="1.2" :max-scale="7" :min-scale="0.2"
              :preview-src-list="prop.topic.topicPic" :initial-index="0" fit="cover" style="width: 100px; height: 100px"
              class="timg">
              <template #error>
                <div class="image-slot"
                  style="display: flex;align-items: center;justify-content: center;width: 100%;height: 100%;">
                  宠物已删除
                </div>
              </template>
            </el-image>
            <!-- <el-image :src="item" v-for="item in prop.topic.topicPic" class="timg"></el-image> -->
          </div>
          <div class="more">
            <el-icon>
              <View />
            </el-icon>
            围观{{ prop.topic.viewed }}&nbsp;
            <el-icon>
              <Timer />
            </el-icon>
            {{ getTimer(prop.topic.createTime) }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.topic-card-box {
  position: relative;
  margin-right: 10px;
  padding: 20px 10px;
  width: 290px;
  height: 480px;
  background-color: #fff;
  box-shadow: rgba($color: #000000, $alpha: 0.1) 0 0 2px 2px;
  border-radius: 5px;
  box-sizing: border-box;
  background: #fff;
  overflow: hidden;


  .tips {
    position: absolute;
    top: 6px;
    right: 0px;
    transform: translate(20px, 0) rotateZ(45deg);
    width: 60px;
    height: 20px;
    line-height: 25px;
    background-color: red;
    z-index: 99;
    text-align: center;
    font-size: 10px;
    color: #fff;
    box-sizing: border-box;
  }

  .topic-box {
    width: 100%;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;


    .left {
      width: 10%;
    }

    .right {
      width: 90%;
      padding-left: 10px;
      box-sizing: border-box;

      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .title {
        margin: 5px 0;
      }

      .content {
        font-size: 14px;
        color: #666;
        overflow: visible;
      }

      .topic-pic {
        .timg {
          width: 100px;
          height: 100px;

          &:nth-child(2n) {
            margin-left: 6px;
          }
        }
      }

      .more {
        display: flex;
        align-items: center;
        font-size: 12px;
        color: #a3a7af;
      }

    }


  }

  .comments-box {
    width: 100%;

    .box-header {
      margin: 5px 0;
      box-sizing: border-box;
    }

    .comment {
      width: 100%;
      box-sizing: border-box;
    }
  }

  .content {
    width: 100%;
    max-height: 200px;

    overflow-wrap: break-word;
    /* 允许在单词内部换行 */
    word-wrap: break-word;
    /* 兼容旧版本浏览器的换行方式 */
    overflow-y: auto;
  }
}

.scrollbar {
  overflow-y: auto;

  /* 滚动条整体 */
  &::-webkit-scrollbar {
    width: 3px;
    height: 3px;
  }

  /* 两个滚动条交接处 -- x轴和y轴 */
  &::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  /* 滚动条滑块 */
  &::-webkit-scrollbar-thumb {
    background-color: #a3a7af;
    border-radius: 1px;
  }
}
</style>
