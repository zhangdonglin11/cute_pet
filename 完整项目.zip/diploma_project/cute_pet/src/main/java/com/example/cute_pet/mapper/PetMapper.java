package com.example.cute_pet.mapper;

import com.example.cute_pet.domain.Pet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 22212
* @description 针对表【pet】的数据库操作Mapper
* @createDate 2024-03-11 17:24:25
* @Entity generator.domain.Pet
*/
public interface PetMapper extends BaseMapper<Pet> {

}




