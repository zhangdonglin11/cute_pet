package com.example.cute_pet;

import com.example.cute_pet.controller.PetCardController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;

@SpringBootTest
class CutePetApplicationTests {





}
