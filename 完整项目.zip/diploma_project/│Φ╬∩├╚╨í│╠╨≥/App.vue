<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import '@/uni_modules/uv-ui-tools/index.scss';
	@import "@/static/fonts/iconfont.css";
	
	page {
		background-image: linear-gradient(to right, #f0fcfc,#e4f7f3, #f2fce3,#fcfee9);
		height: 100%;
	}
</style>