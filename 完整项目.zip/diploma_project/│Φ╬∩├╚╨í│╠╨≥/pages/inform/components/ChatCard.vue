<script setup>
	import {
		ref
	} from 'vue';
	const props = defineProps({
		chat: Object
	})

	// 处理时间
	const handleTime = (dateString) => {
		const date = new Date(dateString);
		const formattedDate = date.toLocaleString('zh-CN', {
			month: '2-digit',
			day: '2-digit',
			hour: '2-digit',
			minute: '2-digit',
			hour12: false,
		});
		return formattedDate
	}
	
	

</script>

<template>
	<view class="dialogue-item" :style="{backgroundColor:props.chat.status==2||props.chat.status==4?'#eee':''}">
		<view class="profile-photo">
			<image :src="props.chat.anotherPic" mode=""></image>
		</view>
		<view class="right-content">
			<view class="name">
				<text @tap="$emit('handleChat')" style="flex: 1;">{{props.chat.anotherName}}</text>
				<text @tap="$emit('handelDelChat',props.chat.chatId)" class="iconfont">&#xe653;</text>
			</view>
			<view class="dialogue-infrom iconfont" @tap="$emit('handleChat')">
				<text v-if="props.chat.type==0" class="content">{{props.chat.content}}</text>
				<text v-if="props.chat.type==1" class="content">&#xe62f;&nbsp;图片</text>
				<text v-if="props.chat.type==2" class="content">&#xe883;&nbsp;宠物档案</text>
				<text style="font-size: 24rpx;">{{handleTime(props.chat.createTime)}}</text>
			</view>
		</view>
	</view>
</template>

<style lang="scss" scoped>
	.dialogue-item {
		display: flex;
		margin-top: 20rpx;
		border-radius: 10rpx;

		.profile-photo {
			image {
				width: 120rpx;
				height: 120rpx;
				border-radius: 50%;
				background-color: #eee;
			}
		}

		.right-content {
			flex: 1;
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			margin-left: 20rpx;

			.name {
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-weight: 700;
			}

			.dialogue-infrom {
				display: flex;
				justify-content: space-between;
				font-size: 28rpx;
				width: 100%;

				.content {
					width: 14em;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;

				}
			}
		}
	}

	
</style>