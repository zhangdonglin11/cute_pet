<script setup>
	import {
		getCurrentInstance,
		ref
	} from 'vue'

	const messageData = ref(0)
	const instance = getCurrentInstance();
	const eventChannel = instance.ctx.getOpenerEventChannel();
	eventChannel.on('sendMessage', data => {
		messageData.value = data
		console.log(messageData.value)
	})

	const querys = defineProps({
		title: String
	})
	uni.setNavigationBarTitle({
		title: querys.title
	});

	// 去详情页
	import {
		getPet
	} from '@/services/mine.js'
	import {
		getTopic
	} from '@/services/topic.js'
	const goDetails = async (item) => {
		// 去宠物详情页
		if (item.petId != null) {
			// 获取单个宠物的信息
			const {
				data: petObj
			} = await getPet(item.petId)
			uni.navigateTo({
				url: `/pages/mine/PetHomePage/PetHomePage?commentId=${item.commentId}`,
				success: (res) => {
					res.eventChannel.emit('sendPetHome', petObj)
				},
			})
		} else { // 去话题页面
			// 获取单个话题的信息
			const {
				data: topicObj
			} = await getTopic(item.topicId)
			uni.navigateTo({
				url: `/pages/topic/TopicDetails/TopicDetails?commentId=${item.commentId}`,
				success: (res) => {
					res.eventChannel.emit('sendTopicItem', topicObj)
				},
			})
		}
	}
</script>

<template>
	<view class="message-container">

		<scroll-view style="height: 100%;">
			<view @tap="goDetails(item)" v-for="(item,index) in messageData" :key="index" class="message-item">
				<view class="item-left">
					<image :src="item.userPic"></image>
				</view>
				<view class="item-content">
					<view class="name">
						{{item.userName}}
					</view>
					<view class="action">
						{{item?.commentId ==null ?'赞了你' :'评论了你' }}
					</view>
					<view v-if="item.commentId" class="content">
						{{item.content}}
					</view>
				</view>
				<view class="item-right">
					<image v-if="item.targetPic" :src="item.targetPic" class="img"></image>
					<view v-else class="iconfont img">
						&#xe6fd;
						<view style="font-size: 16rpx;">
							没有图片
						</view>
					</view>
				</view>
			</view>
		</scroll-view>
	</view>
</template>


<style lang="scss">
	.message-container {
		padding: 0 30rpx;
		width: 100%;
		height: 100%;
		background-color: #fff;
		box-sizing: border-box;

		.message-item {
			display: flex;
			padding: 20rpx 0;
			width: 100%;
			border-bottom: 2rpx solid #ccc;
			box-sizing: border-box;

			.item-left {
				image {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;
				}
			}

			.item-content {
				flex: 1;
				padding: 0 20rpx;
				box-sizing: border-box;

				.name {
					font-size: 32rpx;
				}

				.action {
					margin: 10rpx 0;
					font-size: 24rpx;
					color: #666;
				}

				.content {
					padding-left: 10rpx;
					font-size: 32rpx;
					color: #666;
					border-radius: 6rpx;
					border-left: 10rpx solid #bbb;
				}
			}

			.item-right {
				.img {
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;
					width: 80rpx;
					height: 80rpx;
					border-radius: 10rpx;
				}
			}
		}
	}
</style>