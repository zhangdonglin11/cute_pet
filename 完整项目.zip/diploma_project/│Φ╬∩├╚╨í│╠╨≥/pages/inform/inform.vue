<script setup>
	import ChatCard from '@/pages/inform/components/ChatCard.vue'
	import {
		ref
	} from 'vue';
	// 获取屏幕边界到安全区域距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	import {
		getChatList,
		deleteChat,
		getLikeCommentData
	} from '@/services/informAPI.js'
	// 获取点赞评论数据
	const likeCommentData = ref(0)
	const intoLikeCommentData =async () => {
		const result =await getLikeCommentData()
		console.log(result)
		likeCommentData.value = result.data
	}

	const goMessage = (data,title) => {
		uni.navigateTo({
			url: `/pages/inform/Message/Message?title=${title}`,
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendMessage', data)
			},
			animationDuration: 1000
		})
	}


	// 去对话页面
	const goDialogue = (chat) => {
		uni.navigateTo({
			url: '/pages/inform/Dialogue/Dialogue',
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendDialogue', chat)
			},
			animationDuration: 1000
		})
	}

	// 获取对话列表
	const chatList = ref([])
	const infoChatList = async () => {
		const result = await getChatList()
		chatList.value = result.data
		console.log(chatList.value)
	}

	// 删除对话
	const delPopup = ref()
	const delChatId = ref()
	const openProps = (chatId) => {
		delPopup.value.open()
		delChatId.value = chatId
	}
	const tapDeleChat = async (chatId) => {
		const result = await deleteChat(chatId)
		uni.showToast({
			icon: "none",
			title: result.message
		})
		infoChatList()
		delPopup.value.close()
	}

	import {
		onShow
	} from '@dcloudio/uni-app'
	onShow(() => {
		// 初始化点赞评论数据
		intoLikeCommentData()
		// 初始化对话列表
		infoChatList()
	})
</script>

<template>
	<view class="infrom-container">
		<!-- 头部标题模块 -->
		<view class="hander-navbar" :style="{ paddingTop: safeAreaInsets?.top  + 'px' }">
			消息
		</view>
		<!-- 其他功能区域 -->
		<!-- <view class="more-func">
			<view class="func-item">
				<view class="icon">

				</view>
				必备协议
			</view>
		</view> -->
		<!-- 获赞、评论 -->
		<view class="acquire">
			<view @tap="goMessage(likeCommentData.likeArr,'收到的点赞')" class="acquire-item">
				<text>获赞</text>
				<view style="display: flex;align-items: center;">
					<text>{{likeCommentData?.likeCunt}}</text><text style="font-size: 24rpx;color: #666;">&nbsp;个</text>
				</view>

			</view>
			<view @tap="goMessage(likeCommentData.commentArr,'收到的评论')" class="acquire-item">
				<text>评论</text>
				<view style="display: flex;align-items: center;">
					<text>{{likeCommentData?.commentCount}}</text><text style="font-size: 24rpx;color: #666;">&nbsp;个</text>
				</view>
			</view>
		</view>

		<!-- 对话区域 -->
		<view class="dialogue">
			<view class="dialogue-title">
				对话&nbsp;({{chatList.length}})
			</view>
			<ChatCard v-for="item in chatList" :chat="item" :key="item.id" @handleChat="goDialogue(item)"
				@handelDelChat="openProps"></ChatCard>
		</view>
	</view>
	<!-- 删除功能弹出层 -->
	<uv-popup ref="delPopup" round="10" mode="bottom" @change="change">
		<view class="delPopup-box">
			<view @tap="tapDeleChat(delChatId)" class="del">
				删除对话
			</view>
		</view>
	</uv-popup>
</template>

<style lang="scss">
	.infrom-container {
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
		background: linear-gradient(to top, #fff 40%, transparent);


		.hander-navbar {
			padding: 20rpx 30rpx;
			font-size: 42rpx;
			font-weight: 700rpx;
		}

		.more-func {
			margin-top: 30rpx;
			padding: 30rpx;
			width: 100%;
			border-radius: 30rpx;
			background-color: #fff;
			box-shadow: rgba(0, 0, 0, .04) 0 0 6rpx 4rpx;
			box-sizing: border-box;

			.func-item {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				width: 140rpx;
				font-size: 28rpx;
				background-color: yellow;

				.icon {
					margin-bottom: 10rpx;
					width: 80rpx;
					height: 80rpx;
					border-radius: 20rpx;
					background-color: black;

				}
			}
		}

		.acquire {
			display: flex;
			margin-top: 30rpx;

			.acquire-item {
				flex: 1;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 30rpx;
				height: 100rpx;
				border-radius: 20rpx;
				background-color: #fff;
				box-sizing: border-box;
				font-weight: 700;
				box-shadow: rgba(0, 0, 0, .04) 0 0 6rpx 4rpx;

				&:last-child {
					margin-left: 20rpx;
				}
			}
		}

		.dialogue {
			margin-top: 30rpx;


			.dialogue-title {
				font-weight: 700;
			}


		}
	}


	.delPopup-box {
		width: 100%;

		.del {
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			padding: 30rpx 0;
		}
	}
</style>