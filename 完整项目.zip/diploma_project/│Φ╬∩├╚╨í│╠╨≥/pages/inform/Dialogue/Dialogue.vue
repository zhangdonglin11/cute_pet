<script setup>
	import HanderNav from '@/components/HanderNav.vue'
	import LikePetCard from '@/pages/mine/components/LikePetCard.vue'
	import {
		onMounted,
		ref,
		getCurrentInstance
	} from 'vue'

	import {
		useUserStore
	} from '@/stores/useUserStore.js'
import { code } from '../../../uni_modules/uv-ui-tools/libs/function/test';

	const userStore = useUserStore();
	// 获取屏幕到安全区域的距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	// 接收 宠物卡片 的数据 我的宠物和的收藏
	const chatList = ref(0)
	const instance = getCurrentInstance();
	const eventChannel = instance.ctx.getOpenerEventChannel();
	eventChannel.on('sendDialogue', data => {
		chatList.value = data
		// 获取聊天记录
		infoChatComment(chatList.value.chatId)

		uni.setNavigationBarTitle({
			title: chatList.value.anotherName
		})
	})

	import {
		getChatHistory,
		sendChat,
		sendChatPic,
		blacklistChat,
		reportChat
	} from "@/services/informAPI.js"
	// 获取对话聊天的记录
	const chatCommentArr = ref()
	const goId = ref(0)
	const infoChatComment = async (chatId) => {
		const result = await getChatHistory(chatId)
		chatCommentArr.value = result.data
		goId.value = chatCommentArr.value[chatCommentArr.value.length - 1].id
	}

	// 发送对话文字内容信息
	const iptContent = ref()
	const sandChatComment = async () => {
		const result = await sendChat(chatList.value.chatId, iptContent.value, 0)
		infoChatComment(chatList.value.chatId)
		iptContent.value = ''
		if(result.code == 0){
			uni.showToast({
				icon:'none',
				title:result.message
			})
		}
	}

	// 处理时间
	const handleTime = (dateString) => {
		const date = new Date(dateString);
		const formattedDate = date.toLocaleString('zh-CN', {
			month: '2-digit',
			day: '2-digit',
			hour: '2-digit',
			minute: '2-digit',
			hour12: false,
		});
		return formattedDate
	}

	// 选择宠物模块
	import MyPetCard from '@/pages/mine/components/MyPetCard.vue'
	const petPopup = ref()
	const myPetArr = ref(0)
	const myPetCount = ref(0)
	const isShoeMyPet = ref(false)
	import {
		getMyPet
	} from '@/services/mine.js'
	// 初始呀我的宠物
	const infoMypet = async (uid) => {
		const res = await getMyPet(uid)
		myPetArr.value = res.data
		myPetCount.value = myPetArr.value.length
		console.log(myPetArr.value)
		isShoeMyPet.value = true
	}

	// 点击宠物的信息发送给对方
	const sendPetCard = async (val) => {
		const petContent = JSON.stringify(val)
		const result = await sendChat(chatList.value.chatId, petContent, 2)
		infoChatComment(chatList.value.chatId)
		petPopup.value.close()
	}
	// 发送图片
	const sandPic = async () => {
		// 选择图片
		uni.chooseImage({
			count: 1, //可以选择多少张图片
			sizeType: ['original'],
			crop: {
				quality: 100, //图片质量,不填为80
				width: 400, //裁剪宽度
				height: 400, //裁剪高度
			},
			success: async (res) => {
				await sendChatPic(chatList.value.chatId, res.tempFilePaths[0])
				infoChatComment(chatList.value.chatId)
				return
			},
		});
	}

	// 拉黑举报功能 
	const moveIsShow = ref(false)
	// 拉黑功能
	const tapBlacklistCha = async () => {
		const result = await blacklistChat(chatList.value.chatId)

		uni.showToast({
			icon: "none",
			title: result.message
		})

		chatList.value = result.data
		moveIsShow.value = false
	}
	// 举报功能
	const tapReportChat = async () => {
		const result = await reportChat(chatList.value.chatId)
		uni.showToast({
			icon: "none",
			title: result.message
		})
		chatList.value = result.data
		moveIsShow.value = false
	}

	// 查询宠物是否存在
	const isShowpetCard = (petObj) => {
		console.log(petObj)
		return true
	}

	onMounted(() => {

		infoMypet(userStore.profile.id)
	})
</script>

<template>
	<view class="dialogue-container">
		<!-- 顶部 -->
		<view class="main" style="padding:0 0 120rpx;">

			<scroll-view :scroll-into-view="'i'+goId" scroll-y
				style="height: 100%;padding: 0 30rpx;box-sizing: border-box;" class="scroll-view-box">
				<view :id="'i'+item.id" v-for="item in chatCommentArr" :key="item.id" class="dialogue-item">
					
						
						<!-- 他的消息 -->
						<view v-if="item.userId==chatList.anotherId" class="message-box">
							<view class="box-top">
								<view class="box-left">
									<image :src="item.userPic" mode=""></image>
								</view>
								<view class="box-right">
									<!-- 文字 -->
									<view v-if="item.type==0" class="message" style="margin-right: 120rpx;">
										{{item.content}}
									</view>
									<!-- 图片 -->
									<image v-if="item.type==1" :src="item.content" mode="widthFix"></image>
									<!-- 宠物卡片 -->
									<LikePetCard v-if="item.type==2" :petObj="JSON.parse(item.content)"
										@tapHandlePet="gotoPetDetail" />
								</view>
							</view>
							<view class="box-bottom" style="padding-left: 100rpx;margin-top: 10rpx;">
								{{handleTime(item.createTime)}}
							</view>
						</view>
						
						<!-- 我的的消息 -->
						<view v-if="item.userId==chatList.userId" class="message-box">
							<view class="box-top" style="flex-direction: row-reverse;">
								<!-- 用户头像 -->
								<view class="box-left">
									<image :src="item.userPic" mode=""></image>
								</view>
								<!-- 内容 -->
								<view class="box-right" style="flex-direction: row-reverse;">
									<view v-if="item.type==0" class="message" style="margin-left: 120rpx;">
										{{item.content}}
									</view>
									<image v-if="item.type==1" :src="item.content" mode="widthFix"></image>
									
									<LikePetCard v-if="item.type==2" :petObj="JSON.parse(item.content)"
										style="margin-right: -0rpx;" />
								</view>
							</view>
							<view class="box-bottom" style="text-align: right;padding-right: 100rpx;margin-top: 10rpx;">
								{{handleTime(item.createTime)}}
							</view>
						</view>
					
					
				</view>
				<view style="height: 150rpx;">

				</view>
			</scroll-view>
		</view>
	</view>

	<view class="footer" :style="{paddingBottom:safeAreaInsets.bottom+'px'}">
		<input v-model.trim="iptContent" @confirm="sandChatComment()" maxlength="240" type="text" class="footer-ipt"
			placeholder="发送文字或者右边+图标发图片">
		<view class="sedn-img iconfont" @tap="sandPic">
			&#xe8b2;
		</view>
		<!-- 选择发送我的宠物 -->
		<view v-if="isShoeMyPet" class="send-mypet">
			<view class="box">
				<view class="mypet-top">
					<text>您的宠物档案</text>
					<text @tap="isShoeMyPet=false" class="iconfont">&#xe767;</text>
				</view>
				<view class="mypet-bottom">
					<text>您当前有{{myPetCount}}个宠物档案</text>
					<view class="mypet-btn" @tap="petPopup.open()">
						发送宠物档案
					</view>
				</view>
			</view>
		</view>

		<!-- 举报拉黑功能 -->
		<view class="move-func">
			<view class="iconfont move" @tap="moveIsShow = !moveIsShow">
				&#xe653;
			</view>
			<view v-if="moveIsShow" class="func-box">
				<view @tap="tapReportChat()" class="top iconfont">
					<text style="color: red;font-weight: 700;">&#xe8f1;</text> 举报
				</view>
				<view @tap="tapBlacklistCha()" class="botton iconfont">
					&#xe73e;&nbsp;{{chatList?.status==2||chatList?.status==4?'取消':'拉黑'}}
					<text>&#xe89e;</text>
				</view>
			</view>
		</view>
	</view>
	<!-- 选择宠物 -->
	<uv-popup ref="petPopup" mode="bottom" @change="change">
		<view class="pet-popup-box">
			<scroll-view scroll-y style="height: 100%;">
				<MyPetCard v-for="item in myPetArr" :key="item.pet.id" :petObj="item" @tapHandlePet="sendPetCard">
				</MyPetCard>
			</scroll-view>
		</view>
	</uv-popup>
</template>

<style lang="scss" scoped>
	.dialogue-container {
		height: 100%;
		box-sizing: border-box;

		.main {
			height: 100%;
			padding: 0 30rpx;
			box-sizing: border-box;


			.dialogue-item {
				width: 100%;


				// 他的样式
				.message-box {
					position: relative;
					padding: 10rpx 0;

					.box-top {
						display: flex;

						.box-left {
							image {
								width: 80rpx;
								height: 80rpx;
								border-radius: 40rpx;
								border: 2rpx solid #999;
							}
						}

						.box-right {
							display: flex;
							align-items: center;
							width: 100%;
							position: relative;
							margin: 0 20rpx;

							.message {
								padding: 20rpx 20rpx;
								border-radius: 20rpx;
								background-color: #000;
								color: #fff;
								box-sizing: border-box;
							}

							image {

								width: 400rpx;
								border-radius: 20rpx;
							}
						}
					}
				}
			}

		}
	}

	.footer {
		position: fixed;
		bottom: 0;
		left: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		padding: 30rpx 30rpx 0;
		width: 100%;
		height: 120rpx;
		background-color: #ffffff;
		box-sizing: border-box;

		.footer-ipt {
			padding: 0 20rpx;
			height: 70rpx;
			border-radius: 20rpx;
			flex: 1;
			background-color: #e7e7e7;
		}

		.sedn-img {
			position: relative;
			color: #666;
			font-size: 56rpx;
			margin: 20rpx;

		}

		.send-mypet {
			position: absolute;
			top: -180rpx;
			width: 100%;
			padding: 30rpx;
			box-sizing: border-box;

			.box {
				padding: 20rpx;
				width: 100%;
				height: 100%;
				border-radius: 20rpx;
				background-image: linear-gradient(to bottom, #faffde, #fbfee8, #fefefc);
				box-shadow: rgba(0, 0, 0, 0.1) 0 0 10rpx 2rpx;
				box-sizing: border-box;


				.mypet-top {
					display: flex;
					justify-content: space-between;
					font-size: 24rpx;
					font-weight: 700;
				}

				.mypet-bottom {
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin-top: 10rpx;
					font-size: 20rpx;
					color: #999;

					.mypet-btn {
						padding: 10rpx 20rpx;
						border-radius: 9999rpx;
						background-color: #000;
						color: #fff;
						font-size: 20rpx;
					}
				}
			}
		}

		.move-func {
			position: fixed;
			top: 40%;
			right: 0;
			padding: 10rpx 0 10rpx 10rpx;
			width: 80rpx;
			border-radius: 60rpx 0 0 60rpx;
			background-color: #fff;
			box-shadow: rgba(0, 0, 0, 0.3) 0 0 10rpx 0rpx;
			// border: 2rpx solid #333;
			box-sizing: border-box;

			.move {
				display: flex;
				justify-content: center;
				align-items: center;
				width: 50rpx;
				height: 50rpx;
				border-radius: 50%;
				// background-image: linear-gradient(to right, #f0fcfc,#fcfee9);
				background-color: yellowgreen;
				font-size: 32rpx;
				font-weight: 700;
			}

			.func-box {
				position: absolute;
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				top: 80rpx;
				right: 20rpx;
				min-width: 160rpx;
				height: 160rpx;
				padding: 0 20rpx;
				background-color: #fff;
				font-size: 24rpx;
				border-radius: 10rpx;
				box-shadow: rgba(0, 0, 0, 0.3) 0 0 10rpx 0;

				.botton {
					margin-top: 20rpx;
					position: relative;

					text {
						position: absolute;
						transform: rotate(134deg);
						left: 8px;
						top: 10px;
						font-size: 14rpx;
						font-weight: 700;
						background-color: #fff;
						border-radius: 50%;
					}
				}
			}
		}
	}

	// 选择宠物弹出层样式
	.pet-popup-box {
		height: 600rpx;
		padding: 30rpx;
	}
</style>