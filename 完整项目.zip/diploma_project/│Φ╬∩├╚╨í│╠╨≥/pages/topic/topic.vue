<script setup>
	import TopicNav from './components/TopicNav.vue'
	import TopicItem from './components/TopicItem.vue'
	import {
		ref,
		watch,
		onMounted,
		onUnmounted
	} from 'vue';
	import {
		getFiltrateTopic
	} from '@/services/topic.js'

	// 获取屏幕边界到安全区域距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();


	const goTopicDetails = () => {
		uni.navigateTo({
			url: '/pages/topic/AddTopic/AddTopic'
		})
	}

	// 获取所有的话题
	const filtrate = ref({
		whoTopic: 0, //我的1
		classify: null,
		current: 1, // 查询页数
		size: 5, // 查询条数
		pages: null, //总页数
	})
	const topicArr = ref(0)
	const infoTopicList = async () => {
		filtrate.value.current = 1
		const result = await getFiltrateTopic(filtrate.value)
		topicArr.value = result.data.topicArr
		filtrate.value.current = result.data.current
		filtrate.value.pages = result.data.pages
		console.log(topicArr.value)
		// 改变上拉状态
		status.value = 'loadmore'
		if (filtrate.value.current >= filtrate.value.pages) status.value = 'nomore';
	}
	watch(() => filtrate.value.classify,
		(newVal, oldVal) => {
			infoTopicList()
		}, {
			deep: true
		})
	watch(() => filtrate.value.whoTopic,
		(newVal, oldVal) => {
			infoTopicList()
		}, {
			deep: true
		})

	import {
		saveTopicLike
	} from '@/services/topic.js'
	const tapTopicLike = async (val) => {
		const result = await saveTopicLike(val)
		// 修改点赞状态
		if (result.code = 1) {
			const topicObj = topicArr.value.find(item => item.topic.id == val)
			topicObj.topicLike.isLike = !topicObj.topicLike.isLike
			if(topicObj.topicLike.isLike==true){
				topicObj.topicLike.count +=1
			}else{
				topicObj.topicLike.count -=1
			}
			return
		}
	}

	// 加载更多
	const status = ref('loadmore');
	const loadingText = ref('努力加载中')
	const loadmoreText = ref('轻轻上拉')
	const nomoreText = ref('实在没有了')
	const onReachBottom = async () => {
		if (filtrate.value.current >= filtrate.value.pages) return;
		status.value = 'loading';
		filtrate.value.current += 1;
		const result = await getFiltrateTopic(filtrate.value)
		setTimeout(() => {
			// 获取新的数据
			topicArr.value.push(result.data.topicArr)
			filtrate.value.current = result.data.current
			filtrate.value.pages = result.data.pages

			if (filtrate.value.current >= filtrate.value.pages) status.value = 'nomore';
			else status.value = 'loadmore';
		}, 2000);
	};

	import {
		onShow
	} from '@dcloudio/uni-app'
	onShow(() => {
		infoTopicList()
	})
</script>

<template>
	<view class="topic-container">
		<view style="background-color: #fff; box-shadow: rgba(0, 0, 0, 0.1) 0 2rpx 4rpx 0rpx;">
			<TopicNav :optFor="filtrate.whoTopic" @handleOptFor="(val)=>filtrate.whoTopic=val">
			</TopicNav>

			<view class="classify">
				<view @tap="filtrate.classify=null" :class="{active:filtrate.classify==null}" class="nav">
					全部
				</view>
				<view @tap="filtrate.classify='日常'" :class="{active:filtrate.classify=='日常'}" class="nav">
					日常
				</view>
				<view @tap="filtrate.classify='养宠经验'" :class="{active:filtrate.classify=='养宠经验'}" class="nav">
					养宠经验
				</view>
				<view class="nav iconfont">
					&#xe8f9;
				</view>
			</view>
		</view>

		<scroll-view @scrolltolower="onReachBottom()" class="scroll-box" scroll-y>
			<TopicItem v-for="(item,index) in topicArr" :key="topicArr.topic?.id" :topicObj="item"
				@handleLike="tapTopicLike" @updateTopic="infoTopicList()" class="tItem"></TopicItem>
			<uv-load-more :status="status" :loading-text="loadingText" :loadmore-text="loadmoreText"
				:nomore-text="nomoreText" />
		</scroll-view>

		<!-- 发表页面按钮 -->
		<view @tap="goTopicDetails()" class="topic-button iconfont">
			&#xe6bd;
		</view>

	</view>
</template>

<style lang="scss" scoped>
	.topic-container {
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		background: linear-gradient(to top, #fff 40%, transparent);
		box-sizing: border-box;


		.classify {
			position: relative;
			display: flex;
			align-items: center;
			margin: 10rpx 30rpx;
			padding: 20rpx;
			border-radius: 20rpx;
			box-sizing: border-box;
			font-size: 28rpx;
			background-color: #fff;

			.nav {
				padding: 0 20rpx;
			}

			.active {
				position: relative;
				font-size: 32rpx !important;
				font-weight: 700;

				&::after {
					position: absolute;
					left: 50%;
					bottom: -30%;
					transform: translateX(-50%);
					content: '';
					width: 50rpx;
					height: 6rpx;
					border-radius: 6rpx;
					background-color: red;
				}
			}

			.iconfont {
				position: absolute;
				right: 0;
			}
		}

		.scroll-box {
			flex: 1;
			overflow-y: scroll;
		}

		.topic-button {
			position: fixed;
			display: flex;
			justify-content: center;
			align-items: center;
			right: 30rpx;
			bottom: 10%;
			width: 100rpx;
			height: 100rpx;
			border-radius: 50%;
			background-color: #c6feba;
			font-size: 80rpx;
			color: #666;
			box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 8px 4px;
		}
	}
</style>