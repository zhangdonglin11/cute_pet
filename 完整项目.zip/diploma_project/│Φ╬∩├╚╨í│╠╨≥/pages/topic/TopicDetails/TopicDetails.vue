<script setup>
	import {
		onMounted,
		ref,
		getCurrentInstance
	} from 'vue';
	import {
		saveTopicComment,
		getTopic,
		saveTopicLike
	} from '@/services/topic.js'
	import {
		useUserStore
	} from '@/stores/useUserStore.js'

	const userStore = useUserStore();
	// 获取屏幕到安全区域的距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	// 处理时间
	const getTimer = (ot) => {
		let newtime = new Date();
		let oldtime = new Date(ot);
		let diff = newtime.getTime() - oldtime.getTime();
		let diffInMinutes = diff / (1000 * 60); // 将毫秒转换为分钟
		let diffInHour = diff / (1000 * 60 * 60);
		let diffInDay = diff / (1000 * 60 * 60 * 24);
		if (diffInMinutes.toFixed(2) < 60) {
			return Math.floor(diffInMinutes) + '分钟前';
		} else if (diffInHour < 24) {
			return Math.floor(diffInHour) + '小时前';
		} else {
			return Math.floor(diffInDay) + '天前';
		}
	}

	const props = defineProps({
		goId: Number
	})
	const topicObj = ref(0)


	// 接收 话题组件的数据 我的宠物和的收藏
	const instance = getCurrentInstance();
	const eventChannel = instance.ctx.getOpenerEventChannel();
	eventChannel.on('sendTopicItem',async data => {
		topicObj.value = data
		const result = await getTopic(topicObj.value.topic.id)
		topicObj.value = result.data
	})

	// 获取话题信息
	const infoTopic = async () => {
		const result = await getTopic(topicObj.value.topic.id)
		topicObj.value = result.data
	}


	// 评论区域
	const commentPopup = ref()
	// 输入框获得焦点
	const iptText = ref('说点好听的话~')
	const iptRef = ref(null)

	const formData = ref({
		content: '', //品论内容
		topicId: 1, // 宠物id
		level: 0, // 品论层级 0根 1回复0 2回复1\2
		parentId: '', //回复目标的id，没有则null
		rootId: '' // 根品论id 
	})
	// 根评论方法
	const rootComment = () => {
		commentPopup.value.open()
		iptText.value = '说点好听的话~';
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.topicId = topicObj.value.topic.id
		formData.value.level = 0;
		formData.value.parentId = '';
		formData.value.rootId = ''
	}
	// 其他评论
	const OtherComment = (val) => {
		commentPopup.value.open()
		iptText.value = '回复 ' + val.nickName;
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.topicId = topicObj.value.topic.id
		formData.value.level = val.level;
		formData.value.parentId = val.parentId;
		formData.value.rootId = val.rootId
		console.log(val.level + "=" + topicObj.value.topic.id)
	}

	// 提交评论
	const SubmintTopicComment = async (val) => {
		if (val.content == '') {
			return
		}
		const res = await saveTopicComment(val);
		uni.showToast({
			icon: 'none',
			title: res.message
		})
		// 更新页面信息
		infoTopic()
		// 关闭评论输入框
		commentPopup.value.close()
	}

	// 点赞
	const taptopicLike = async () => {
		const result = await saveTopicLike(topicObj.value.topic.id)
		infoTopic()
	}
	// 举报删除模块
	const morePopup = ref()

	const tapDelTopic = (val) => {
		morePopup.value.close()
	}

	const tapReportTopic = (val) => {
		morePopup.value.close()
	}
	
	import {reportComment} from '@/services/mine.js'
	const tapReportComment =async (pid)=>{
		const result=await reportComment(pid)
		if(result.code){
			uni.showToast({
				icon:'none',
				title:"举报成功"
			})
		}
	}
	
	// 前往用户主页
	const gotoUserHome=(userId)=>{
		// console.log(userId)
		uni.navigateTo({
			url:`/pages/mine/UserHome/UserHome?userId=${userId}`
		})
	}
</script>

<template>
	<view class="TopicDetails-container">

		<scroll-view :scroll-into-view="'p'+props.goId" scroll-y style="height: 100%;">
			<view class="details-box">
				<view class="box-left" @tap="gotoUserHome(topicObj?.topic?.userId)">
					<image :src="topicObj?.topic?.userPic" class="pic" center></image>
				</view>
				<view class="box-right">
					<view class="right-hander">
						<view class="user-name">
							{{topicObj?.topic?.userName}}
						</view>
						<!-- 举报删除弹出层 -->
						<view @tap="morePopup.open()" class="iconfont">
							&#xe653;
						</view>
					</view>

					<view class="topic-title" >
						{{topicObj?.topic?.title}}
					</view>

					<view class="topic-content">
						<text style="color: deepskyblue;">#{{topicObj.topic?.classify}}</text>
						&nbsp;{{topicObj.topic?.content}}
						<view class="topic-img">
							<template v-if="topicObj.pic?.length==1">
								<img :src="topicObj.pic[0]" class="one-pic" />
							</template>
							<template v-else>
								<img v-for="(item,index) in topicObj?.pic" :src="item" :key="index" class="two-pic" />
							</template>
						</view>
					</view>

					<view class="topic-bottom">
						<view class="iconfont icon-left">
							&#xe8db;&nbsp;围观{{topicObj.topic?.viewed}}
							&nbsp;&nbsp;&#xe856;{{getTimer(topicObj.topic?.createTime)}}
						</view>
						<view class="icon-right">
							<!-- 黑桃 &#xe887; -->
							<text class="iconfont" @tap="taptopicLike()">
								<text v-if="topicObj.topicLike?.isLike" style="color: red;">&#xe887;</text>
								<text v-else>&#xe886;</text>
								&nbsp;{{topicObj.topicLike?.count}}
							</text>
						</view>
					</view>
				</view>
			</view>
			<!-- 评论区域 -->
			<view class="comments-section">
				<view class="comment-header">
					<text class="haeder-left">全部评论{{topicObj.topicComment?.count}}</text>
				</view>

				<view :id="'p'+item.id" :style="{backgroundColor:item.id==props.goId?'#eee':''}"
					class="comment_container" v-for="(item,index) in topicObj.topicComment?.comments" :key="index">
					<view class="box_left" @tap="gotoUserHome(item.userId)">
						<image :src="item.avatar" mode=""></image>
					</view>
					<view class="box_right">
						<view class="box_right_top">
							<view class="user_name">
								{{item.nickName}}
								<text v-if="item.nickName==userStore.profile.nickname"
									style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">我</text>
								<!-- 举报按钮 -->
								<span @tap="tapReportComment(item.id)" class="iconfont" style="margin-left: 20rpx;">&#xe76b;</span>
							</view>

							<view class="user_say"
								@tap="OtherComment({rootId:item.id, parentId:item.userId, nickName:item.nickName,level:1})">
								<text class="say">{{item.content}}</text>
								<text class="t">{{getTimer(item.createTime)}}</text>
								<text class="t" style="color: lightskyblue;">回复</text>
							</view>
						</view>

						<view :id="'p'+childItem.id" :style="{backgroundColor:childItem.id==props.goId?'#eee':''}"
							class="child_comment" v-for="(childItem,childIndex) in item.child" :key="index">
							<view class="box_left" @tap="gotoUserHome(childItem.userId)">
								<image :src="childItem.avatar" mode=""></image>
							</view>
							<view class="box_right">
								<view class="user_name">
									<text> {{childItem.nickName}}&nbsp;
										<text v-if="childItem.replyUserName==userStore.profile.nickname"
											style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">我</text>
									</text>
									<text v-show="childItem.level == 2">回复&nbsp;'{{childItem.replyUserName}}'
										<text v-if="childItem.replyUserName==userStore.profile.nickname"
											style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">我</text>
									</text>
									<!-- 举报按钮 -->
									<span @tap="tapReportComment(childItem.id)" class="iconfont" style="margin-left: 20rpx;">&#xe76b;</span>
								</view>
								<!--  -->
								<view class="user_say"
									@tap="OtherComment({rootId:item.id, parentId:childItem.userId, nickName:childItem.nickName,level:2})">
									<text class="say">{{childItem.content}}</text>
									<text class="t">{{getTimer(childItem.createTime)}}</text>

									<text class="t" style="color: lightskyblue;">回复</text>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="comments-box">
					--没有更多数据了--
				</view>
			</view>
		</scroll-view>
		
		<view class="comment-ipt" :style="{paddingBottom: safeAreaInsets?.bottom+'rpx'}">
			<input @tap="rootComment()" type="text" class="ipt" placeholder="说点好听的话~~" disabled />
		</view>

		<!-- 评论弹出层 -->
		<uv-popup ref="commentPopup" mode="bottom" bgColor="none" :overlayStyle="{background: 'rgba(0,0,0,0)'}"
			:safeAreaInsetBottom="false">
			<view class="popup-box" :style="{paddingBottom: safeAreaInsets?.bottom+'rpx'}">
				<input focus class="ipt" type="text" :placeholder="iptText" maxlength="140"
					v-model.trim="formData.content" @confirm="SubmintTopicComment(formData)" />
			</view>
		</uv-popup>
	</view>
	<!-- 举报关闭弹出层 -->
	<uv-popup ref="morePopup" mode="bottom">
		<view class="morePopup-box">
			<view @tap="tapReportTopic(topicObj.topic.id)" class="del">
				举报
			</view>
			<view @tap="tapDelTopic(topicObj.topic.id)"
				v-if="topicObj.topic.userId==userStore.profile.id" class="del">
				删除
			</view>
		</view>
	</uv-popup>
</template>

<style lang="scss" scoped>
	.TopicDetails-container {
		width: 100%;
		height: 100%;
		background-color: #f9f9f9;

		.details-box {
			display: flex;
			padding: 0 30rpx;
			border-radius: 20rpx;
			box-sizing: border-box;

			.box-left {
				.pic {
					width: 70rpx;
					height: 70rpx;
					border-radius: 50%;
					background-color: red;
				}
			}

			.box-right {
				flex: 1;
				margin-left: 20rpx;
				font-size: 32rpx;
				box-sizing: border-box;

				.right-hander {
					display: flex;
					justify-content: space-between;

					.iconfont {
						font-size: 40rpx;
						font-weight: 700;
					}
				}

				.topic-title {
					margin: 20rpx 0;
					font-size: 36rpx
				}

				.topic-content {
					color: #333;
					width: 600rpx;
					word-wrap: break-word;
					overflow-wrap: break-word;
					.topic-img {

						.one-pic {
							margin-top: 20rpx;
							width: 400rpx;
							
						}

						.two-pic {
							margin-top: 20rpx;
							margin-right: 20rpx;
							width: 260rpx;
							height: 260rpx;
						}
					}
				}

				.topic-bottom {
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin-top: 20rpx;

					.icon-left {
						font-size: 24rpx;
						color: #999;
					}

					.icon-right {
						font-size: 28rpx;
						color: #333;

						.iconfont {
							margin-right: 10rpx;
							width: 50rpx;
						}
					}

				}
			}
		}

		.comments-section {
			margin-top: 20rpx;
			padding: 10rpx 30rpx;

			.comment-header {
				font-size: 36rpx
			}

			.comment_container {
				display: flex;
				margin-top: 30rpx;


				.box_left {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;

					background-size: 80rpx 80rpx;

					image {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;

					}
				}

				.box_right {
					flex: 1;
					margin-left: 20rpx;


					.box_right_top {
						margin-bottom: 20rpx;

						.user_name {
							font-size: 24rpx;
							color: #666;
						}

						.user_say {
							width: 100%;
							margin-top: 20rpx;

							.t {
								margin-left: 10rpx;
								font-size: 20rpx;
								color: #999;
							}
						}
					}

					.child_comment {
						display: flex;

						padding: 10rpx 0 10rpx 10rpx;
						margin-bottom: 10rpx;

						.box_left {
							width: 60rpx;
							height: 60rpx;
							border-radius: 50%;

							background-size: 60rpx 60rpx;

							image {
								width: 60rpx;
								height: 60rpx;
								border-radius: 50%;
							}
						}

						.box_right {
							border-bottom: 0 !important;


							.user_name {
								font-size: 24rpx;
								color: #666;
							}

							.user_say {
								margin-top: 10rpx;

								.t {
									margin-left: 10rpx;
									font-size: 20rpx;
									color: #999;
								}
							}
						}
					}

				}
			}

			.comments-box {
				display: flex;
				justify-content: center;
				margin: 50rpx 0 120rpx;
			}
		}

		// 评论输入框
		.comment-ipt {
			position: fixed;
			padding: 10rpx 40rpx 0;
			left: 0;
			bottom: 0;
			width: 100%;
			background-color: #fff;
			box-sizing: border-box;

			.ipt {
				padding: 0 40rpx;
				width: 100%;
				height: 60rpx;
				border-radius: 30rpx;
				background-color: #f0f0f0;
					
			}
		}

		// 评论输入弹窗
		.popup-box {
			padding: 10rpx 40rpx 0;
			background-color: #fff;

			.ipt {
				padding: 0 40rpx;
				width: 100%;
				height: 60rpx;
				border-radius: 30rpx;
				background-color: #f0f0f0;
				box-sizing: border-box;
			}
		}
	}

	.morePopup-box {
		width: 100%;

		.del {
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			padding: 15rpx 0;
			border-bottom: 2rpx solid #ccc;
		}
	}
</style>