<script setup>
	import {
		ref
	} from 'vue';
	// 获取屏幕边界到安全区域距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	const props=defineProps({
		optFor: Number
	})
</script>

<template>
	<!-- 头部标题模块 -->
	<view class="navbar" :style="{ paddingTop: safeAreaInsets?.top  + 'px' }">
		<view @tap="$emit('handleOptFor',0)" :class="{active:props.optFor==0}" class="nav_tabs">
			话题社区
		</view>
		<view @tap="$emit('handleOptFor',1)" :class="{active:props.optFor==1}" class="nav_tabs">
			我的发布
		</view>
	</view>
</template>

<style lang="scss" scoped>
	.navbar {
		
		display: flex;
		align-items: center;
		padding: 0;

		// background-color: #fff;
		.nav_tabs {
			display: flex;
			padding: 20rpx 0 20rpx 30rpx;
			font-size: 32rpx;
			align-items: center;
		}

		.active {
			font-size: 42rpx;
			font-weight: 700;
		}
	}
</style>