<script setup>
	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	import {
		ref
	} from 'vue';

	const userStore = useUserStore();
	const props = defineProps({
		topicObj: Object
	})
	const getTimer = (ot) => {
		let newtime = new Date();
		let oldtime = new Date(ot);
		let diff = newtime.getTime() - oldtime.getTime();
		let diffInMinutes = diff / (1000 * 60); // 将毫秒转换为分钟
		let diffInHour = diff / (1000 * 60 * 60);
		let diffInDay = diff / (1000 * 60 * 60 * 24);
		if (diffInMinutes.toFixed(2) < 60) {
			return Math.floor(diffInMinutes) + '分钟前';
		} else if (diffInHour < 24) {
			return Math.floor(diffInHour) + '小时前';
		} else {
			return Math.floor(diffInDay) + '天前';
		}
	}

	import {
		saveTopicLike,
		getReport,
		getDelTopic,
		saveViewed
	} from "@/services/topic.js"
	
	const goDetails =async () => {
		await saveViewed(props.topicObj.topic.id)
		uni.navigateTo({
			url: '/pages/topic/TopicDetails/TopicDetails',
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendTopicItem', props.topicObj)
			}
		})
	}
	

	// 举报删除模块
	const morePopup = ref()
	const emit = defineEmits(['updateTopic'])

	const tapDelTopic = async (val) => {
		const result = await getDelTopic(val)
		uni.showToast({
			icon: 'none',
			title: result.message
		})
		emit('updateTopic')
		morePopup.value.close()
	}

	const tapReportTopic = async (val) => {
		const result = await getReport(val)
		uni.showToast({
			icon: 'none',
			title: result.message
		})
		morePopup.value.close()
	}
	
	// 前往用户主页
	const gotoUserHome=(userId)=>{
		// console.log(userId)
		uni.navigateTo({
			url:`/pages/mine/UserHome/UserHome?userId=${userId}`
		})
	}
</script>

<template>
	<view class="topic-item">
		<view class="item-left" @tap="gotoUserHome(props.topicObj.topic.userId)">
			<!-- 头像图片 -->
			<image :src="props.topicObj.topic.userPic" class="pic"></image>
		</view>

		<view class="item-right">

			<view class="item-right-hander">
				<view class="user-name">
					{{props.topicObj.topic.userName}}
					<text v-if="props.topicObj.topic.userId==userStore.profile.id"
						style="padding:2rpx; background-color:#eee;border-radius: 4rpx;">我</text>
				</view>
				<view @tap="morePopup.open()" class="iconfont">
					&#xe653;
				</view>
			</view>

			<view class="topic-title" @tap="goDetails()">
				{{props.topicObj.topic.title}}
			</view>

			<view class="topic-content" @tap="goDetails()">
				<div style="max-height: 100rpx; white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">
					<text style="color: deepskyblue;">#{{props.topicObj.topic.classify}}</text>
					&nbsp;{{props.topicObj.topic.content}}
				</div>
				<view class="topic-img">
					<template v-if="props.topicObj.pic?.length==1">
						<image center class="timg" :src="props.topicObj.pic[0]">
						</image>
					</template>
					<template v-if="props.topicObj.pic?.length>1">
						<image center class="timg" :src="props.topicObj.pic[0]">
						</image>
						<image center class="timg" :src="props.topicObj.pic[1]">
						</image>
						<text class="iconfont">&nbsp;&nbsp;&#xe86a;</text>
					</template>
				</view>
			</view>

			<view class="topic-bottom">
				<view class="iconfont icon-left">
					&#xe8db;&nbsp;围观 {{props.topicObj.topic.viewed}} &nbsp;&nbsp;&#xe856;
					{{getTimer(props.topicObj.topic.createTime)}}
				</view>
				<view class="icon-right">
					<!-- 黑桃 &#xe887; -->
					<text class="iconfont" @tap="$emit('handleLike',topicObj.topic.id)">
						<text v-if="props.topicObj.topicLike.isLike" style="color: red;">&#xe887;</text>
						<text v-else>&#xe886;</text>
						&nbsp;{{props.topicObj.topicLike.count}}
					</text>

					<text class="iconfont">
						&#xe768;&nbsp;{{props.topicObj.topicComment.count}}
					</text>
				</view>
			</view>

		</view>

	</view>
	<!-- 举报关闭弹出层 -->
	<uv-popup ref="morePopup" mode="bottom">
		<view class="morePopup-box">
			<view @tap="tapReportTopic(props.topicObj.topic.id)" class="del">
				举报
			</view>
			<view @tap="tapDelTopic(props.topicObj.topic.id)" v-if="props.topicObj.topic.userId==userStore.profile.id"
				class="del">
				删除
			</view>
		</view>
	</uv-popup>
</template>

<style lang="scss" scoped>
	.topic-item {
		display: flex;
		margin: 30rpx 30rpx 0;
		padding: 20rpx;
		border-radius: 20rpx;
		background-color: #fff;
		box-sizing: border-box;
		box-shadow: rgba(0, 0, 0, .08) 0 0 6rpx 6rpx;

		.item-left {
			.pic {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
				background-color: #ccc;
			}
		}

		.item-right {
			flex: 1;
			margin-left: 20rpx;
			font-size: 32rpx;
			box-sizing: border-box;

			.item-right-hander {
				display: flex;
				justify-content: space-between;
				font-size: 32rpx;
				.iconfont {
					font-size: 40rpx;
					font-weight: 700;
				}
			}

			.topic-title {
				margin: 20rpx 0;
				font-size: 36rpx;
			}

			.topic-content {
				width: 540rpx;
				font-size: 32rpx;
			
				box-sizing: border-box;
				.topic-img {
					display: flex;
					align-items: center;
					margin-top: 20rpx;
					.timg {
						margin-left: 20rpx;
						width: 180rpx;
						height: 180rpx;
					}
				}
			}

			.topic-bottom {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-top: 20rpx;

				.icon-left {
					font-size: 24rpx;
					color: #999;
				}

				.icon-right {
					font-size: 28rpx;
					color: #333;

					.iconfont {
						margin-right: 10rpx;
						width: 50rpx;
					}
				}

			}
		}

	}

	.morePopup-box {
		width: 100%;

		.del {
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			padding: 15rpx 0;
			border-bottom: 2rpx solid #ccc;
		}
	}
</style>