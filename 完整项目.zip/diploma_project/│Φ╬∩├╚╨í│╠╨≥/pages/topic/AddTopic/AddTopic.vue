<script setup>
	import {
		ref,
		computed,
		onMounted,
		getCurrentInstance,
		watch
	} from 'vue';
	import {
		getTopicDraft,
		saveTopic,
		saveTopicPic
	} from '@/services/topic.js'

	import {
		changeImgType
	} from '@/services/common.js'

	// 提交表单
	const topicForm = ref({
		id: null, //话题id
		userId: null, //用户id
		title: null, //标题
		content: '', //内容
		classify: null, //类别
		allow: 1 //是否允许评论
	})
	const topicPicker = ref()
	const topicColumns = ref([
		['日常', '养宠经验']
	])
	// 是否允许评论 
	const isAllow = ref(true)
	watch(() => isAllow.value,
		(newVal, oldVal) => {
			newVal ? topicForm.value.allow = 1 : topicForm.value.allow = 0
		}, {
			deep: true
		})

	// 添加图片
	const pathList = ref([]) //宠物照片数组
	const isOpImg = ref(false) //是否修改图片
	const optionImg = () => {
		const imgLen = pathList.value.length
		if (imgLen > 3) return;
		uni.chooseImage({
			count: 4 - imgLen, //可以选择多少张图片
			sizeType: ['original'],
			crop: {
				quality: 100, //图片质量,不填为80
				width: 400, //裁剪宽度
				height: 400, //裁剪高度
			},
			success: (res) => {
				//从相册或摄像头拿到图片临时路径及信息后进行判断
				//res.temFiles.size返回的单位为B 1KB=1024B
				if (res.tempFiles.size > 16 * 1024 * 1024) {
					uni.showToast({
						icon: 'none',
						title: "照片不能超过16M"
					})
					return
				}
				pathList.value.push(res.tempFilePaths[0])
				isOpImg.value = true;
				return
			},
		});
	}
	// 删除小图片
	const deleteimg = (i) => {
		pathList.value.splice(i, 1);
		isOpImg.value = true
	}

	// 获取初始呀草稿
	const infoTopic = async () => {
		const res = await getTopicDraft()
		topicForm.value = res.data.topic
		topicForm.value.allow == 1 ? isAllow.value = true : isAllow.value = false
		// 将网络图片转为本地图片
		res.data.picList.map(async item => {
			const path = await changeImgType(item)
			pathList.value.push(path.tempFilePath)
		})
		
	}

	const tapSaveTopic = async () => {
		if (topicForm.value.title == null  || topicForm.value.classify == null) {
			uni.showToast({
				icon: 'none',
				title: '请填完整内容'
			})
			return
		}

		await saveTopic(topicForm.value, isOpImg.value)
		pathList.value.map(async item => {
			await saveTopicPic(topicForm.value.id, item)
		})
		
		uni.navigateBack()
	}

	import {
		onShow
	} from '@dcloudio/uni-app'
	onMounted(() => {
		infoTopic()
	})
</script>

<template>
	<view class="addTopic-container">
		<view class="form-data">
			<!-- 标题 -->
			<input v-model.trim="topicForm.title" class="title" type="text" placeholder="标题&nbsp;吃饭睡觉打豆豆" />

			<view class="content">
				<!-- 内容 -->
				<textarea v-model.trim="topicForm.content" class="" placeholder="分享身边新鲜事"></textarea>
				<!-- 图片 -->
				<view class="imgbox clearfix">
					<view @tap="deleteimg(index)" v-for="(item,index) in pathList" :key="index" class="addimg">
						<image center :src="item"></image>
					</view>
					<view v-if="pathList.length<4" @tap="optionImg()" class="addimg iconfont">
						&#xe74b;
					</view>
				</view>
			</view>
			<!-- 选择话题 -->
			<view class="item">
				<text class="iconfont">&#xe76a;&nbsp;选择话题</text>
				<view @click="topicPicker.open()" class="iconfont" style="display: flex;">
					<input class="select_ipt" placeholder="请选择" v-model="topicForm.classify" disabled />
					&nbsp;&#xe8c4;
				</view>
				<uv-picker ref="topicPicker" :columns="topicColumns"
					@confirm="(e)=>topicForm.classify=e.value[0]"></uv-picker>
			</view>
			<!-- 是否允许评论 -->
			<view class="item">
				<text class="iconfont">&#xe768;&nbsp;{{topicForm.allow?'允许评论':'不许评论'}}</text>
				<view class="iconfont" style="display: flex;"><uv-switch v-model="isAllow"></uv-switch>
					&nbsp;&#xe8c4;</view>
			</view>
			<!-- 发布按钮 -->
			<view @tap="tapSaveTopic" class="addBtn">
				发布
			</view>
		</view>
	</view>
</template>

<style lang="scss" scoped>
	.addTopic-container {
		width: 100%;
		height: 100%;
		font-size: 28rpx;

		.form-data {
			padding: 0 30rpx;

			.title {
				height: 80rpx;
				line-height: 80rpx;
				border-bottom: 4rpx solid #ccc;
			}

			.content {
				position: relative;
				width: 100%;

				textarea {
					width: 100%;
					min-height: 320rpx;
					padding: 20rpx 0;
					box-sizing: border-box;
			
				}

				.imgbox {
					width: 100%;
					padding: 20rpx 0;
					border-bottom: 4rpx solid #ccc;

					.addimg {
						float: left;
						display: flex;
						justify-content: center;
						align-items: center;
						margin-left: 17rpx;
						width: 160rpx;
						height: 160rpx;
						font-size: 48rpx;
						border: 2rpx solid #ccc;
						box-sizing: border-box;

						image {
							width: 100%;
							height: 100%;
						}

						&:nth-child(4n+1) {
							margin-left: 0 !important;
						}
					}
				}
			}

			.item {
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 80rpx;
				border-bottom: 4rpx solid #ccc;

				.select_ipt {
					text-align: right;
				}
			}

			.addBtn {
				display: flex;
				justify-content: center;
				align-items: center;
				margin: 60rpx 30rpx 0;
				height: 80rpx;
				border-radius: 40rpx;
				background-color: #000;
				color: #fff;
				font-size: 32rpx;
				box-sizing: border-box;
			}
		}
	}

	// 清除浮动样式类
	.clearfix {
		zoom: 1;

		&::after {
			content: "";
			display: table;
			// 清除浮动
			clear: both;
		}

		&::before {
			content: "";
			display: table;
		}
	}
</style>