<script setup>
	import {
		onMounted,
		ref,
		getCurrentInstance,
		watch
	} from 'vue'
	// 获取屏幕边界到安全区域距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync()

	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	const userSore = useUserStore()


	import {
		updateProfilePic,
		updateProfile
	} from "@/services/mine.js"

	const fromData = ref({
		name: null,
		sex: null,
		password: null
	})

	// 点击保存按钮 保存信息
	const tapSaveProfile = async () => {
		if(fromData.value.name=='')fromData.value.name=null;
		if(fromData.value.password=='')fromData.value.password=null;
		const result = await updateProfile(fromData.value)
		if (result.code == 1) {
			userSore.setProfile(result.data)
		}
		uni.showToast({
			icon: "none",
			title: result.message
		})
	}
	
	const nameLength = ref(0)
	watch(() => fromData.value.name,
		(newVal, oldVal) => {
			let chineseCount = 0;
			for (let i = 0; i < newVal.length; i++) {
				if (isChinese(newVal.charAt(i))) {
					chineseCount++;
				}
			}
			// 计算英文字母和其他字符的数量
			let otherCount = newVal.length - chineseCount;
			// 计算总字节长度
			let byteLength = chineseCount * 2 + otherCount;
			// 判断是否符合要求
			nameLength.value = byteLength
		}, {
			deep: true
		})
		
		

	const isChinese = (char) => {
		const reg = /[\u4E00-\u9FA5]/;
		return reg.test(char);
	}
	
	
	
	// 点击头像图片修改头像
	const updataPic = () => {
		uni.chooseImage({
			count: 1,
			sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
			sourceType: ['album'], //从相册选择
			success: async function(res) {
				// 调用接口保存图片
				const result = await updateProfilePic(res.tempFilePaths[0])
				if (result.code == 1) {
					userSore.setProfile(result.data)
				}
				uni.showToast({
					icon: 'none',
					title: result.message
				})
			}
		})
	}
	
	

	import {
		onShow
	} from '@dcloudio/uni-app'
	onShow(() => {
		fromData.value.sex = userSore.profile.sex
		console.log(userSore.profile)
	})
</script>

<template>
	<view class="useehome_content">

		<!-- 主要区域 -->
		<view class="home_main">
			<!-- 头像模块 -->
			<view @tap="updataPic" class="profile-photo">
				<image :src="userSore.profile.pic" mode=""></image>
				<view class="pp-title">点击设置头像</view>
				<text class="iconfont">&#xe84a;</text>
			</view>
			<!-- 用户名字 -->
			<view class="item profile-name">
				用户昵称{{nameLength}}
				<input type="text"  v-model.trim="fromData.name" :placeholder="userSore.profile?.nickname"
					maxlength="12" />
			</view>
			<!-- 用户性别 -->
			<view class="item profile-sex">
				<text>用户性别</text>
				<view class="item-sex">
					<view @tap="fromData.sex='男'" :class="{active_Sex:fromData.sex=='男'}" class="iconfont boy">
						&#xe7a0;<text>男</text></view>
					<view @tap="fromData.sex='女'" :class="{active_Sex:fromData.sex=='女'}" class="iconfont girt">
						&#xe7a1;<text>女</text></view>
				</view>
			</view>
			<!-- 用户密码 -->
			<view class="item profile-password">
				<text>用户密码</text>
				<input style="height: 100%;" type="text" v-model.trim="fromData.password" placeholder="密码:字母+数字 6-16" maxlength="16" />
			</view>
		</view>

		<!-- 保存用户信息 -->
		<view class="footer" :style="{paddingBottom: safeAreaInsets.bottom+10+'rpx'}">
			<view @tap="tapSaveProfile" class="profile-save iconfont">
				&#xe84e;&nbsp;保存信息
			</view>
		</view>
	</view>
</template>

<style lang="scss">
	.useehome_content {
		display: flex;
		width: 100%;
		height: 100%;

		.home_main {
			position: relative;
			flex: 1;
			margin-top: 200rpx;

			border-radius: 30rpx 30rpx 0 0;
			background-color: #fff;
			box-shadow: rgba(0, 0, 0, 0.1) 0rpx -2rpx 2rpx 2rpx;

			.profile-photo {
				position: absolute;
				top: 0;
				left: 50%;
				transform: translate(-50%, -50%);
				width: 200rpx;
				height: 200rpx;
				border-radius: 50%;

				image {
					width: 100%;
					height: 100%;
					border-radius: 50%;
					border: 2rpx solid #ccc;
				}

				.pp-title {
					width: 100%;
					text-align: center;
					font-size: 28rpx;
					color: #999;
				}

				.iconfont {
					display: flex;
					justify-content: center;
					align-items: center;
					position: absolute;
					bottom: 0;
					right: 0;
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
					background: -webkit-linear-gradient(left, #fbf620, #9de610);
				}
			}

			.item {
				margin-top: 50rpx;
				padding: 0 40rpx;
				display: flex;
				justify-content: space-between;
				font-size: 36rpx;
				font-weight: 700;

				input {
					text-align: right;
					font-weight: 400;
				}

				// 用户性别
				.item-sex {
					display: flex;
					align-items: center;

					view {
						display: flex;
						align-items: center;
						padding: 16rpx 32rpx;
						border-radius: 10rpx;
						font-size: 24rpx;

						text {
							color: #000;
							margin-left: 15rpx;
						}
					}

					.boy {
						color: #34a2e5;
						margin-right: 10rpx;

					}

					.girt {
						color: #e2759f;
					}

					// 宠物性别选择样式
					.active_Sex {
						background-color: #f0f0f0;
					}
				}
			}

			.profile-name {
				margin-top: 200rpx;
			}
		}

		// 底部保存信息按钮
		.footer {
			position: fixed;
			bottom: 0;
			left: 0;
			padding: 10rpx 30rpx 0;
			width: 100%;
			background-color: #fff;
			box-shadow: rgba(0, 0, 0, 0.4) 0 -2rpx 6rpx 0;
			box-sizing: border-box;

			.profile-save {
				display: flex;
				justify-content: center;
				align-items: center;
				height: 80rpx;
				border-radius: 40rpx;
				background-color: #000;
				color: #fff;
				font-size: 32rpx;
			}
		}
	}

	// 清除浮动
	.clearfix:after,
	.clearfix:before {
		content: "";
		display: table;
	}

	.clearfix:after {
		clear: both;
	}

	.clearfix {
		zoom: 1;
	}
</style>