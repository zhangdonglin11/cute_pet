<script setup>
	import {
		onMounted,
		ref
	} from 'vue';
	import {
		getAnimal
	} from '@/services/common.js'


	const indexList = ref([])
	const itemArr = ref([])

	// 接收页面参数
	const query = defineProps({
		petType: Number
	})

	const selectCell = (cell) => {
		// 在列表页面中选择数据后发送事件
		uni.$emit('selectedData', cell);
		uni.navigateBack()
	}

	onMounted(async () => {
		let animal = ''
		if (query.petType == 1) {
			animal = 'catList'
		} else {
			animal = 'dogList'
		}
		const res = await getAnimal(animal)
		indexList.value = res.map(item => item.letter)
		itemArr.value = res.map(item => item.data)
	})
</script>

<template>
	<view>

		<uv-index-list :index-list="indexList" customNavHeight="100rpx">

			<template v-for="(item, index) in itemArr">
				<!-- #ifdef APP-NVUE -->
				<uv-index-anchor :text="indexList[index]"></uv-index-anchor>
				<!-- #endif -->
				<uv-index-item>
					<!-- #ifndef APP-NVUE -->
					<uv-index-anchor :text="indexList[index]"></uv-index-anchor>
					<!-- #endif -->
					<view class="list-cell" v-for="(cell, index) in item" @tap="selectCell(cell)">
						{{cell}}
					</view>
				</uv-index-item>
			</template>
		</uv-index-list>
	</view>
</template>

<style lang="scss" scoped>
	.list-cell {
		/* #ifndef APP-PLUS */
		display: flex;
		box-sizing: border-box;
		width: 100%;
		/* #endif */
		padding: 10px 24rpx;
		overflow: hidden;
		color: #323233;
		font-size: 14px;
		line-height: 24px;
		background-color: #fff;
	}
</style>