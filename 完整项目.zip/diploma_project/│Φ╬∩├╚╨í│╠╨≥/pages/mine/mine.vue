<script setup>
	import MyPet from './components/MyPet.vue'
	import LikePet from './components/LikePet.vue'
	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	import {
		ref
	} from 'vue';


	const menuButtonInfo = uni.getMenuButtonBoundingClientRect();
	const userStore = useUserStore();

	// 公告轮播信息
	const text = ref('在网络上与他人交流时，要保持礼貌和尊重。避免使用侮辱、攻击或恶意诋毁的言辞,拒绝传播违法、暴力、色情等不良信息，共同营造一个健康、积极的网络环境')

	// 我的宠物和收藏宠物模块
	const navtodo = ref(true)

	const myPetRef = ref()

	const likePetRef = ref()

	// 编辑信息和退出登录模块
	// 编辑
	const goUserEditor = () => {
		uni.navigateTo({
			url: '/pages/mine/UserEditor/UserEditor'
		})
	}
	// 退出
	const exitModal = ref()
	const confirm = () => {
		exitModal.value.close()
		userStore.clearProfile()
		uni.navigateTo({
			url: '/pages/login/login'
		})
	}

	import {
		onLoad,
		onShow
	} from "@dcloudio/uni-app"
	onShow(() => {
		myPetRef?.value?.infoMyPet()
		likePetRef?.value?.infoLikePet()
	})
</script>

<template>
	<view class="mine_content">
		<!-- 个人信息区域 -->
		<view class="mine_header" :style="{marginTop:menuButtonInfo.bottom+'px'}">
			<view class="profile-left">
				<image :src="userStore.profile.pic"></image>
			</view>
			<view class="profile-content">
				<view class="profile-name">{{userStore.profile.nickname}}</view>
				<view class="iconfont" :style="{color:userStore.profile.sex == '男'? '#1daaf8;':'#ef6da0;'}" style="margin-top: 20rpx;">
					{{userStore.profile.sex == '男'?'&#xe7a0;':'&#xe7a1;'}}
				</view>
			</view>
			<view class="profile-right iconfont">
				<view @tap="goUserEditor" class="right-item">
					&#xe621;&nbsp;编辑资料
				</view>
				<view @tap="exitModal.open()" class="right-item" style="margin-top: 20rpx;">
					&#xe8b6;&nbsp;退出登录
				</view>
			</view>
		</view>
		<!-- 退出登录弹窗 -->
		<uv-modal ref="exitModal" title='是否退出登录' @confirm="confirm" width="500rpx">
			<template v-slot:confirmButton style="display: flex;">
				<button type="default" @click="confirm" style="flex: 1;">确定</button>
				<button type="default" @click="exitModal.close()" style="flex: 1;">取消</button>
			</template>
		</uv-modal>


		<!-- 主要区域 -->
		<view class="mine_main">
			<!-- 公告消息 -->
			<view class="message">
				<uv-notice-bar :text="text" mode="closable" speed="50"
					url="/pages/componentsB/tag/tag"></uv-notice-bar>
			</view>
			<view class="mine_nav">
				<view class="nav" :class="{'active':navtodo}" @tap="navtodo = true">我的宠物</view>
				<view class="nav" :class="{'active':!navtodo}" @tap="navtodo = false">我的收藏</view>
			</view>

			<!-- 宠物卡片展示模块 -->
			<MyPet ref="myPetRef" v-if="navtodo" :uid="userStore?.profile.id" />
			<LikePet ref="likePetRef" v-if="!navtodo" :uid="userStore?.profile.id" />
		</view>
	</view>
</template>

<style lang="scss" scoped>
	@import "@/static/fonts/iconfont.css";

	.mine_content {
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		background: -webkit-linear-gradient(left, #DFF0EF, #F4F8D5);

		.mine_header {
			display: flex;
			align-items: center;
			padding: 30rpx 40rpx;
			width: 100%;
			box-sizing: border-box;

			.profile-left {
				width: 160rpx;
				height: 160rpx;
				border-radius: 80rpx;
				overflow: hidden;

				image {
					width: 100%;
					height: 100%;
					background-color: chartreuse;
				}
			}

			.profile-content {
				flex: 1;
				font-weight: 700;
				padding: 0 20rpx;
				height: 120rpx;
				box-sizing: border-box;
				
				.profile-name {
					width: 300rpx;
					font-size: 40rpx;
					white-space: nowrap;
					/* 防止换行 */
					overflow: hidden;
					/* 隐藏超出部分 */
					text-overflow: ellipsis;
					/* 超出部分显示省略号 */
					
				}
				
			}

			.profile-right {
				padding: 0 10rpx;
				width: 170rpx;
				font-size: 20rpx;
				box-sizing: border-box;

				.right-item {
					display: flex;
					justify-content: center;
					align-items: center;
					height: 50rpx;
					border-radius: 30rpx;
					background-color: #000;
					color: #fff;
				}
			}

		}

		.mine_main {
			flex: 1;
			padding: 30rpx;
			border-radius: 40rpx 40rpx 0 0;
			box-sizing: border-box;
			background-color: #ffffff;
			box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
				rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;


			.message {}

			.mine_nav {
				padding: 30rpx 0;
				display: flex;
				align-items: center;
				font-size: 36rpx;


				.nav {
					margin-right: 40rpx;
				}

				.active {
					font-size: 40rpx;
					font-weight: 700;
					border-bottom: 2px solid #faf442;
					box-sizing: border-box;
				}
			}

			// 宠物主页
			.pet_home_content {
				.add_btn {
					margin-top: 40rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					height: 100rpx;
					border-radius: 60rpx;
					background-color: #000000;
					color: #ffffff;
				}
			}

			// 点赞
			.my_like_content {
				width: 100%;
				box-sizing: border-box;

				.pet_item {
					float: left;
					position: relative;
					float: left;
					margin-top: 30rpx;
					margin-right: 30rpx;
					padding: 20rpx;
					width: 330rpx;
					border-radius: 20rpx;
					box-sizing: border-box;
					box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
						rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;

					&:nth-child(-n+2) {
						margin-top: 0;
					}

					&:nth-child(even) {
						margin-right: 0;
					}

					.item_pet_prc {
						position: relative;
						width: 290rpx;
						height: 290rpx;
						box-sizing: border-box;

						image {
							border-radius: 10rpx;
						}

						.item_like {
							position: absolute;
							bottom: 10rpx;
							right: 10rpx;
							display: flex;
							justify-content: center;
							align-items: center;
							padding: 12rpx 20rpx;
							font-size: 20rpx;
							border-radius: 44rpx;
							background-color: rgba(0, 0, 0, 0.2);
							transform: scale(.8);

							.iconfont {}

							text {
								margin-left: 10rpx;
							}
						}

					}

					.item_pet_name {
						margin-top: 20rpx;


					}
				}
			}
		}
	}
</style>