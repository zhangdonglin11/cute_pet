<script setup>
	import {
		ref
	} from 'vue'
	const props = defineProps({
		petObj: Object,
		pet: Object,
	})

	const unfold = ref(false)

</script>

<template>
	<view class="pet_card">
		<view class="information" @tap="$emit('tapHandlePet',props.petObj)">
			<view class="pet_left">
				<image v-if="props.petObj.pet.petType===1" src="@/static/image/mao.png" mode="aspectFit"
					style="margin-top: 10rpx;"></image>
				<image v-if="props.petObj.pet.petType===2" src="@/static/image/gou.png" mode="aspectFit"></image>
				<view class="iconfont boy" v-if="props.petObj.pet.petSex == '弟弟'">
					&#xe7a0;
				</view>
				<view class="iconfont girt" v-if="props.petObj.pet.petSex == '妹妹'">
					&#xe7a0;
				</view>
			</view>
			<view class="pet_right">
				<view class="p_top">
					<view class="p_name">{{props.petObj.pet.petNick}}</view>
					<view class="address">
						<view class="iconfont">&#xe874;</view>{{props.petObj.pet.petAddress}}
					</view>
				</view>
				<view class="p_botton">
					<view class="tag" v-if="props.petObj.pet.petVariety !==''">
						{{props.petObj.pet.petVariety}}
					</view>
					<view class="tag" v-if="props.petObj.pet.petAge !==''">
						{{props.petObj.pet.petAge}}
					</view>
					<view class="tag">
						{{props.petObj.pet.petStatus}}
					</view>
				</view>
			</view>
		</view>
		<!-- 展开模块 -->
		<view class="letter" v-show="unfold">
			{{props.petObj.pet.petOwner}}
		</view>
		<view class="open_btn iconfont" @click="unfold= !unfold" v-if="props.petObj.pet.petOwner">
			{{unfold?'收起&#xe8e2;':'展开&#xe7a4;'}}
		</view>
	</view>
</template>

<style lang="scss" scoped>
	.pet_card {
		padding: 30rpx 30rpx 50rpx;
		margin-bottom: 20rpx;
		width: 100%;
		background-color: #ebff7c;
		border-radius: 30rpx;
		font-size: 24rpx;
		box-sizing: border-box;
		box-shadow: rgba(0, 0, 0, 0.05) 0px 0px 4px 0px,
			rgba(0, 0, 0, 0.08) 0px 0px 4px 1px;

		.information {
			margin: 10rpx 0;
			display: flex;

			.pet_left {
				position: relative;
				width: 120rpx;
				height: 120rpx;
				border-radius: 50%;
				background-color: #fff;
				display: flex;
				justify-content: center;
				align-items: center;

				image {
					width: 80%;
					height: 80%;
				}

				view {
					position: absolute;
					bottom: 0;
					right: 0;
					width: 30rpx;
					height: 30rpx;
					line-height: 30rpx;
					text-align: center;
					font-size: 16rpx;
					border-radius: 50%;
					color: #fff;
				}

				.boy {
					background-color: #34a2e5;
					margin-right: 10rpx;

				}

				.girt {
					background-color: #e2759f;
				}
			}

			.pet_right {
				flex: 1;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				margin-left: 30rpx;

				.p_top {
					display: flex;
					justify-content: space-between;

					.p_name {
						font-size: 36rpx;
						font-weight: 700;
					}

					.address {
						display: flex;

					}

				}

				.p_botton {
					display: flex;

					.tag {
						border-radius: 30rpx;
						margin-right: 10rpx;
						padding: 4rpx 14rpx;
						background-color: #fefefe;
						box-sizing: border-box;

						&:last-child {
							background: -webkit-linear-gradient(left, #b4febf, #d6ffb0);
						}
					}

				}
			}
		}

		.letter {
			margin-top: 20rpx;
			padding: 14rpx 20rpx;
			border-radius: 14rpx;
			font-size: 24rpx;
			word-wrap: break-word;
			background-color: #ffffff;
		}

		.open_btn {
			position: absolute;
			margin-top: 14rpx;
			left: 50%;
			transform: translateX(-50%);
			text-align: center;
			font-size: 20rpx;

			.iconfont {
				font-size: 20rpx;
			}
		}


	}
</style>