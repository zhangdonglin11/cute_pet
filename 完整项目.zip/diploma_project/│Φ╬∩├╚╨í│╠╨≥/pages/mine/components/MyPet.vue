<script setup>
	import MyPetCard from './MyPetCard.vue'
	import {
		getMyPet,
	} from '@/services/mine.js'
	import {
		onMounted,
		ref
	} from 'vue';
	const props = defineProps({
		uid: Number,
		noAdd:Boolean
	})

	const petArr = ref()
	const infoMyPet = async () => {
		const res = await getMyPet(props.uid)
		petArr.value = res.data
	}

	// 传宠物信息对象去宠物主页
	const gotoPetDetail = (petObj) => {
		uni.navigateTo({
			url: `/pages/mine/PetHomePage/PetHomePage`,
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendPetHome', petObj)
			}
		})
	}

	const addPet = () => {
		uni.navigateTo({
			url: '/pages/mine/PetEditor/PetEditor?isAdd=true'
		})
	}

	// 暴露组件的属性和方法
	defineExpose({
		infoMyPet
	})

	onMounted(() => {
		infoMyPet()
	})
</script>

<template>
	<view class="my-pet-container">
		<view style="max-height: 740rpx;transform: translate3d(0, 0, 0);overflow-y: scroll;">
			<!-- 宠物卡片 -->
			<MyPetCard v-for="item in petArr" :key="item.pet.id" 
			:petObj="item" @tapHandlePet="gotoPetDetail"></MyPetCard>
		</view>
		
		<!-- 添加宠物 创建档案 -->
		<button v-if="!props.noAdd" class="add_btn iconfont" @click="addPet()" >
			&#xe8b3;
			<text style="margin-left: 20rpx;">创建档案</text>
		</button>
	</view>
</template>

<style lang="scss" scoped>
	.my-pet-container {
		.add_btn {
			display: flex;
			align-items: center;
			justify-content: center;
			height: 90rpx;
			border-radius: 45rpx;
			background-color: #000;
			color: #fff;
			font-size: 32rpx
		}
	}
</style>