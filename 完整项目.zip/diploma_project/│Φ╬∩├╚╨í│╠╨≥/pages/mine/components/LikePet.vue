<script setup>
	import LikePetCard from '@/pages/mine/components/LikePetCard.vue'
	import {
		getLikePet
	} from '@/services/mine.js'
	import {
		onMounted,
		ref
	} from 'vue';
	const props = defineProps({
		uid: Number
	})

	const petArr = ref()

	const infoLikePet = async () => {
		const res = await getLikePet(props.uid)
		petArr.value = res.data
	}


	// 暴露组件的属性和方法
	defineExpose({
		infoLikePet
	})

	onMounted(() => {
		infoLikePet()
	})
</script>

<template>
	<view class="like-pet-container">
		<LikePetCard v-for="(item,index) in petArr" :key="item.pet.id" :petObj="item"
			@tapHandlePet="gotoPetDetail(item)" />
		<view v-if="petArr==''">
			还没有喜欢的宠物呀，首页找找吧！
		</view>
	</view>
</template>

<style lang="scss">
	.like-pet-container {
		width: 100%;
		display: flex;
		flex-wrap: wrap;

		like-pet-card {
			margin-top: 30rpx;
			margin-right: 30rpx;

			&:nth-child(2n) {
				margin-right: 0;
			}

			&:nth-child(-n+2) {
				margin-top: 0;
			}
		}
	}
</style>