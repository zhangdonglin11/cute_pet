<script setup>
	import PetContent from '@/components/PetContent.vue'
	import PetLikeButton from '@/components/PetLikeButton.vue'
	import {
		ref,
		defineExpose,
		reactive,
		onMounted
	} from "vue"

	import {
		getFiltratePet
	} from '@/services/homeAPI.js'
	import {
		getPet,
		likePet,
		savePetComment
	} from '@/services/mine.js'


	// 宠物列表
	const petArr = ref(0)
	// 筛选条件
	let condition = {
		petType: '',
		address: '',
		state: '',
		sex: '',
		age: '',
		current: 1, // 查询页数
		size: 5, // 查询条数
		pages: 1, //总页数
	}

	// 轮播控制
	const leftIndex = ref(-1)
	const centerIndex = ref(0)
	const rightIndex = ref(1)
	// 切换宠物
	const nextPet = async () => {
		if (centerIndex.value < petArr.value.length - 1) {
			// 最后一页就不可以下一个了
			leftIndex.value++
			centerIndex.value++
			rightIndex.value++
		} else {
			uni.showToast({
				icon: 'none',
				title: "没有更多了"
			})
		}
		// 在展示倒数第三个就发起更多的宠物的请求
		if (centerIndex.value > petArr.value.length - 3) {
			// 获取新的数据
			// 查询下一页
			condition.current++;
			if (condition.current > condition.pages) return;
			const result = await getFiltratePet(condition)
			petArr.value.push(...result.data.petArr)
			condition.pages = result.data.pages
			console.log(result)
		}
	}

	// 相认识他按钮功能
	import {
		getChat
	} from "@/services/informAPI.js"

	const myChatList = ref(0)
	const tapMakingFriends = async (anotherId) => {
		const result = await getChat(anotherId)
		myChatList.value = result.data
		console.log(result)
		if (result.code == 1) {
			// 去对话页面
			uni.navigateTo({
				url: '/pages/inform/Dialogue/Dialogue',
				success: function(res) {
					// 通过eventChannel向被打开页面传送数据
					res.eventChannel.emit('sendDialogue', myChatList.value)
				},
				animationDuration: 1000
			})
			return
		}
		uni.showToast({
			icon: "none",
			title: result.message
		})
	}


	// 筛选请求
	const filtrate = async (val) => {
		// 重置筛选
		petArr.value = ''
		leftIndex.value = -1
		centerIndex.value = 0
		rightIndex.value = 1
		condition = {
			...val,
			current: 1, // 查询页数
			size: 5,
		}
		const result = await getFiltratePet(condition)
		petArr.value = result.data.petArr
		condition.pages = result.data.pages
	}

	// 获取宠物的信息
	const infoPet = async () => {
		const res = await getPet(petArr.value[centerIndex.value].pet.id)
		console.log(res);
		if (res.code == 1) {
			petArr.value[centerIndex.value] = res.data
		} else {
			uni.showToast({
				icon: "none",
				title: res.message
			})
		}
	}

	// 点赞收藏
	const tapLike = async () => {
		const result = await likePet(petArr.value[centerIndex.value].pet.id)
		infoPet()
	}
	// end

	// 评论区域 start
	const iptPopup = ref()
	const iptText = ref('说点什么吧...')
	const formData = ref({
		content: '', //品论内容
		petId: 1, // 宠物id
		level: 0, // 品论层级 0根 1回复0 2回复1\2
		parentId: '', //回复目标的id，没有则null
		rootId: '' // 根品论id 
	})
	// 根评论方法 
	const rootComment = () => {
		console.log("111")
		iptPopup.value.open()
		iptText.value = '说点什么吧...';
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.petId = petArr.value[centerIndex.value].pet.id
		formData.value.level = 0;
		formData.value.parentId = '';
		formData.value.rootId = ''
		console.log(petArr.value[centerIndex.value].pet.id)
	}
	// 其他评论
	const OtherComment = (val) => {
		iptPopup.value.open()
		iptText.value = '回复 ' + val.nickName;
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.petId = petArr.value[centerIndex.value].pet.id
		formData.value.level = val.level;
		formData.value.parentId = val.parentId;
		formData.value.rootId = val.rootId
		console.log(val.level)
		console.log(val.level)
	}
	// 提交评论
	const SubmintPetComment = async (val) => {
		if (val.content == '') {
			return
		}
		console.log(val)
		const res = await savePetComment(val);
		uni.showToast({
			icon: 'none',
			title: res.message
		})
		// 更新页面信息
		infoPet()
		// 关闭评论输入框
		iptPopup.value.close()
	}
	// 评论 end 

	// 监听scroll显示隐藏换一个的按钮
	const isShow = ref(true)




	// 暴露组件的属性和方法
	defineExpose({
		filtrate
	})
	onMounted(async () => {
		const result = await getFiltratePet(condition)
		petArr.value = result.data.petArr
		condition.pages = result.data.pages
	})
</script>

<template>
	<view class="swiper_content">
		<view class="item_box">
			<view class="item"
				:class="[{center: index==centerIndex},{left: index==leftIndex},{right: index==rightIndex}]"
				v-for="(item,index) in petArr" :key="index">
				<PetContent @parentScroll="(val)=>isShow=val" @handleRootComment="rootComment()"
					@handleOtherComment="OtherComment" :pet="item.pet" :pic="item.pic" :petComment="item.petComment" />
			</view>

			<!--底部控制切换  -->
			<!-- v-if="isShow" -->
			<view class="footer_btn" v-if="isShow">
				<view class="btn next iconfont" @tap="nextPet">
					&#xe8ba;&nbsp;换一个
				</view>
				<view @tap="tapMakingFriends(petArr[centerIndex]?.pet.userId)" class="btn making_friends iconfont">
					&#xe8a5; &nbsp;想认识Ta
				</view>
			</view>

			<!-- 点赞/评论 区域 start -->
			<view class="right-button">
				<PetLikeButton v-if="petArr[centerIndex]?.pet" @hendleLike="tapLike()" @hendleComment="rootComment()"
					:petLike="petArr[centerIndex]?.petLike" :commentCount="petArr[centerIndex]?.petComment.count" />
			</view>
			<!-- 点赞/评论 区域 end -->
			
			<view class="home-tips">
				<text>暂时没有该条件的宠物</text>
				<text>换一些条件试试吧！</text>
			</view>
		</view>
		<!-- 评论弹出层 -->
		<uv-popup ref="iptPopup" mode="bottom" bgColor="none" :overlayStyle="{background: 'rgba(0,0,0,0)'}"
			style="z-index: 100;" :safeAreaInsetBottom="false">
			<view class="popup-box">
				<input class="ipt" type="text" :placeholder="iptText" maxlength="140" v-model.trim="formData.content"
					@confirm="SubmintPetComment(formData)" />
			</view>
		</uv-popup>
	</view>
</template>



<style lang="scss" scoped>
	// 组件轮廓
	.swiper_content {
		position: relative;
		width: 100%;
		padding: 0 30rpx;
		box-sizing: border-box;
		transform-style: preserve-3d;

		.item_box {
			position: relative;
			width: 100%;
			height: 1080rpx;
			box-sizing: border-box;

			.item {
				position: absolute;
				width: 100%;
				height: 100%;
				padding: 30rpx 30rpx;
				border-radius: 30rpx 30rpx 0 0;
				left: 0;
				transform: scale(0.8);
				z-index: 3;
				background-color: #fff;
				box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
					rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;
				box-sizing: border-box;
				visibility: visible;
			}


			.left {
				left: -110%;
				transform: scale(1);
				z-index: 6;
				transition: all 0.8s ease;
				visibility: visible;
			}

			.center {
				visibility: visible;
				z-index: 5;
				left: 0;
				top: 0;
				bottom: 10%;
				transform: scale(1) !important;
				transition: all 0.8s ease;

			}

			.right {
				left: 0;
				transform: scale(0.8);
				z-index: 4;
				transition: all 1s ease;
				// transition-delay: 1s;
				visibility: visible;
			}

		}
	}


	// 底部切换
	.footer_btn {
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		display: flex;
		align-items: center;
		box-sizing: border-box;
		color: #000;
		z-index: 10;

		.btn {
			flex: 1;
			display: flex;
			align-items: center;
			justify-content: center;
			margin: 30rpx 10rpx;
			height: 80rpx;
			border-radius: 40rpx;
			box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 4px 2px;
		}

		.next {
			background-color: #fff;

		}

		.making_friends {
			background: -webkit-linear-gradient(left, #ebff7c, #fcf239);
		}
	}

	// 点赞
	.right-button {
		position: fixed;
		right: 25rpx;
		top: 40%;
		z-index: 100;
	}


	.home-tips {
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	// 评论弹出
	.popup-box {
		height: 400rpx;
		padding: 10rpx 60rpx 0;
		box-sizing: border-box;
		background-color: #fff;
		z-index: 100;

		.ipt {
			padding: 0 30rpx;
			height: 60rpx;
			border-radius: 60rpx;
			background-color: #e0e0e0;
		}
	}
</style>