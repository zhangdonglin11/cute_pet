<script setup>
	import CustomNavbar from './components/CustomNavbar.vue'
	import PetSwiper from './components/PetSwiper.vue'
	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	import {
		ref
	} from 'vue';
	// 获取PetSwiper组件的实例，可以父组件调用子组件的方法
	const petRef = ref()
</script>


<template>
	<view class="viewport">
		<!-- 筛选模块 -->
		<CustomNavbar @handleFiltrate="petRef?.filtrate" />
		<!-- 宠物轮播图展示 -->
		<PetSwiper ref="petRef" />
	</view>
</template>

<style lang="scss">

	.viewport {
		position: relative;
		height: 100%;
		background: linear-gradient(to top, #fff 60%, transparent);
	}
</style>