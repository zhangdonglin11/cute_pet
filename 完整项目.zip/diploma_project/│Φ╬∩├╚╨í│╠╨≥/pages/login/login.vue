<script setup>
	import HanderNav from '@/components/HanderNav.vue'
	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	import {
		getPhoneCode,
		loginCode,
		login
	} from '@/services/login.js'
	import {
		reactive,
		ref,
		getCurrentInstance
	} from 'vue';
	// 获取实例
	const instance = getCurrentInstance();

	const isCode = ref(true)

	const formModel = ref({
		mobile: '13169197359',
		password: 'a123456',
		code: ''
	})

	const rules = ref({
		mobile: [{
			required: true,
			message: '请输入电话号码',
			// blur和change事件触发检验
			trigger: ['blur', 'change']
		}, {
			// 自定义验证函数，见上说明，注意这里面的逻辑不能出现语法报错，否则可能导致不验证
			validator: (rule, value, callback) => {
				// 此处业务逻辑省略
				const reg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/; // 正则表达式
				if (!reg.test(value)) { // 如果不符合要求
					return false // 返回错误信息
				} else {
					return true; // 校验通过
				}
				// 返回true表校验通过，返回false表示不通过
			},
			message: '电话号码格式错误',
			trigger: ['blur', 'change']
		}],
		password: [{
			required: true,
			message: '密码不能为空',
			// blur和change事件触发检验
			trigger: ['blur', 'change']
		}, {
			// 自定义验证函数，见上说明，注意这里面的逻辑不能出现语法报错，否则可能导致不验证
			validator: (rule, value, callback) => {
				// 此处业务逻辑省略
				const reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/; // 正则表达式
				if (!reg.test(value)) { // 如果不符合要求
					return false // 返回错误信息
				} else {
					return true; // 校验通过
				}
				// 返回true表校验通过，返回false表示不通过
			},
			message: '密码：字母+数字 6-16',
			trigger: ['blur', 'change']
		}],
	})

	// 短信登录
	const codeSubmit = () => {
		instance.refs["form"].validate().then(async res => {
			// 验证码登录
			if (formModel.value.code.length == 4) {
				// 发起验证码登录请求
				const result = await loginCode(formModel.value.mobile, formModel.value.code)
				if (result.code == 1) {
					useUserStore().setProfile(result.data)
					uni.showToast({
						icon: "none",
						title: result.message
					})
					uni.navigateBack()
				} else {
					useUserStore().clearProfile()
					uni.showToast({
						icon: "none",
						title: result.message
					})
				}
			} else {
				uni.showToast({
					icon: "none",
					title: '请输入完整的验证码'
				})
			}
		})
	}

	// 密码登录
	const passwordSubmit = () => {
		instance.refs["form"].validate().then(async res => {
			// 验证码登录
			const result=await login(formModel.value.mobile,formModel.value.password)
			if(result.code){
				useUserStore().setProfile(result.data)
				uni.navigateBack()
			}
			uni.showToast({
				icon: "none",
				title: result.message
			})
		})
	}

	// 重置
	const reset = () => {
		form.resetFields();
		form.clearValidate();
	}


	// 验证码区域
	const tips = ref('')
	const seconds = ref(10)
	const codeChange = (text) => {
		tips.value = text;
	}
	const getCode = () => {
		if (instance.refs["code"].canGetCode) {
			instance.refs["form"].validate().then(async res => {
				uni.showLoading({
					title: '正在获取验证码'
				})
				// 手机号正确才可以发请求
				// 模拟向后端请求验证码
				const result = await getPhoneCode(formModel.value.mobile)

				setTimeout(() => {
					if (result.code == 1) {
						uni.hideLoading();
						// 这里此提示会被this.start()方法中的提示覆盖
						uni.$uv.toast(result.message);
						// 通知验证码组件内部开始倒计时
						instance.refs["code"].start();
					} else {
						uni.hideLoading();
						// 这里此提示会被this.start()方法中的提示覆盖
						uni.$uv.toast(result.message);
					}
				}, 2000);
			}).catch(errors => {
				uni.showToast({
					icon: 'error',
					title: '请输入正确的电话号码'
				})
			})
		} else {
			uni.$uv.toast('倒计时结束后再发送');
		}
	}
</script>

<template>
	<view class="container">
		<HanderNav></HanderNav>
		
		<view class="login_box">
			<view style="margin-top: 120rpx;font-size: 42rpx;">
				欢迎来到宠物萌社区
			</view>
			<view class="box-herader">
				{{isCode? '短信登录':'密码登录'}}
			</view>

			<!-- 验证码登录 -->
			<template v-if="isCode">
				<uv-form :model="formModel" :rules="rules" ref="form" labelAlign="right">
					<view style="height: 80px;box-sizing: border-box">
						<uv-form-item label="电话:" prop="mobile" labelWidth="70px">
							<uv-input v-model.trim="formModel.mobile" maxlength="11" placeholder="请输入电话" border="bottom"
								fontSize="20px" />
						</uv-form-item>
					</view>
					<view class="code">
						验证码：
						<input v-model="formModel.code" type="number" maxlength="4" />
						<!-- 验证码区域 -->
						<view class="wrap">
							<uv-toast ref="toast"></uv-toast>
							<uv-code :seconds="seconds" ref="code" @change="codeChange"></uv-code>
							<uv-button @tap="getCode">{{tips}}</uv-button>
						</view>
					</view>
				</uv-form>
				<view class="btn" style="background-color:#07c160;" @tap="codeSubmit">
					登录
				</view>
			</template>

			<!-- 短信登录 -->
			<template v-if="!isCode">
				<uv-form :model="formModel" :rules="rules" ref="form" labelAlign="right">
					<view style="height: 80px;box-sizing: border-box">
						<uv-form-item label="电话:" prop="mobile" labelWidth="70px">
							<uv-input v-model.trim="formModel.mobile" maxlength="11" placeholder="请输入电话" border="bottom"
								fontSize="20px" />
						</uv-form-item>
					</view>
					<view style="height: 80px;box-sizing: border-box">
						<uv-form-item label="密码:" prop="password" labelWidth="70px">
							<uv-input v-model="formModel.password" maxlength="16" placeholder="请输入密码" border="bottom"
								fontSize="20px" />
						</uv-form-item>
					</view>
				</uv-form>
				<view class="btn" style="background-color:#07c160;" @tap="passwordSubmit">
					登录
				</view>
			</template>

			<!-- 切换登录状态 -->
			<view style="text-align: center;">
				<text class="dx" @tap="isCode=!isCode">
					{{isCode? '密码登录':'短信登录'}}
				</text>
			</view>

		</view>
	</view>
</template>

<style lang="scss">
	.container {
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		background: -webkit-linear-gradient(left, #0dcda4, #c3fcd4);
		box-sizing: border-box;

		.login_box {
			flex: 1;
			margin-top: 100rpx;
			padding: 0rpx 60rpx;
			background-color: white;
			border-radius: 30rpx 30rpx 0 0;

			.box-herader {
				margin: 40rpx 0;
				font-size: 48rpx;
				text-align: center;

			}

			// 验证码区域
			.code {
				font-size: 20px;
				display: flex;
				padding-bottom: 20px;
				align-items: center;
				height: 80px;
				box-sizing: border-box;

				.title1 {
					margin: 0;
					padding: 0;
					width: 102px;
				}

				input {
					flex: 1;
					border-bottom: 2px #0dcda4 solid;
					text-align: center;
				}

				.wrap {
					margin-left: 10px;
					width: 120px;
				}

			}

			.btn {
				height: 80rpx;
				line-height: 80rpx;
				border-radius: 40rpx;
				text-align: center;
				margin-bottom: 30rpx;
				color: #fff;
			}

			.dx {
				height: 80rpx;
				line-height: 80rpx;
				text-align: center;
				color: #666;
			}
		}
	}
</style>