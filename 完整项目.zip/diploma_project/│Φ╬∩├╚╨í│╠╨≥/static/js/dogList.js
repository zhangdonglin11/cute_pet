export default {
	'list': [{
		'letter': 'A',
		'data': [
			'阿拉斯加犬',
			'爱斯基摩犬'
		]
	}, {
		'letter': 'B',
		'data': [
			'比熊犬',
			'博美犬 ',

		]
	},  {
		'letter': 'D',
		'data': [
			'斗牛犬 ',
			'德国牧羊犬',
			'大白熊犬'
		]
	}, {
		'letter': 'E',
		'data': [


		]
	}, {
		'letter': 'G',
		'data': [
			'贵宾犬',
			'蝴蝶犬'
		]
	}, {
		'letter': 'H',
		'data': [
			'哈士奇',
		]
	}, {
		'letter': 'J',
		'data': [
			'金毛',
			'吉娃娃'
		]
	}, {
		'letter': 'K',
		'data': [
			'昆明犬',
			'柯基犬'
		]
	}, {
		'letter': 'L',
		'data': [
			'拉布拉多',
			'罗威那犬'
		]
	}, {
		'letter': 'M',
		'data': [
			'柯基犬',
			'牧羊犬'
		]
	}, {
		'letter': 'R',
		'data': [
			'日本柴犬'
		]
	}, {
		'letter': 'S',
		'data': [
			'松狮犬',
			'萨摩耶',
			'圣伯纳犬',
			'沙皮中国犬',
			'苏牧'
		]
	}, {
		'letter': 'T',
		'data': [
			'泰迪犬',
		]
	},  {
		'letter': 'X',
		'data': [
			'西施犬',
			'雪纳瑞'
		]
	},  {
		'letter': 'Z',
		'data': [
			'中华田园犬',
		]
	}],
}