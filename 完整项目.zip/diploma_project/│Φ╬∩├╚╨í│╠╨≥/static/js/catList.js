export default {
	'list': [{
		'letter': 'B',
		'data': [
			'巴厘猫',
			'布偶猫',
			'波斯猫',
		]
	}, {
		'letter': 'C',
		'data': [
			'暹罗猫',
		]
	}, {
		'letter': 'E',
		'data': [
			'俄罗斯蓝猫',

		]
	}, {
		'letter': 'H',
		'data': [
			'华南虎斑',

		]
	}, {
		'letter': 'J',
		'data': [
			'金毛',
			'吉娃娃'
		]
	}, {
		'letter': 'K',
		'data': [
			'狸花猫',
		]
	}, {
		'letter': 'L',
		'data': [
			'蓝猫',
		]
	}, {
		'letter': 'M',
		'data': [
			'曼基康',
			'孟买猫',
		]
	}, {
		'letter': 'S',
		'data': [
			'苏格兰折耳猫',
		]
	}, {
		'letter': 'T',
		'data': [
			'唐老鸭猫',
		]
	}, {
		'letter': 'X',
		'data': [
			'小老虎猫',
		]
	}, {
		'letter': 'Y',
		'data': [
			'银渐层',
			'云南虎斑',
			'英国短毛猫',
		]
	}, {
		'letter': 'Z',
		'data': [
			'中华田园猫',
			'中华狸花猫',
			'中国虎斑猫',
			'中国山猫',
		]
	}],
}