// 获取全国省市区文件
export const getAdress = () => {
	return new Promise((resolve, reject) => {
		uni.request({
			url:'http://localhost:8088/js/regions.json',
			success(res) {
					resolve(res.data)
					console.log(res)
			},
			// 响应失败
			fail(err) {
				uni.showToast({
					icon: "none",
					title: "网络错误，换一个网络试试！2"
				})
				reject(err)
			}
		})
	})
}
// 获取猫狗品种文件
export const getAnimal = (Animal) => {
	return new Promise((resolve, reject) => {
		uni.request({
			url:`http://localhost:8088/js/${Animal}.json`,
			success(res) {
					resolve(res.data)
					console.log(res)
			},
			// 响应失败
			fail(err) {
				uni.showToast({
					icon: "none",
					title: "网络错误，换一个网络试试！2"
				})
				reject(err)
			}
		})
	})
}
// 网络图片转临时内存
export const changeImgType = (oldUrl) => {
	return uni.downloadFile({
		url: oldUrl,
	})
}



