class FillStylePattern {
    constructor(img, pattern) {
        this._style = pattern;
        this._img = img;
    }
}

export default FillStylePattern;