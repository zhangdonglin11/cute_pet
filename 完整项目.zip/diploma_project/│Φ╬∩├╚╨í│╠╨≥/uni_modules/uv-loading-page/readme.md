## LoadingPage 加载页

> **组件名：uv-loading-page**

该组件是一个页面级的加载效果，可以在页面初始化数据等场景使用，与骨架屏有相似之处。

### <a href="https://www.uvui.cn/components/loadingPage.html" target="_blank">查看文档</a>

### [完整示例项目下载 | 关注更多组件](https://ext.dcloud.net.cn/plugin?name=uv-ui)

#### 如使用过程中有任何问题，或者您对uv-ui有一些好的建议，欢迎加入 uv-ui 交流群：<a href="https://ext.dcloud.net.cn/plugin?id=12287" target="_blank">uv-ui</a>、<a href="https://www.uvui.cn/components/addQQGroup.html" target="_blank">官方QQ群</a>
