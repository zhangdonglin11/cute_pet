<script setup>
	import {
		ref
	} from 'vue';
	import {
		useUserStore
	} from '@/stores/useUserStore.js'

	const userStore = useUserStore();


	const props = defineProps({
		pet: Object,
		pic: Array,
		petComment: Object,
		goId: Number
	})

	const getTimer = (ot) => {
		let newtime = new Date();
		let oldtime = new Date(ot);
		let diff = newtime.getTime() - oldtime.getTime();
		let diffInMinutes = diff / (1000 * 60); // 将毫秒转换为分钟
		let diffInHour = diff / (1000 * 60 * 60);
		let diffInDay = diff / (1000 * 60 * 60 * 24);
		if (diffInMinutes.toFixed(2) < 60) {
			return Math.floor(diffInMinutes) + '分钟前';
		} else if (diffInHour < 24) {
			return Math.floor(diffInHour) + '小时前';
		} else {
			return Math.floor(diffInDay) + '天前';
		}
	}

	const emit = defineEmits(['handleRootComment', 'handleOtherComment', 'parentScroll'])
	const handleScroll = (e) => {
		uni.$uv.debounce(function() {
			if (e.target.scrollTop > 10) {
				emit("parentScroll", false)
			} else {
				emit("parentScroll", true)
			}
		}, 300)
	}
	// 举报
	import {reportPet} from '@/services/mine.js'
	const tapReportPet =async (pid)=>{
		const result=await reportPet(pid)
		if(result.code){
			uni.showToast({
				icon:'none',
				title:"举报成功"
			})
		}
	}
	import {reportComment} from '@/services/mine.js'
	const tapReportComment =async (pid)=>{
		const result=await reportComment(pid)
		if(result.code){
			uni.showToast({
				icon:'none',
				title:"举报成功"
			})
		}
	}
	// 前往用户主页
	const gotoUserHome=(userId)=>{
		// console.log(userId)
		uni.navigateTo({
			url:`/pages/mine/UserHome/UserHome?userId=${userId}`
		})
	}
</script>

<template>
	<scroll-view :scroll-into-view="'p'+props.goId" @scroll="handleScroll" scroll-y class="box-container">
		<!-- <view class="box-container"> -->
		<view class="detail_container">
			<!-- 举报按钮 -->
			<view @tap="tapReportPet(props.pet.id)" class="report">
				<view class="iconfont ">
					&#xe8f1;
				</view>
				<text>举报</text>
			</view>
			<!-- 宠物图片 轮播图 -->
			<uv-swiper :list="props.pic" radius="20rpx" imgMode="scaleToFill" height="300" :indicator="true"
				indicatorMode="dot" circular></uv-swiper>
			<!-- 宠物信息 -->
			<view class="pet_title">
				<text class="pet_nick">{{props.pet.petNick}}</text>
				<view class="iconfont boy" v-if="props.pet.petSex == '弟弟'">
					&#xe7a0;
				</view>
				<view class="iconfont girt" v-if="props.pet.petSex == '妹妹'">
					&#xe7a1;
				</view>
				<text class="address">{{props.pet.petAddress}}</text>
			</view>
			<view class="pet_feature">
				<text>{{props.pet.petVariety}}</text>
				<text>{{props.pet.petAge}}</text>
				<text v-if="props.pet.petStatus=='找对象'">{{props.pet.experience}}</text>
				<text>{{props.pet.petStatus}}</text>
			</view>
			<view class="pet_owner" v-if="props.pet.petOwner">
				{{props.pet.petOwner}}
			</view>
			<view class="hr"></view>
			<!-- 评论区 -->
			<view class="appraise_container">
				<view class="a_title">
					共 {{props.petComment?.count}} 条品论
				</view>
				<!-- 输入框 -->
				<view class="a_input">
					<input class="ipt" type="text" placeholder="说点什么吧..." @tap="$emit('handleRootComment')"
						disabled="false" />
				</view>
				<!-- 评论区列表 -->
				<view :id="'p'+item.id" :style="{backgroundColor:item.id==props.goId?'#eee':''}"
					class="comment_container" v-for="(item,index) in props.petComment?.comments" :key="item.id">
					<view class="box_left" @tap="gotoUserHome(item.userId)">
						<image :src="item.avatar" mode=""></image>
					</view>
					<view class="box_right">
						<view class="box_right_top">
							<view class="user_name">
								{{item.nickName}}
								<text v-if="item.nickName==userStore.profile.nickname"
									style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">
									我
								</text>
								<!-- 举报按钮 -->
								<span @tap="tapReportComment(item.id)" class="iconfont" style="margin-left: 20rpx;">&#xe76b;</span>
							</view>

							<view class="user_say"
								@tap="$emit('handleOtherComment',{rootId:item.id, parentId:item.userId, nickName:item.nickName,level:1})">
								<text class="say">{{item.content}}</text>
								<text class="t">{{getTimer(item.createTime)}}</text>
								<text
									class="t">{{props.pet?.petAddress.substring(0,props.pet?.petAddress.indexOf('·'))}}</text>
								<text class="t" style="color: lightskyblue;">回复</text>
							</view>
						</view>

						<view :id="'p'+childItem.id" :style="{backgroundColor:childItem.id==props.goId?'#eee':''}"
							class="child_comment" v-for="(childItem,childIndex) in item.child" :key="childItem.id">
							<view class="box_left" @tap="gotoUserHome(childItem.userId)">
								<image :src="childItem.avatar" mode=""></image>
							</view>
							<view class="box_right">
								<view class="user_name">
									<text> {{childItem.nickName}}&nbsp;
										<text v-if="childItem.replyUserName==userStore.profile.nickname"
											style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">我</text>
									</text>

									<text v-show="childItem.level == 2">回复&nbsp;'{{childItem.replyUserName}}'
										<text v-if="childItem.replyUserName==userStore.profile.nickname"
											style="padding:2rpx; background-color:#ccc;border-radius: 4rpx;">我</text>
									</text>
									<!-- 举报按钮 -->
									<span @tap="tapReportComment(childItem.id)" class="iconfont" style="margin-left: 20rpx;">&#xe76b;</span>
								</view>
								<!--  -->
								<view class="user_say"
									@tap="$emit('handleOtherComment',{rootId:item.id, parentId:childItem.userId, nickName:childItem.nickName,level:2})">
									<text class="say">{{childItem.content}}</text>
									<text class="t">{{getTimer(childItem.createTime)}}</text>
									<text
										class="t">{{props.pet?.petAddress.substring(0,props.pet?.petAddress.indexOf('·'))}}</text>
									<text class="t" style="color: lightskyblue;">回复</text>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="hint">
					暂时没有更多了
				</view>
			</view>
		</view>
	</scroll-view>
</template>

<style lang="scss" scoped>
	// 宠物卡片
	.box-container {
		position: relative;
		width: 100%;
		height: 100%;
		// overflow: scroll;

		// &::-webkit-scrollbar {
		// 	width: 0;
		// 	height: 0;
		// }
	}

	.detail_container {
		position: relative;
		width: 100%;
		background-color: #f9f9f9;

		.report {
			display: flex;
			align-items: center;
			position: absolute;
			left: 30rpx;
			top: 30rpx;
			padding: 10rpx 30rpx;
			border-radius: 40rpx;
			border: 2rpx #fff solid;
			background-color: rgba(0, 0, 0, 0.2);
			font-size: 24rpx;
			font-weight: 400;
			color: #f9f9f9;
			z-index: 3;
			transform: scale(.8);
		}

		.pet_title {
			display: flex;
			align-items: center;
			margin-top: 20rpx;

			.pet_nick {
				font-size: 32rpx;
				font-weight: 700;
			}

			.iconfont {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 32rpx;
				height: 32rpx;
				margin: 0 20rpx;
				font-size: 16rpx;
				border-radius: 50%;
				color: #fff;
			}

			.boy {
				background-color: #1daaf8;
			}

			.girt {
				background-color: #ef6da0;
			}

			.address {
				color: #666;
				font-size: 28rpx;
			}
		}

		.pet_feature {
			display: flex;
			align-items: center;
			margin-top: 20rpx;

			text {
				margin-left: 4rpx;
				margin-right: 10rpx;
				display: flex;
				align-items: center;
				padding: 10rpx 20rpx;
				border-radius: 60rpx;
				font-size: 20rpx;
				font-weight: 700;
				background: -webkit-linear-gradient(left, #e9ff79, #fcf23f);
				box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 4px 2px;
				// rgba(0, 0, 0, 0.05) 1px 0px 4px 1px;

				&:last-child {
					background: -webkit-linear-gradient(left, #b6febf, #d9ffb4);
				}
			}
		}

		.pet_owner {
			margin-top: 20rpx;
			padding: 24rpx;
			background-color: #f0f0f0;
			border-radius: 10rpx;

		}

		.hr {
			margin: 20rpx 0;
			height: 2rpx;
			background-color: #f0f0f0;
		}

		.appraise_container {
			.a_title {}

			.a_input {
				margin-top: 20rpx;

				.ipt {
					position: relative;
					padding: 0 0 0 60rpx;
					border-radius: 30rpx;
					height: 60rpx;
					line-height: 60rpx;
					background-color: #f0f0f0;

					&::before {
						position: absolute;
						left: 30rpx;
						font-family: 'iconfont';
						content: '\e621';
					}
				}
			}

			.comment_container {
				display: flex;
				margin-top: 30rpx;


				.box_left {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;

					background-size: 80rpx 80rpx;

					image {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;

					}
				}

				.box_right {
					flex: 1;
					margin-left: 20rpx;


					.box_right_top {
						margin-bottom: 20rpx;

						.user_name {
							font-size: 24rpx;
							color: #666;
						}

						.user_say {
							width: 100%;
							margin-top: 20rpx;

							.t {
								margin-left: 10rpx;
								font-size: 20rpx;
								color: #999;
							}
						}
					}

					.child_comment {
						display: flex;

						padding: 10rpx 0 10rpx 10rpx;
						margin-bottom: 10rpx;

						.box_left {
							width: 60rpx;
							height: 60rpx;
							border-radius: 50%;

							background-size: 60rpx 60rpx;

							image {
								width: 60rpx;
								height: 60rpx;
								border-radius: 50%;
							}
						}

						.box_right {
							border-bottom: 0 !important;


							.user_name {
								font-size: 24rpx;
								color: #666;
							}

							.user_say {
								margin-top: 10rpx;

								.t {
									margin-left: 10rpx;
									font-size: 20rpx;
									color: #999;
								}
							}
						}
					}

				}
			}

			.hint {
				margin: 60rpx;
				padding-bottom: 30rpx;
				text-align: center;
				color: #999;
			}
		}
	}
</style>