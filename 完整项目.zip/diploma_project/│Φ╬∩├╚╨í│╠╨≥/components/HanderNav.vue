<script setup>
	// 获取屏幕到安全区域的距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	const props = defineProps({
		title: String
	})

	const toBack = () => {
		uni.navigateBack()
	}
</script>

<template>
	<view class="go-back" :style="{paddingTop: safeAreaInsets?.top+'px'}">
		<view class="box">
			<view class="btn-nav iconfont" @tap="toBack">
				&#xe892;
			</view>
			<view class="title">
				{{props.title}}
			</view>
		</view>
	</view>
</template>

<style lang="scss" scoped>
	.go-back {
		position: fixed;
		width: 100%;
		padding: 0 40rpx;
		background-color: #fff;
		z-index: 999;

		.box {
			height: 100rpx;
			position: relative;
			display: flex;
			align-items: center;
			font-size: 36rpx;

			.btn-nav {
				display: flex;
				font-weight: 700;
			}

			.iconfont {
				font-size: 36rpx !important;
			}

			.title {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
			}
		}
	}
</style>