<script setup>
	import {
		onMounted,
		reactive,
		ref,
		watch,
		computed,
		defineEmits
	} from 'vue';
	// 获取屏幕边界到安全区域距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	// 子组件调用父组件
	const emits = defineEmits(['handleFiltrate'])

	// 所有筛选的条件
	const condition = reactive({
		petType: '',
		address: '',
		state: '',
		sex: '',
		age: ''
	})

	/* 选择城市start */
	import {
		getAdress
	} from '@/services/common.js'
	const picker = ref()
	// 选择地址
	const loading = ref(true)
	const provinces = ref([]) //省
	const citys = ref([]) //市
	const areas = ref([]) //区
	const pickerValue = ref([0, 0, 0])
	const defaultValue = ref([99999, 1, 2])
	// 计算当前城市
	const addressList = computed(() => [provinces.value, citys.value]);
	// 省市区
	const getData = async () => {
		// console.log("调用了getdata")
		const data = await getAdress()
		// console.log('获取的数据：', data);
		provinces.value = data.sort((left, right) => (Number(left.code) > Number(right
			.code) ? 1 : -1));
		provinces.value.unshift({
			id: "99999",
			name: "全国",
			code: "99999",
			parentId: "999999",
			children: ''
		})
		// console.log(provinces.value)
		setTimeout(() => {
			loading.value = false
		}, 200)
	}
	const change = (e) => {
		if (loading.value) return;
		const {
			columnIndex,
			index,
			indexs
		} = e
		// 改变了省
		if (columnIndex === 0) {
			citys.value = provinces.value[index]?.children || []
			areas.value = citys.value[0]?.children || []
			picker.setIndexs([index, 0, 0], true)
		} else if (columnIndex === 1) {
			areas.value = citys.value[index]?.children || []
			picker.setIndexs(indexs, true)
		}
	}
	// 确定选择的地区
	const confirm = (e) => {
		// console.log('确认选择的地区：', e);
		defaultValue.value = e.indexs
		if (e.value[0].name == '全国') {
			condition.address = ''
		} else {
			condition.address = e.value[0].name + '·' + e.value[1].name
		}
		console.log(condition.address)
	}
	/* 选择地址end */


	/* 	筛选模块 start */
	import {
		getCondition
	} from '@/services/homeAPI.js'
	const popup = ref()
	// 筛选Condition
	const stateList = ref()
	const sexList = ref()
	const ageList = ref()
	// 获取初始化筛选选项
	const initCondition = async () => {
		const res = await getCondition()
		stateList.value = res.data.state
		sexList.value = res.data.sex
		ageList.value = res.data.age
	}
	// 计算首页筛选个数
	const screenConut = ref(0)
	watch(
		() => condition,
		(newVal, oldVal) => {
			// console.log('condition发生变化', newVal, oldVal);
			screenConut.value = 0
			if (newVal.state != '') {
				screenConut.value++
			}
			if (newVal.sex != '') {
				screenConut.value++
			}
			if (newVal.age != '') {
				screenConut.value++
			}
		}, {
			deep: true
		}
	)
	// 重置筛选
	const resetPopup = () => {
		condition.state = ''
		condition.age = ''
		condition.sex = ''
	}
	// 筛选确定时
	const filtrateConfirm = (e) => {
		// 这里调用筛选请求
		popup.value.close()
		emits('handleFiltrate', condition)
	}
	/* 打开筛选 模块 end */

	// 筛选变化时发起新的请求
	watch(() => condition.petType,
		(newVal, oldVal) => {
			emits('handleFiltrate', condition)
		}, {
			deep: true
		})
	watch(() => condition.address,
		(newVal, oldVal) => {
			emits('handleFiltrate', condition)
		}, {
			deep: true
		})

	onMounted(() => {
		// 初始化选择地址模块
		getData()
		// 初始化筛选模块
		initCondition()
	})
</script>

<template>
	<view class="navbar" :style="{ paddingTop: safeAreaInsets?.top  + 'px' }">
		<!-- 头部导航 猫狗类型筛选 -->
		<view class="nav_tabs">
			<view class="tab" :class="condition.petType==''? 'active':''" @click="condition.petType=''">
				全部
			</view>
			<view class="tab" :class="condition.petType==1? 'active':''" @click="condition.petType=1">
				喵星人
			</view>
			<view class="tab" :class="condition.petType==2? 'active':''" @click="condition.petType=2">
				汪星人
			</view>
		</view>

		<!-- 其他条件选择模块 -->
		<view class="conditions">
			<view @click="picker.open()" class="c_item select_one">{{condition.address==''? '全国':condition.address}}
			</view>
			<view @click="popup.open()" class="c_item select_two">筛选{{screenConut!=0? '('+screenConut+')':''}}</view>
		</view>

		<!-- 选择省市 -->
		<uv-picker ref="picker" :columns="addressList" :loading="loading" keyName="name" @change="change"
			@confirm="confirm">
		</uv-picker>

		<!-- 筛选 -->
		<uv-popup ref="popup" @change="changePopup" duration="100">
			<view class="pop_up">
				<!-- 状态筛选  Start-->
				<view class="title">
					状态
				</view>
				<view class="content">
					<view class="label" :class="item == condition.state?'avtive':''" v-for="(item, index) in stateList"
						:key="item" @click="condition.state==item? condition.state='':condition.state = item">
						{{item}}
					</view>
				</view>
				<!-- end -->
				<!-- 性别筛选  Start-->
				<view class="title">
					性别
				</view>
				<view class="content">
					<view class="label" :class="item == condition.sex?'avtive':''" v-for="(item, index) in sexList"
						:key="item" @click="condition.sex==item? condition.sex='':condition.sex = item">
						{{item}}
					</view>
				</view>
				<!-- end -->
				<!-- 年龄筛选 start -->
				<view class="title">
					年龄
				</view>
				<view class="content">
					<view class="label" :class="item == condition.age?'avtive':''" v-for="(item, index) in ageList"
						:key="item" @click="condition.age==item?condition.age='':condition.age=item">
						{{item}}
					</view>
				</view>
				<view class="pop_up_footer" @click="reset">
					<view class="pop_nav reset" @click="resetPopup()">
						重置
					</view>
					<view class="pop_nav confirm" @click="filtrateConfirm()">
						确定
					</view>
				</view>
				<!-- end -->
			</view>
		</uv-popup>

	</view>
</template>



<style lang="scss" scoped>
	@import "@/static/fonts/iconfont.css";
	.navbar {
		// 头部导航烂
		.nav_tabs {
			display: flex;
			padding: 20rpx 30rpx;
			font-size: 32rpx;
			font-weight: 700;
			align-items: center;

			.tab {
				margin-right: 60rpx;
			}

			.active {
				position: relative;
				font-size: 42rpx;

				&::after {
					position: absolute;
					bottom: -16rpx;
					left: 50%;
					transform: translateX(-50%);
					content: '';
					width: 30rpx;
					height: 4px;
					border-radius: 2rpx;
					background-color: black;
				}
			}
		}

		// 添加筛选模块
		.conditions {
			display: flex;
			padding: 40rpx 30rpx;
			font-size: 28rpx;

			.c_item {
				position: relative;
				flex: 1;
				margin-right: 20rpx;
				padding: 0 30rpx;
				height: 60rpx;
				line-height: 60rpx;
				border-radius: 30rpx;
				background-color: #fff;
				font-size: 28rpx;
				color: #000;

				&:last-child {
					margin-right: 0rpx;
				}

				&::after {
					content: "";
					position: absolute;
					top: 50%;
					right: 30rpx;
					transform: translateY(-50%);
					width: 0;
					height: 0;
					border-left: 10rpx solid transparent;
					border-right: 10rpx solid transparent;
					border-top: 10rpx solid #000;

				}
			}
		}


		// 弹窗
		.pop_up {
			width: 750rpx;
			padding: 30rpx 30rpx 0;
			box-sizing: border-box;
			font-size: 24rpx;

			.title {
				padding: 20rpx 0;
			}

			.content {
				display: flex;
				flex-wrap: wrap;

				.label {
					display: flex;
					justify-content: center;
					align-items: center;
					margin-right: 45rpx;
					margin-bottom: 20rpx;
					width: 200rpx;
					height: 60rpx;
					border-radius: 30rpx;
					border: 2rpx solid #888;
					color: #888;
					box-sizing: border-box;

					&:nth-child(3n) {
						margin-right: 0;
					}
				}

				.avtive {
					position: relative;
					border: 2rpx solid #000;
					color: #000;

					&::after {
						position: absolute;
						right: -4rpx;
						top: -4rpx;
						border-radius: 50%;
						background-color: #fff;
						font-family: "iconfont";
						content: '\e84c';
						font-size: 24rpx;
					}
				}
			}

			.pop_up_footer {
				display: flex;
				align-items: center;
				height: 100rpx;

				.pop_nav {
					display: flex;
					justify-content: center;
					align-items: center;
					height: 60rpx;
					border-radius: 30rpx;
				}

				.reset {
					flex: 2;
					background-color: #ccc;
				}

				.confirm {
					flex: 3;
					margin-left: 40rpx;
					background-color: #000;
					color: #fff;
					box-sizing: border-box;
				}
			}

		}
	}
</style>