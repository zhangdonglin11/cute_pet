<script setup>
	import PetContent from '@/components/PetContent.vue'
	import PetLikeButton from '@/components/PetLikeButton.vue'
	import {
		getPet,
		likePet,
		savePetComment
	} from '@/services/mine.js'

	import {
		onMounted,
		ref,
		getCurrentInstance
	} from 'vue';

	import {
		useUserStore
	} from '@/stores/useUserStore.js'
	const userSore = useUserStore()

	// 接收页面参数 	// 获取评论id跳转目标位置
	const query = defineProps({
		commentId: Number
	})
	const goId = ref(0)

	// 获取宠物信息
	const petObj = ref()
	const isShow = ref(false)

	// 接收 宠物卡片 的数据 我的宠物和的收藏
	const instance = getCurrentInstance();
	const eventChannel = instance.ctx.getOpenerEventChannel();
	eventChannel.on('sendPetHome', data => {
		isShow.value = true
		petObj.value = data
		// 更新页面信息
		infoPet(petObj.value.pet.id)
		console.log(query.commentId)
		goId.value=query.commentId
	})
	
	
	// 获取宠物信息
	const infoPet = async (pid) => {
		const res = await getPet(pid)
		console.log(res);
		if (res.code == 1) {
			petObj.value = res.data
			isShow.value = true
		} else {
			uni.navigateBack()
			uni.showToast({
				icon: "none",
				title: "宠物已删除"
			})
		}
	}


	// 跳转修改页 并且传值
	const gotoEditorPet = () => {
		uni.navigateTo({
			url: '/pages/mine/PetEditor/PetEditor',
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendPet', {
					pet: petObj.value.pet,
					picList: petObj.value.pic
				})
			}
		})
	}
	// 返回更新
	uni.$once("updatePet",()=>{
		infoPet(petObj.value.pet.id)
	})


	// 点赞收藏
	const tapLike = async (pid) => {
		const result = await likePet(pid)
		infoPet(pid)
	}
	// 评论
	const commentPopup = ref()
	const iptText = ref('说点什么吧...')
	const formData = ref({
		content: '', //品论内容
		petId: 1, // 宠物id
		level: 0, // 品论层级 0根 1回复0 2回复1\2
		parentId: '', //回复目标的id，没有则null
		rootId: '' // 根品论id 
	})
	// 根评论方法
	const rootComment = () => {
		commentPopup.value.open()
		iptText.value = '说点什么吧...';
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.petId = petObj.value.pet.id
		formData.value.level = 0;
		formData.value.parentId = '';
		formData.value.rootId = ''
	}
	// 其他评论
	const OtherComment = (val) => {
		commentPopup.value.open()
		iptText.value = '回复 ' + val.nickName;
		// 根评论数据格式化
		formData.value.content = "";
		formData.value.petId = petObj.value.pet.id
		formData.value.level = val.level;
		formData.value.parentId = val.parentId;
		formData.value.rootId = val.rootId
		console.log(val.level)
	}

	// 提交评论
	const SubmintPetComment = async (val) => {
		if (val.content == '') {
			return
		}
		console.log(val)
		const res = await savePetComment(val);
		uni.showToast({
			icon: 'none',
			title: res.message
		})
		// 更新页面信息
		infoPet(petObj.value.pet.id)
		// 关闭评论输入框
		commentPopup.value.close()
	}
	// 相认识他按钮功能
	import {
		getChat
	} from "@/services/informAPI.js"

	const myChatList = ref(0)
	const tapMakingFriends = async (anotherId) => {
		const result = await getChat(anotherId)
		myChatList.value = result.data
		console.log(result)
		if (result.code == 1) {
			// 去对话页面
			uni.navigateTo({
				url: '/pages/inform/Dialogue/Dialogue',
				success: function(res) {
					// 通过eventChannel向被打开页面传送数据
					res.eventChannel.emit('sendDialogue', myChatList.value)
				},
				animationDuration: 1000
			})
			return
		}
		uni.showToast({
			icon: "none",
			title: result.message
		})
	}
</script>

<template>
	<view class="pet-details-container">
		<view class="main">
			<PetContent v-if="isShow" :pet="petObj.pet" :pic="petObj.pic" :petComment="petObj?.petComment"
				@handleRootComment="rootComment()" @handleOtherComment="OtherComment" :goId="goId"/>
		</view>

		<view class="right-button">
			<PetLikeButton v-if="isShow" @hendleLike="tapLike(petObj.pet.id)" @hendleComment="rootComment()"
				:petLike="petObj.petLike" :commentCount="petObj?.petComment?.count"  />
		</view>

		<!-- 评论弹出层 -->
		<uv-popup ref="commentPopup" mode="bottom" bgColor="none" :overlayStyle="{background: 'rgba(0,0,0,0)'}"
			:safeAreaInsetBottom="false">
			<view class="popup-box">
				<input class="ipt" type="text" :placeholder="iptText" maxlength="140" v-model.trim="formData.content"
					@confirm="SubmintPetComment(formData)" />
			</view>
		</uv-popup>

		<view class="footer">
			<template v-if="petObj?.pet?.userId == userSore.profile.id">
				<view class="btn backColor iconfont">
					&#xe878; &nbsp;推荐朋友
				</view>
				<view class="btn yelowColor iconfont" @tap="gotoEditorPet">
					&#xe621; &nbsp;去编辑
				</view>
			</template>
			<template v-else>
				<view class="btn backColor iconfont">
					&#xe878; &nbsp;推荐朋友
				</view>
				<view class="btn yelowColor iconfont" @tap="tapMakingFriends(petObj?.pet?.userId)">
					&#xe8a5; &nbsp;想认识TA
				</view>
			</template>
		</view>
	</view>
</template>



<style lang="scss" scoped>
	.pet-details-container {
		display: flex;
		flex-direction: column;
		padding: 40rpx 30rpx 120rpx;
		width: 100%;
		height: 100%;
		box-sizing: border-box;

		.main {
			flex: 1;
			padding: 30rpx;
			border-radius: 30rpx 30rpx 0 0;
			box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
				rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;
			background-color: #fff;
			overflow-y: hidden;
		}

		.right-button {
			position: fixed;
			right: 25rpx;
			top: 50%;
		}

		.popup-box {
			height: 120rpx;
			padding: 10rpx 60rpx 0;
			box-sizing: border-box;
			background-color: #fff;

			.ipt {
				padding: 0 30rpx;
				height: 60rpx;
				border-radius: 60rpx;
				background-color: #e0e0e0;
			}
		}

		.footer {
			display: flex;
			justify-content: space-between;
			align-items: center;
			position: fixed;
			left: 0;
			bottom: 0;
			height: 120rpx;
			width: 100%;
			padding: 0 30rpx 15rpx;
			background-color: #fff;
			box-sizing: border-box;
			box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
				rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;

			.btn {
				display: flex;
				justify-content: center;
				align-items: center;
				width: 48%;
				height: 80rpx;
				border-radius: 45rpx;
				font-size: 32rpx;
			}

			.backColor {
				background-color: #000;
				color: #fff;
			}

			.yelowColor {
				background: -webkit-linear-gradient(left, #ebff7c, #fcf239);
				color: #000;
			}
		}
	}
</style>