<script setup>
	import MyPet from '../components/MyPet.vue'
	import LikePet from '../components/LikePet.vue'
	import {
		ref
	} from 'vue';
	import {
		getProfile
	} from '@/services/mine.js'
import {
		getChat
	} from "@/services/informAPI.js"
	const profile = ref(0)
const uid = ref(null)
	const initProfile = async (uid) => {
		const result = await getProfile(uid)
		if (result.code == 1) {
			profile.value = result.data
		
		} else {
			uni.navigateBack()
			uni.showToast({
				icon: 'none',
				title: result.message
			})
		}
	}

	// 我的宠物和收藏宠物模块
	const navtodo = ref(true)
	const myPetRef = ref()
	const likePetRef = ref()
	const tapMakingFriends = async (anotherId) => {
		const result = await getChat(anotherId)
		console.log(result)
		if (result.code == 1) {
			// 去对话页面
			uni.navigateTo({
				url: '/pages/inform/Dialogue/Dialogue',
				success: function(res) {
					// 通过eventChannel向被打开页面传送数据
					res.eventChannel.emit('sendDialogue',result.data)
				},
				animationDuration: 1000
			})
			return
		}
		uni.showToast({
			icon: "none",
			title: result.message
		})
	}
	import {
		onShow,
		onLoad
	} from '@dcloudio/uni-app'
	onShow(() => {
		

	})
	onLoad((options) => {
		uid.value =options.userId
		initProfile(options.userId)
		myPetRef?.value?.infoMyPet()
		likePetRef?.value?.infoLikePet()
	})
</script>

<template>
	<view class="user-home">
		<!-- 用户信息 -->
		<view class="mine_header">
			<view class="profile-left">
				<image :src="profile?.pic"></image>
			</view>
			<view class="profile-content">
				<view class="profile-name">{{profile?.nickname}}</view>
				<view class="iconfont" :style="{color:profile?.sex == '男'? '#1daaf8;':'#ef6da0;'}"
					style="margin-top: 20rpx;">
					{{profile?.sex == '男'?'&#xe7a0;':'&#xe7a1;'}}
				</view>
			</view>
			<view class="profile-right iconfont">
			</view>
		</view>
		<!-- 主要区域 -->
		<view class="mine_main">
			<view class="mine_nav">
				<view class="nav" :class="{'active':navtodo}" @tap="navtodo = true">他的宠物</view>
				<view class="nav" :class="{'active':!navtodo}" @tap="navtodo = false">他的点赞</view>
			</view>
			<!-- 宠物卡片展示模块 -->
			<MyPet ref="myPetRef" v-if="navtodo" :uid="uid" :noAdd="true" />
			<LikePet ref="likePetRef" v-if="!navtodo" :uid="uid" />
		</view>
	</view>
	<view class="footer">
			<view class="btn backColor iconfont" @tap="tapMakingFriends(uid)">
				&#xe8a5; &nbsp;想认识TA
			</view>
	</view>
</template>


<style lang="scss">
	.user-home {
		height: 100%;
		display: flex;
		flex-direction: column;
	}

	.mine_header {
		display: flex;
		align-items: center;
		padding: 30rpx 40rpx;
		width: 100%;
		box-sizing: border-box;

		.profile-left {
			width: 160rpx;
			height: 160rpx;
			border-radius: 80rpx;
			overflow: hidden;
			background-color: red;

			image {
				width: 100%;
				height: 100%;
				background-color: chartreuse;
			}
		}

		.profile-content {
			flex: 1;
			font-weight: 700;
			padding: 0 20rpx;
			height: 120rpx;
			box-sizing: border-box;

			.profile-name {
				width: 300rpx;
				font-size: 40rpx;
				white-space: nowrap;
				/* 防止换行 */
				overflow: hidden;
				/* 隐藏超出部分 */
				text-overflow: ellipsis;
				/* 超出部分显示省略号 */

			}
		}

		.profile-right {
			padding: 0 10rpx;
			width: 170rpx;
			font-size: 20rpx;
			box-sizing: border-box;
		}
	}

	.mine_main {
		flex: 1;
		padding: 30rpx;
		border-radius: 40rpx 40rpx 0 0;
		box-sizing: border-box;
		background-color: #ffffff;
		box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
			rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;


		.message {}

		.mine_nav {
			padding: 30rpx 0;
			display: flex;
			align-items: center;
			font-size: 36rpx;


			.nav {
				margin-right: 40rpx;
			}

			.active {
				font-size: 40rpx;
				font-weight: 700;
				border-bottom: 2px solid #faf442;
				box-sizing: border-box;
			}
		}

		// 宠物主页
		.pet_home_content {
			.add_btn {
				margin-top: 40rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				height: 100rpx;
				border-radius: 60rpx;
				background-color: #000000;
				color: #ffffff;
			}
		}

		// 点赞
		.my_like_content {
			width: 100%;
			box-sizing: border-box;

			.pet_item {
				float: left;
				position: relative;
				float: left;
				margin-top: 30rpx;
				margin-right: 30rpx;
				padding: 20rpx;
				width: 330rpx;
				border-radius: 20rpx;
				box-sizing: border-box;
				box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
					rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;

				&:nth-child(-n+2) {
					margin-top: 0;
				}

				&:nth-child(even) {
					margin-right: 0;
				}

				.item_pet_prc {
					position: relative;
					width: 290rpx;
					height: 290rpx;
					box-sizing: border-box;

					image {
						border-radius: 10rpx;
					}

					.item_like {
						position: absolute;
						bottom: 10rpx;
						right: 10rpx;
						display: flex;
						justify-content: center;
						align-items: center;
						padding: 12rpx 20rpx;
						font-size: 20rpx;
						border-radius: 44rpx;
						background-color: rgba(0, 0, 0, 0.2);
						transform: scale(.8);

						.iconfont {}

						text {
							margin-left: 10rpx;
						}
					}

				}

				.item_pet_name {
					margin-top: 20rpx;


				}
			}
		}
	}
	
	.footer {
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: fixed;
		left: 0;
		bottom: 30rpx;
		height: 160rpx;
		width: 100%;
		padding: 0 30rpx 15rpx;
		background-color: #fff;
		box-sizing: border-box;
		box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
			rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;
	
		.btn {
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			height: 80rpx;
			border-radius: 45rpx;
			font-size: 32rpx;
		}
	
		.backColor {
			background-color: #000;
			color: #fff;
		}
	
		.yelowColor {
			background: -webkit-linear-gradient(left, #ebff7c, #fcf239);
			color: #000;
		}
		}
</style>