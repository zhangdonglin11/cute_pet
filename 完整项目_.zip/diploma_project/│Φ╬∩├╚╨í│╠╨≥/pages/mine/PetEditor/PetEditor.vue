<script setup>
	import HanderNav from '@/components/HanderNav.vue'
	import {
		ref,
		computed,
		onMounted,
		getCurrentInstance,
		watch
	} from 'vue';
	import {
		onLoad
	} from '@dcloudio/uni-app'
	import {
		getPetDraft,
		savePetDraft,
		savePetPic,
		savePet,
		deletePet
	} from '@/services/mine.js'
	import {
		changeImgType
	} from '@/services/common.js'
	// 获取屏幕到安全区域的距离
	const {
		safeAreaInsets
	} = uni.getSystemInfoSync();

	// 上传的表单
	const petForm = ref({
		id: null, // 宠物id
		petType: null,
		petVariety: null, //宠物品种
		petNick: null, //宠物昵称
		petSex: '弟弟', //宠物性别
		petAge: null, //宠物年龄
		petAddress: null, // 宠物地址
		petStatus: null, //宠物状态
		experience: '无经验', //配种宠物经验
		petOwner: '', // 铲屎官的话
		userId: '', //  用户id
	})


	// 选择宠物类别start 
	const setPetType = (type) => {
		petForm.value.petVariety = ''
		if (query.isAdd) petForm.value.petType = type
	}

	// 选择宠物品种 stsrt
	const gotoVariety = () => {
		if(petForm.value.petType==null)return;
		uni.navigateTo({
			url: `/pages/mine/PetVariety/PetVariety?petType=${petForm.value.petType}`
		})
	}
	// 上一页返回的数据 设置宠物品种
	uni.$on('selectedData', (data) => {
		petForm.value.petVariety = data
	});
	// 选择宠物品种 end

	// 年龄选择器 start
	const pickerAge = ref() // 绑定选择器
	const columnsAge = [
		['一岁以内', '1-3岁', '3-7岁', '7岁以上']
	]
	// 年龄选择器 end

	/* 宠物现居地 
	城市三级联动选择器 
	选择城市start */
	import {
		getAdress
	} from '@/services/common.js'
	const pickerAddress = ref()
	// 选择地址
	const loading = ref(true)
	const provinces = ref([]) //省
	const citys = ref([]) //市
	const areas = ref([]) //区
	const pickerValue = ref([0, 0, 0])
	const defaultValue = ref([3442, 1, 2])
	// 计算当前城市
	const addressList = computed(() => [provinces.value, citys.value, areas.value]);
	// 省市区
	const getData = async () => {
		const data = await getAdress()
		// console.log('获取的数据：', data);
		provinces.value = data.sort((left, right) => (Number(left.code) > Number(right
			.code) ? 1 : -1));
		handlePickValueDefault()
		setTimeout(() => {
			loading.value = false
		}, 200)
	}

	const handlePickValueDefault = () => {
		// 设置省
		pickerValue.value[0] = provinces.value.findIndex(item => Number(item.id) === defaultValue.value[0]);
		// 设置市
		citys.value = provinces.value[pickerValue.value[0]]?.children || [];
		pickerValue.value[1] = citys.value.findIndex(item => Number(item.id) === defaultValue.value[1]);
		// 设置区
		areas.value = citys.value[pickerValue.value[1]]?.children || [];
		pickerValue.value[2] = areas.value.findIndex(item => Number(item.id) === defaultValue.value[2]);
		// 重置下位置
		pickerAddress.value.setIndexs([pickerValue.value[0], pickerValue.value[1], pickerValue.value[2]], true);
	}

	const change = (e) => {
		if (loading.value) return;
		const {
			columnIndex,
			index,
			indexs
		} = e
		// 改变了省
		if (columnIndex === 0) {
			citys.value = provinces.value[index]?.children || []
			areas.value = citys.value[0]?.children || []
			pickerAddress.value.setIndexs([index, 0, 0], true)
		} else if (columnIndex === 1) {
			areas.value = citys.value[index]?.children || []
			pickerAddress.value.setIndexs(indexs, true)
		}
	}
	// 确定选择的地区
	const confirm = (e) => {
		// console.log('确认选择的地区：', e);
		defaultValue.value = e.indexs

		petForm.value.petAddress = `${e.value[0].name}·${e.value[1].name}·${e.value[2].name}`
		// console.log('确认选择的地区：', e);
		uni.showToast({
			icon: 'none',
			title: `${e.value[0].name}/${e.value[1].name}/${e.value[2].name}`
		})

		// console.log(condition.address)
	}
	// 过滤地址的 · x
	const fitterAdd = (value) => {
		return value != null ? value.replace(/·/g, '') : ''
	}
	/* 选择地址end */

	/* 宠物状态选择 start */
	const pickerState = ref()
	const columnsState = [
		['找朋友', '找对象', '找代溜', '找领养']
	]
	/* 宠物状态选择 end */

	/* 宠物状态选择 start */
	const pickerExperience = ref()
	const columnsExperience = [
		['无经验', '有经验']
	]
	/* 宠物状态选择 end */

	// 添加图片
	const pathList = ref([]) //宠物照片数组
	const isOpImg = ref(false) //是否修改图片
	const optionImg = () => {
		const imgLen = pathList.value.length
		if (imgLen > 4) return;
		uni.chooseImage({
			count: 5 - imgLen, //可以选择多少张图片
			sizeType: ['original'],
			crop: {
				quality: 100, //图片质量,不填为80
				width: 400, //裁剪宽度
				height: 400, //裁剪高度
			},
			success: (res) => {
				//从相册或摄像头拿到图片临时路径及信息后进行判断
				//res.temFiles.size返回的单位为B 1KB=1024B
				if (res.tempFiles.size > 16 * 1024 * 1024) {
					uni.showToast({
						icon: 'none',
						title: "照片不能超过16M"
					})
					return
				}
				pathList.value.push(res.tempFilePaths[0])
				isOpImg.value = true;
				return
			},
		});
	}
	// 删除小图片
	const deleteimg = (i) => {
		pathList.value.splice(i, 1);
		isOpImg.value = true
	}

	// 路径传参 判断是添加还是修改
	const query = defineProps({
		isAdd: Boolean
	})



	onLoad(async () => {
		if (query.isAdd) {
			// 获取宠物草稿 保存页
			const res = await getPetDraft()
			if (res.code == 1) {
				petForm.value = res.data.pet
				// 遍历宠物的图片转为本地存储格式
				res.data.picList.map(async item => {
					const path = await changeImgType(item)
					pathList.value.push(path.tempFilePath)
				})
			}
		} else {
			// 接收宠物主页的数据 修改页
			const instance = getCurrentInstance();
			const eventChannel = instance.ctx.getOpenerEventChannel();
			eventChannel.on('sendPet', data => {
				petForm.value = data.pet
				// 遍历宠物的图片转为本地存储格式
				data.picList.map(async item => {
					const path = await changeImgType(item)
					pathList.value.push(path.tempFilePath)
				})
			})
		}
	})

	// 保存宠物草稿
	const tapSavePetDraft = async () => {
		// 保存宠物信息
		const res = await savePetDraft(petForm.value, isOpImg.value)
		// 循环上传图片
		if (isOpImg.value) {
			pathList.value.map(async item => {
				console.log(petForm.value.id)
				await savePetPic(petForm.value.id, item)
			})
		}
		uni.showToast({
			icon: 'none',
			title: res.message
		})
		if(query.isAdd)return;
		
	}
	
	const handleShowToast=(title)=>{
		uni.showToast({
			icon:'none',
			title:title
		})
	}

	// 获取实例
	const instance = getCurrentInstance();
	// 正式保存宠物
	const tapSavePet =async () => {
		if(petForm.value.petType==null)return handleShowToast('请选择宠物类型');
		if(petForm.value.petVariety==null)return handleShowToast('请选择宠物品种');
		if(petForm.value.petNick==null)return handleShowToast('宠物昵称不能为空');
		if(petForm.value.petAge==null)return handleShowToast('请选择宠物年龄');
		if(petForm.value.petAddress==null)return handleShowToast('请选择宠物地址');
		if(petForm.value.petStatus==null)return handleShowToast('请选择宠物状态');
		if(pathList.value.length==0)return handleShowToast('图片不能为空');
		// 保存宠物信息
		const result = await savePet(petForm.value, isOpImg.value)
		// 循环上传图片
		if (isOpImg.value) {
			pathList.value.map(async item => {
				console.log(petForm.value.id)
				await savePetPic(petForm.value.id, item)
			})
		}
		uni.showToast({
			icon: 'none',
			title: result.message
		})
		uni.navigateBack({
			success: function() {
				// 通过eventChannel向被打开页面传送数据
				uni.$emit('updatePet')
			}
		})

	}

	// 删除宠物
	const tapDetelePet = async (pid) => {
		const res = await deletePet(pid)
		uni.showToast({
			icon: 'none',
			title: res.message
		})
		uni.switchTab({
			url: '/pages/mine/mine'
		})
	}

	onMounted(() => {
		// 初始化城市数据
		getData()
		// 打开页面判断是修改页或添加页
	})
</script>

<template>
	<view class="petEditor_content">
		<!-- 头部导航组件 -->
		<HanderNav></HanderNav>

		<view class="head_text">
			快和新朋友认识一下吧！
		</view>

		<view class="main">
			<view class="form-box">

				选择你的宠物类别
				<!-- 猫|狗 -->
				<view class="category" :style="{opacity:query.isAdd?'':'0.7'}">
					<view @click="setPetType(1)" :class="{active_Type:petForm?.petType == 1}">
						<image src="@/static/image/mao.png"></image><text>喵喵</text>
					</view>
					<view @click="setPetType(2)" :class="{active_Type:petForm?.petType == 2}">
						<image src="@/static/image/gou.png"></image><text>修狗</text>
					</view>
				</view>
				<!-- end -->

				<!-- 宠物品种 -->
				<view class="list_item">
					<text>宠物品种</text>
					<input class="select_ipt" placeholder="请选择宠物品种" v-model="petForm.petVariety" disabled
						@click="gotoVariety()" />
				</view>
				<!-- end -->

				<!-- 宠物昵称 -->
				<view class="list_item">
					<text>宠物昵称</text>
					<input placeholder="请输入" v-model="petForm.petNick" maxlength="7" />
				</view>
				<!-- end -->

				<!-- 宠物性别 -->
				<view class="list_item">
					<text>宠物性别</text>
					<view class="pet_sex">
						<view @click="petForm.petSex = '弟弟'" :class="{active_Sex:petForm.petSex == '弟弟'}"
							class="iconfont boy">
							&#xe7a0; &nbsp;弟弟</view>
						<view @click="petForm.petSex = '妹妹'" :class="{active_Sex:petForm.petSex == '妹妹'}"
							class="iconfont girt">
							&#xe7a1; &nbsp;妹妹</view>
					</view>
				</view>
				<!-- end -->

				<!-- 宠物年龄 -->
				<view class="list_item">
					<text>宠物年龄</text>
					<view class="">
						<uv-picker ref="pickerAge" :columns="columnsAge"
							@confirm="(e)=>petForm.petAge=e.value[0]"></uv-picker>

						<input class="select_ipt" placeholder="请选择" v-model="petForm.petAge" disabled
							@click="pickerAge.open()" />
					</view>
				</view>
				<!-- end -->

				<!-- 宠物现居地 -->
				<view class="list_item uni-title ">
					<text class="">
						宠物现居地
					</text>
					<view>
						<uv-picker ref="pickerAddress" :columns="addressList" :loading="loading" keyName="name"
							@change="change" @confirm="confirm">
						</uv-picker>
						<input class="select_ipt" placeholder="请选择" :value="fitterAdd(petForm.petAddress)" disabled
							@click="pickerAddress.open()" />
					</view>
				</view>
				<!-- end -->

				<!-- 宠物状态 -->
				<view class="list_item">
					<text>宠物状态</text>
					<view class="">
						<uv-picker ref="pickerState" :columns="columnsState"
							@confirm="(e)=>petForm.petStatus=e.value[0]"></uv-picker>
						<input class="select_ipt" placeholder="请选择" v-model="petForm.petStatus" disabled
							@tap="pickerState.open()" />
					</view>
				</view>
				<!-- end -->

				<!-- ；配种经验 -->
				<view class="list_item" v-if="petForm.petStatus == '找对象'">
					<text>配种经验</text>
					<view class="">
						<uv-picker ref="pickerExperience" :columns="columnsExperience"
							@confirm="(e)=>petForm.experience=e.value[0]"></uv-picker>

						<input class="select_ipt" placeholder="请选择" v-model="petForm.experience" disabled
							@click="pickerExperience.open()" />
					</view>
				</view>
				<!-- end -->

				<!-- 宠物照片start -->
				<view class="list_item_img">
					<view class="header_title">
						<text>宠物照片</text>
						<text class="num">{{pathList?.length}}/5</text>
					</view>
					<!-- 上传多张图片模块 -->
					<view class="uploadImg">
						<view @click="deleteimg(index)" v-for="(item,index) in pathList" :key="index" class="list_img">
							<image center :src="item"></image>
						</view>
						<view class="iconfont option_img" @click="optionImg">
							&#xe8b5;
							<text>上传图片</text>
						</view>
					</view>
				</view>
				<!-- end -->

				<!-- 铲屎官的话 -->
				<view class="list_user_talk">
					<text>铲屎官的话（选填）</text>
					<textarea maxlength="100" v-model.trim="petForm.petOwner">
							<text>{{petForm.petOwner?.length}}/100</text>
					</textarea>
				</view>
				<!-- end -->
			</view>
		</view>

		<!-- 底部按钮 -->
		<view class="footer" :style="{paddingBottom: safeAreaInsets?.bottom+'rpx'}">
			<template v-if="query.isAdd">
				<view @tap="tapSavePetDraft()" class="footer-left-btn savebtn iconfont">
					&#xe881;&nbsp;存草稿
				</view>
				<view @tap="tapSavePet()" class="footer-right-btn iconfont">
					&#xe8f2;&nbsp;创建档案
				</view>
			</template>
			<template v-else>
				<view @tap="tapDetelePet(petForm.id)" class="footer-left-btn delbtn iconfont">
					&#xe765;&nbsp;删除
				</view>
				<view @tap="tapSavePet()" class="footer-right-btn iconfont">
					&#xe880;&nbsp;保存档案
				</view>
			</template>
		</view>
	</view>
</template>



<style lang="scss">
	@import "@/static/fonts/userDefined/iconfont.css";
	@import "@/static/fonts/iconfont.css";

	.petEditor_content {
		display: flex;
		flex-direction: column;
		width: 100%;
		height: 100%;
		background: -webkit-linear-gradient(left, #effafc, #e7f7ec, #fffed8);
		box-sizing: border-box;

		.head_text {
			height: 10%;
			padding: 0 30rpx;
			display: flex;
			align-items: center;
			font-size: 36rpx;
			box-sizing: border-box;
		}

		.main {
			flex: 1;
			padding: 0 30rpx;
			width: 100%;
			height: 0;
			min-height: 0;
			overflow-y: scroll;
			box-sizing: border-box;
			background-color: #fff;
			// transform: translate3d(0, 0, 0);

			// &::-webkit-scrollbar {
			// 	width: 0;
			// 	height: 0;
			// }

			.form-box {
				// transform: translate3d(0, 0, 0);
				margin: 4rpx 0 100rpx;
				padding: 30rpx 30rpx;
				border-radius: 20rpx;
				box-shadow: rgba(0, 0, 0, 0.08) 0px 0px 10px 6px;
				box-sizing: border-box;

				// 猫狗类别
				.category {
					display: flex;
					padding: 20rpx 0 0 0;

					view {
						display: flex;
						flex-direction: column;
						justify-content: center;
						align-items: center;
						width: 240rpx;
						height: 240rpx;
						border-radius: 30rpx;
						background-color: #f4f4f4;

						&:nth-child(1) {
							margin-right: 40rpx;
						}

						image {
							width: 30%;
							height: 30%;
							margin-bottom: 30rpx;
						}
					}
				}

				// 设定元素的上下内边距和下边框
				.list_item {
					display: flex;
					align-items: center;
					justify-content: space-between;
					padding: 30rpx 0;
					border-bottom: 2rpx solid #ccc;
					color: #999;

					input {
						text-align: right;
						color: #000;
						font-size: 28rpx;
					}

					// 	// input添加 > 符号 设定input字体的靠右	
					.select_ipt {
						position: relative;
						padding: 0 30rpx;


						&::after {
							font-family: "iconfont";
							/* 替换为你的字体图标库的名称 */
							content: "\e8c4";
							/* 替换为你想要显示的字体图标的 Unicode 值 */
							color: #000;
							font-size: 24rpx;
							font-weight: 700;
							position: absolute;
							top: 10rpx;
							right: 0;
						}
					}
				}


				// 性别两个按钮的样式
				.pet_sex {
					display: flex;

					.iconfont {
						padding: 16rpx 32rpx;
						border-radius: 10rpx;
						font-size: 24rpx;
					}

					.boy {
						color: #34a2e5;
					}

					.girt {
						color: #e2759f;
					}
				}

				// 上传图片模块
				.list_item_img {
					padding: 30rpx 0 20rpx;
					border-bottom: 2rpx solid #ccc;


					.header_title {
						display: flex;
						justify-content: space-between;
						align-items: center;
						padding: 20rpx 0;


						.num {
							font-size: 24rpx;
						}
					}

					// 上传多张图片模块
					.uploadImg {
						display: flex;
						flex-wrap: wrap;
						margin-top: 20rpx;

						.list_img {
							position: relative;
							margin-right: 30rpx;
							width: 140rpx;
							height: 140rpx;
							border-radius: 20rpx;
							margin-bottom: 30rpx;

							image {
								width: 100%;
								height: 100%;
								border-radius: 20rpx;
							}

							&::after {
								font-family: "iconfont";
								content: "\e763";
								position: absolute;
								top: 0;
								right: 0;
								transform: translate(30%, -30%);
								width: 30rpx;
								height: 30rpx;
								line-height: 30rpx;
								text-align: center;
								font-size: 16rpx;
								font-weight: 900;
								border-radius: 50%;
								background-color: #000;
								color: #fff;
							}

						}

						.option_img {
							margin-bottom: 30rpx;
							display: flex;
							flex-direction: column;
							justify-content: space-around;
							align-items: center;
							width: 140rpx;
							height: 140rpx;
							padding: 20rpx;
							border-radius: 20rpx;
							font-size: 48rpx;
							font-weight: 700;
							border: 4rpx solid #ccc;
							box-sizing: border-box;

							text {
								font-size: 20rpx;
								font-weight: 400;
							}
						}

						// 清除浮动样式类
						.clearfix {
							zoom: 1;

							&::after {
								content: "";
								display: table;
								// 清除浮动
								clear: both;
							}

							&::before {
								content: "";
								display: table;
							}
						}
					}

				}

				// 铲屎官的话，文本模块
				.list_user_talk {
					display: flex;
					flex-direction: column;
					padding: 30rpx 0;
					box-sizing: border-box;
					transform: translate3d(0, 0, 0); //设置3D视图解决页面变化的抖动

					textarea {
						position: relative;
						margin-top: 20rpx;
						padding: 20rpx;
						width: 100%;
						border-radius: 20rpx;
						background-color: #f4f4f4;
						box-sizing: border-box;

						text {
							position: absolute;
							bottom: 10rpx;
							right: 20rpx;
							color: #000;
							font-size: 24rpx;
						}
					}
				}
			}
		}

		.footer {
			position: fixed;
			bottom: 0;
			left: 0;
			display: flex;
			padding: 16rpx 30rpx 0rpx;
			width: 100%;
			background-color: #fff;
			box-shadow: rgba(0, 0, 0, 0.1) 0px 6px 24px 0px,
				rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;
			box-sizing: border-box;


			.footer-left-btn {
				flex: 2;
				display: flex;
				justify-content: center;
				align-items: center;
				height: 80rpx;
				margin-right: 20rpx;
				border-radius: 40rpx;

			}

			.delbtn {
				background-color: #fadbe5;
				color: #e1565d;
			}

			.savebtn {
				background-color: #e7f7ec;
				color: #000;
			}

			.footer-right-btn {
				flex: 3;
				display: flex;
				justify-content: center;
				align-items: center;
				border-radius: 40rpx;
				background-color: #000;
				color: #fff;

			}
		}
	}


	// 宠物类别选择样式
	.active_Type {
		background: -webkit-linear-gradient(left, #ebff7a, #fdf33b);
	}

	// 宠物性别选择样式
	.active_Sex {
		background-color: #f0f0f0;
	}
</style>