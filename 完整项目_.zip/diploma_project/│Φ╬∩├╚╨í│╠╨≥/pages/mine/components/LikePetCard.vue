<script setup>
	const props = defineProps({
		petObj: Object
	})

	// 传宠物信息对象去宠物主页
	const gotoPetDetail = (petObj) => {
		uni.navigateTo({
			url: `/pages/mine/PetHomePage/PetHomePage`,
			success: function(res) {
				// 通过eventChannel向被打开页面传送数据
				res.eventChannel.emit('sendPetHome', petObj)
			}
		})
	}
</script>
<template>
	<view class="pet_item" @tap="gotoPetDetail(props.petObj)">
		<view class="item_pet_prc">
			<image mode="scaleToFill" class="img" style="width: 100%;height: 100%;" :src="props.petObj.pic[0]" alt="宠物不存在" />
			<view class="item_like">
				<view class="iconfont" style="color: red;">
					&#xe887;
				</view>
				<text>{{props.petObj.petLike.count}}</text>
			</view>
		</view>
		<view class="item_pet_name">
			{{props.petObj.pet.petNick}}
		</view>
	</view>
</template>

<style lang="scss">
	.pet_item {
		position: relative;
		padding: 20rpx;
		width: 330rpx;
		border-radius: 20rpx;
		box-sizing: border-box;
		box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px;
		border: 2rpx solid #ccc;


		
		.item_pet_prc {
			position: relative;
			width: 290rpx;
			height: 290rpx;
			box-sizing: border-box;

			image {
				border-radius: 10rpx;
			}

			.item_like {
				position: absolute;
				bottom: 10rpx;
				right: 10rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				padding: 12rpx 20rpx;
				font-size: 20rpx;
				border-radius: 44rpx;
				background-color: rgba(0, 0, 0, 0.2);
				transform: scale(.8);

				.iconfont {}

				text {
					margin-left: 10rpx;
					color: #fff;
					font-size: 24rpx
				}
			}


		}

		.item_pet_name {
			margin-top: 20rpx;
		}

	}
</style>