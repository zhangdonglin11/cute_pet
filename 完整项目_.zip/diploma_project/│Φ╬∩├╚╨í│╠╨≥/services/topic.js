// 获取 话题草稿信息
export const getTopicDraft = () => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/topic/draft', {
		params: {},
		custom: {
			auth: true
		}
	})
}

// 发布 topic 话题
export const saveTopic = (topic, imageChange) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/topic/', topic, {
		params: {
			imageChange
		},
		custom: {
			auth: true
		}
	})
}

// 上传图片
// 上传 宠物图片
export const saveTopicPic = (tid, path) => {
	return uni.$uv.http.upload('/topic/pic', {
		params: {
			tid
		},
		/* 会加在url上 */
		filePath: path, // 要上传文件资源的路径。
		// 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
		custom: {
			auth: true
		}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
		name: 'files', // 文件对应的 key , 开发者在服务器端通过这个 key 可以获取到文件二进制内容
		formData: {}, // HTTP 请求中其他额外的 form data 
	})
}


// 获取单个话题的信息 
export const getTopic = (tid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/topic', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}
// 获取单个话题的信息 
export const saveViewed = (tid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/topic/viewed', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}

// 获取个人所有话题列表
export const getUserTopic = (uid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/topic/list', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}

// 获取筛选的话题列表 
export const getFiltrateTopic = (filtrate) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/topic/list', filtrate, {
		params: {},
		custom: {
			auth: true
		}
	})
}

// 评论
export const saveTopicComment = (comment) => {
	return uni.$uv.http.post('/topic/comment', comment, {
		params: {},
		custom: {
			auth: true
		}
	})
}

// 点赞
export const saveTopicLike = (tid)=>{
	return uni.$uv.http.get('/topic/like', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}

// 举报
export const getReport=(tid)=>{
	return uni.$uv.http.get('/topic/report', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}
// 删除
export const getDelTopic=(tid)=>{
	return uni.$uv.http.get('/topic/delete', {
		params: {
			tid
		},
		custom: {
			auth: true
		}
	})
}