// 我的 接口
// 获取用户个人信息
export const getProfile= (uid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/mine/profile', {
		params: {
			uid
		},
		custom: {
			auth: true
		},
	})
}
// 获取我的宠物
export const getMyPet = (uid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/mine/pet', {
		params: {
			uid
		},
		custom: {
			auth: true
		},
	})
}
// 获取喜欢的宠物
export const getLikePet = (uid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/mine/like', {
		params: {
			uid
		},
		custom: {
			auth: true
		},

	})
}

// 获取单个宠物的信息
export const getPet = (pid) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/pet', {
		params: {
			pid
		},
		custom: {
			auth: true
		}
	})
}

// 获取 宠物草稿信息
export const getPetDraft = () => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/pet/draft', {
		params: {},
		custom: {
			auth: true
		}
	})
}

// 保存 宠物草稿信息
export const savePetDraft = (pet, imageChange) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/pet/draft', pet, {
		params: {
			imageChange
		},
		custom: {
			auth: true
		}
	})
}

// 保存 宠物信息
export const savePet = (pet, imageChange) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/pet', pet, {
		params: {
			imageChange
		},
		custom: {
			auth: true
		}
	})
}


// 上传 宠物图片
export const savePetPic = (pid, path) => {
	return uni.$uv.http.upload('/pet/pic', {
		params: {
			pid
		},
		/* 会加在url上 */
		filePath: path, // 要上传文件资源的路径。
		// 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
		custom: {
			auth: true
		}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
		name: 'files', // 文件对应的 key , 开发者在服务器端通过这个 key 可以获取到文件二进制内容
		formData: {}, // HTTP 请求中其他额外的 form data 
	})
}

// 删除宠物
export const deletePet = (pid) => {
	return uni.$uv.http.get('/pet/delete', {
		params: {pid},
		custom: {
			auth: true
		}
	})
}

// 宠物点赞
export const likePet = (pid) => {
	return uni.$uv.http.get('/pet/like', {
		params: {pid},
		custom: {
			auth: true
		}
	})
}

// 宠物评论
export const savePetComment = (comment) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/pet/comment', comment, {
		params: {},
		custom: {
			auth: true
		}
	})
}
// 举报宠物
export const reportPet = (pid) => {
	return uni.$uv.http.get('/pet/reportPet', {
		params: {pid},
		custom: {
			auth: true
		}
	})
}
// 举报评论
export const reportComment = (cid) => {
	return uni.$uv.http.get('/pet/reportComment', {
		params: {cid},
		custom: {
			auth: true
		}
	})
}
// 修改用户头像
export const updateProfilePic = (path) => {
	return uni.$uv.http.upload('/mine/profile/pic', {
		params: {},
		/* 会加在url上 */
		filePath: path, // 要上传文件资源的路径。
		// 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
		custom: {
			auth: true
		}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
		name: 'mfile', // 文件对应的 key , 开发者在服务器端通过这个 key 可以获取到文件二进制内容
		formData: {}, // HTTP 请求中其他额外的 form data 
	})
}

// 修改个人信息
export const updateProfile = (fromData) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.post('/mine/profile', fromData, {
		params: {},
		custom: {
			auth: true
		}
	})
}