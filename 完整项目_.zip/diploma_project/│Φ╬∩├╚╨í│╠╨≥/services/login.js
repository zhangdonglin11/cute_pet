// 获取验证码
export const getPhoneCode = (mobile) => {
	// 基本用法，注意：post的第三个参数才为配置项
	return uni.$uv.http.get('/m_login/code', {
		params: {
			mobile
		}
	})
}

// 验证码登录	
export const loginCode = (mobile,code) => {
	// 基本用法，注意：post的第三个参数才为配置项项
	return uni.$uv.http.post('/m_login/code', {
		mobile,
		code
	},{
		// 跨域请求时是否携带凭证（cookies）仅H5支持（HBuilderX 2.6.15+）
		    withCredentials: true,
	})
}

// 密码登录	
export const login = (mobile,password) => {
	// 基本用法，注意：post的第三个参数才为配置项项
	return uni.$uv.http.post('/m_login', {
		mobile,
		password
	},{
		// 跨域请求时是否携带凭证（cookies）仅H5支持（HBuilderX 2.6.15+）
		    withCredentials: true,
	})
}