// 获取分类选中的数据
export const getCondition = () => {
	// 局部修改配置，局部配置优先级高于全局配置
	return uni.$uv.http.get('/home/condition', {
		dataType: 'json',
		// 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
		custom: {
			auth: false
		}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
	})
}

// 获取首页筛选的宠物
export const getFiltratePet = (filtrate)=>{
	// 局部修改配置，局部配置优先级高于全局配置
	return uni.$uv.http.post('/home/pet/show',filtrate, {
	    params: {}, /* 会加在url上 */
	    dataType: 'json',
	    // 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
	    custom: {auth: true}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
	   	    timeout: 10000, // H5(HBuilderX 2.9.9+)、APP(HBuilderX 2.9.9+)、微信小程序（2.10.0）、支付宝小程序
	    // 返回当前请求的task, options。请勿在此处修改options。非必填
	    getTask: (task, options) => {
	         // 相当于设置超时时间500ms
	         // setTimeout(() => {
	         //   task.abort()
	         // }, 500)
	    },
	})
}



