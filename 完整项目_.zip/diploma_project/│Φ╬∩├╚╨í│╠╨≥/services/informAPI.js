// 获取点赞数据
export const getLikeCommentData=()=>{
	return uni.$uv.http.get('/inform', {
		params: {},
		custom: {
			auth: true
		}
	})
}
// 获取评论数据

// 发起对话请求
export const getChat = (anotherId) => {
	return uni.$uv.http.get('/inform/chat', {
		params: {
			anotherId
		},
		custom: {
			auth: true
		}
	})
}
// 获取对话列表
export const getChatList = () => {
	return uni.$uv.http.get('/inform/chat/list', {
		params: {},
		custom: {
			auth: true
		}
	})
}
// 获取聊天记录
export const getChatHistory = (chatId) => {
	return uni.$uv.http.get('/inform/chat/history', {
		params: {
			chatId
		},
		custom: {
			auth: true
		}
	})
}
// 发送对话信息
export const sendChat = (chatId, content, type) => {
	return uni.$uv.http.post('/inform/chat/sand', {
		chatId,
		content,
		type
	}, {
		params: {},
		custom: {
			auth: true
		}
	})
}
// 发送图片
export const sendChatPic = (chatId, path) => {
	return uni.$uv.http.upload('/inform/chat/sandpic', {
		params: {
			chatId
		},
		/* 会加在url上 */
		filePath: path, // 要上传文件资源的路径。
		// 注：如果局部custom与全局custom有同名属性，则后面的属性会覆盖前面的属性，相当于Object.assign(全局，局部)
		custom: {
			auth: true
		}, // 可以加一些自定义参数，在拦截器等地方使用。比如这里我加了一个auth，可在拦截器里拿到，如果true就传token
		name: 'files', // 文件对应的 key , 开发者在服务器端通过这个 key 可以获取到文件二进制内容
		formData: {}, // HTTP 请求中其他额外的 form data 
	})
}

// 拉黑对方
export const blacklistChat = (chatId) => {
	return uni.$uv.http.get('/inform/chat/blacklist', {
		params: {chatId},
		custom: {
			auth: true
		}
	})
}
// 举报对方
export const reportChat = (chatId) => {
	return uni.$uv.http.get('/inform/chat/report', {
		params: {chatId},
		custom: {
			auth: true
		}
	})
}

// 删除对话
export const deleteChat = (chatId) => {
	return uni.$uv.http.get('/inform/chat/delete', {
		params: {chatId},
		custom: {
			auth: true
		}
	})
}


// return uni.$uv.http.post('/topic/comment', comment, {
// 		params: {},
// 		custom: {
// 			auth: true
// 		}
// 	})


// 点赞
// export const saveTopicLike = (tid)=>{
// 	return uni.$uv.http.get('/topic/like', {
// 		params: {
// 			tid
// 		},
// 		custom: {
// 			auth: true
// 		}
// 	})
// }