<script setup>
	import {
		ref
	} from 'vue';

	const props = defineProps({
		petLike: Object,
		commentCount: Number
	})
	
	
</script>

<template>
	<view class="pet-like-Button">
		<view class="common top" @tap="$emit('hendleLike')">
			<view class="iconfont" style="color: red;" v-if="props.petLike.isLike">
				&#xe887;
				<text class="text">{{props.petLike.count}}</text>
			</view>
			<view class="iconfont" v-else>
				&#xe886;
				<text class="text">点赞</text>
			</view>
		</view>
		<view class="common" @click="$emit('hendleComment')">
			<view class="iconfont">
				&#xe768;
				<text class="text" v-if="commentCount==0">评论</text>
				<text class="text" v-else>{{commentCount}}</text>
			</view>
		</view>
	</view>
</template>

<style lang="scss">
	.pet-like-Button {
		display: flex;
		flex-direction: column;
		padding: 0 10rpx;
		height: 200rpx;
		width: 80rpx;
		border-radius: 40rpx;
		background-color: #fff;
		box-sizing: border-box;
		overflow: hidden;
		box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px,
			rgba(0, 0, 0, 0.08) 0px 0px 10px 1px;

		.common {
			flex: 1;
			display: flex;
			justify-content: center;
			align-items: center;

		}

		.top {
			border-bottom: 1px solid #666;
		}

		.iconfont {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-size: 32rpx;
		}

		.text {
			margin-top: 8rpx;
			font-size: 20rpx;

		}
	}
</style>