package com.example.cute_pet.mapper;

import com.example.cute_pet.domain.Picture;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 22212
* @description 针对表【picture】的数据库操作Mapper
* @createDate 2024-03-11 17:24:25
* @Entity generator.domain.Picture
*/
public interface PictureMapper extends BaseMapper<Picture> {

}




