package com.example.cute_pet.mapper;

import com.example.cute_pet.domain.Chat;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 22212
* @description 针对表【chat】的数据库操作Mapper
* @createDate 2024-03-11 17:24:24
* @Entity generator.domain.Chat
*/
public interface ChatMapper extends BaseMapper<Chat> {

}




