<!-- 用户管理 -->
<script setup>
// ElConfigProvider 组件
import { ElConfigProvider } from 'element-plus';
// 引入中文包
import zhCn from 'element-plus/es/locale/lang/zh-cn';
// 更改分页文字
// zhCn.el.pagination.total = '共 `{total} 条`';
// zhCn.el.pagination.goto = '跳至';
// zhCn.el.pagination.pagesize = '条/页';
// zhCn.el.pagination.pageClassifier = '页';
import { Search, Calendar, Delete, Refresh } from '@element-plus/icons-vue'
import { onMounted, ref } from 'vue'
import { getUserList, resetUserImg, updateUser, delUserById, saveUser } from '@/api/userAPI.js'


// 获取用户列表
const tableUserData = ref([{
  id: 1,
  nickname: "测试01",
  pic: "http://localhost:8088/image/20240214c2f8c6cb-cd8b-4a2e-adf0-81f75a84c8cf.jpeg",
  sex: "女",
  phone: "13169197359",
  password: "aa123456",
  role: "ADMIN",
  status: 0,
  createTime: "2024-02-21T07:50:52.000+00:00"
}])
const searchFrom = ref({
  searchType: 1, // 查询类型 1,2,3 id/昵称/电话
  searchIpt: '', // 查询内容
})
const condition = ref({
  audit: 0, // 0/1 所有用户或者待审核用户
  current: 1, // 查询页数
  size: 7, // 查询条数
  pages: 10, //总页数
  total: 100, //总条数
})

// 初始化用户列表
const infoUserList = async (val) => {
  const result = await getUserList(val)
  tableUserData.value = result.data.userList
  condition.value.current = result.data.current
  condition.value.pages = result.data.pages
  condition.value.total = result.data.total
  console.log(result)
}

const tapSearch = () => {
  condition.value.current = 1
  infoUserList({ ...searchFrom.value, ...condition.value })
}
// 分页
const handleSizeChange = (size) => { }
const handleCurrentChange = () => {
  infoUserList({ ...searchFrom.value, ...condition.value })
}
// 处理时间 
const handleTime = (originalDateStr) => {
  const date = new Date(originalDateStr);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const formattedDateStr = `${year}-${month}-${day} ${hours}:${minutes}`;
  return formattedDateStr; // 输出 "2024-02-21-07:50"
}
// 编辑弹窗
const fromUserData = ref()
const dialogFormVisible = ref(false)
const editClick = (row) => {
  fromUserData.value = JSON.parse(row)
  dialogFormVisible.value = true
}
// 将用户的头像重置
const handelUserImage = async (id) => {
  const result = await resetUserImg(id)
  console.log(result);
  fromUserData.value = result.data
  infoUserList({ ...searchFrom.value, ...condition.value })
  ElMessage.success('以重置用户头像')
}
// 确定修改
const confirmUser = async () => {
  await updateUser(fromUserData.value)
  infoUserList({ ...searchFrom.value, ...condition.value })
  dialogFormVisible.value = false
  ElMessage.success('修改成功')
}
// 通过审核
const passUserStatus = async (row) => {
  let userdata = JSON.parse(row)
  userdata.status = 0
  await updateUser(userdata)
  ElMessage.success('操作成功')
  infoUserList({ ...searchFrom.value, ...condition.value })
}
// 删除用户
const delUser = async (id) => {
  await delUserById(id)
  infoUserList({ ...searchFrom.value, ...condition.value })
  ElMessage.success('删除成功')
}
// 添加用户
const addUserFrom = ref({
  nickname: '',
  phone: '',
  password: ''
})
const dialogAdd = ref(false)

const addUser = async () => {
  if (addUserFrom.value.nickname == '' && addUserFrom.value.phone == '' && addUserFrom.value.password == '') {
    ElMessage.error('不能为空')
    return
  }
  const result = await saveUser(addUserFrom.value)
  if (result.code == 1) {
    infoUserList({ ...searchFrom.value, ...condition.value })
    ElMessage.success('添加成功')
  }

  dialogAdd.value = false
  addUserFrom.value = {}
}

onMounted(() => {
  infoUserList({ ...searchFrom.value, ...condition.value })
})
</script>

<template>
  <div class="user-admin-box">
    <div class="box-hander flx-center" style="justify-content: left;">
      <el-input v-model.trim="searchFrom.searchIpt" placeholder="搜素 请输入" class="input-with-select">
        <template #prepend>
          <el-select v-model="searchFrom.searchType" style="width: 100px">
            <el-option label="用户id" :value="1" />
            <el-option label="昵称" :value="2" />
            <el-option label="电话" :value="3" />
          </el-select>
        </template>
        <template #append>
          <el-button @click="tapSearch" :icon="Search" />
        </template>
      </el-input>
      <div class="btn">
        <el-button @click="dialogAdd = true" type="primary">添加用户</el-button>
      </div>
    </div>
    <!-- 列表/待审核 -->
    <el-tabs v-model="condition.audit" @tab-change="infoUserList({ ...searchFrom, ...condition })" class="demo-tabs">
      <el-tab-pane label="用户列表" :name="0"></el-tab-pane>
      <el-tab-pane label="待审核" :name="1"></el-tab-pane>
    </el-tabs>
    <!-- 表格 -->
    <el-table :data="tableUserData" style="width: 100%" :border="true">
      <el-table-column label="#" type="index" width="40" />
      <el-table-column prop="id" label="用户id" width="100" />
      <el-table-column label="头像" width="60">
        <template #default="scope">
          <el-avatar shape="square" :size="40" :src="scope.row?.pic" />
        </template>
      </el-table-column>
      <el-table-column prop="nickname" label="昵称" width="120" />
      <el-table-column prop="sex" label="性别" width="60" />
      <el-table-column prop="phone" label="电话" width="120" />
      <el-table-column prop="role" label="角色" width="120" />
      <el-table-column label="时间" width="180">
        <template #default="scope">
          {{ handleTime(scope.row.createTime) }}
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="状态" width="100">
        <template #default="scope">
          <el-tag v-if="scope.row.status == 0" type="success">正常</el-tag>
          <el-tag v-if="scope.row.status == 1" type="warning">待审核</el-tag>
          <el-tag v-if="scope.row.status == 2" type="danger">禁用</el-tag>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作">
        <template #default="scope">
          <el-button type="primary" size="small" @click="editClick(JSON.stringify(scope.row))">编辑</el-button>
          <el-popconfirm @confirm="delUser(scope.row.id)" width="200" confirm-button-text="确定" cancel-button-text="取消"
            :icon="InfoFilled" icon-color="#626AEF" title="确定删除该用户？此操作会清除用户的所有信息！">
            <template #reference>
              <el-button type="danger" size="small">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="page-box">
      <el-config-provider :locale="zhCn">
        <el-pagination v-model:current-page="condition.current" v-model:page-size="condition.size"
          layout="total, prev, pager, next, jumper" :total="condition.total" @size-change="handleSizeChange"
          @current-change="handleCurrentChange" background="#409eff" />
      </el-config-provider>
    </div>
    <!-- 编辑弹窗 -->
    <el-dialog v-model="dialogFormVisible" title="编辑用户信息" width="800">
      <div class="dialog-box">
        <div class="left-box">
          <div class="flx-center">
            <span>用户昵称：</span>
            <el-input v-model.trim="fromUserData.nickname" maxlength="12" placeholder="请输入">
              <template #append>
                <el-button @click="fromUserData.nickname = '铲屎官' + Math.floor(1000 + Math.random() * 9000)"
                  :icon="Refresh" />
              </template>
            </el-input>
          </div>
          <div style="display: flex;margin-top: 20px;">
            <span>用户头像：</span>
            <div class="flx-center">
              <div><el-image style="width: 200px; height: 200px" :src="fromUserData.pic" /></div>
              <div class="flx-center"><el-button title="重置图片" @click="handelUserImage(fromUserData.id)" type="danger"
                  :icon="Delete" size="large" circle /></div>
            </div>
          </div>
        </div>

        <div class="right-box">
          <div class="flx-center">
            <span>用户性别：</span>
            <el-input v-model="fromUserData.sex" placeholder="男/女" />
          </div>
          <div class="flx-center" style="margin-top: 20px;">
            <span>用户电话：</span>
            <el-input v-model="fromUserData.phone" disabled placeholder="请输入电话号码" />
          </div>
          <div class="flx-center" style="margin-top: 20px;">
            <span>用户密码：</span>
            <el-input v-model="fromUserData.password" placeholder="6-16位字母+数字" />
          </div>
          <div class="flx-center" style="margin-top: 20px;">
            <span>用户角色：</span>
            <el-input v-model="fromUserData.role" disabled placeholder="ADMIN/USER" />
          </div>
          <div class="flx-center" style="margin-top: 20px;">
            <span>用户状态：</span>
            <div>
              <el-button @click="fromUserData.status = 0" :type="fromUserData.status == 0 ? 'success' : ''"
                size="small">正常</el-button>
              <el-button @click="fromUserData.status = 1" :type="fromUserData.status == 1 ? 'warning' : ''"
                size="small">待审核</el-button>
              <el-button @click="fromUserData.status = 2" :type="fromUserData.status == 2 ? 'danger' : ''"
                size="small">禁用</el-button>
            </div>
          </div>
          <div class="flx-center" style="margin-top: 20px;">
            <span>修改时间：</span>
            <div> {{ handleTime(fromUserData.createTime) }}</div>
          </div>
        </div>
      </div>

      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取消修改</el-button>
          <el-button type="primary" @click="confirmUser">
            确定修改
          </el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 添加用户窗口 -->
    <el-dialog v-model="dialogAdd" title="添加用户" width="600">
      <div style="padding: 20px;">
        <div class="flx-center" style="box-sizing: border-box;">
          <span style="width: 100px;">用户昵称：</span>
          <el-input v-model.trim="addUserFrom.nickname" maxlength="12" placeholder="请输入">
            <template #append>
              <el-button @click="addUserFrom.nickname = '铲屎官' + Math.floor(1000 + Math.random() * 9000)"
                :icon="Refresh" />
            </template>
          </el-input>
        </div>
        <div class="flx-center" style="margin-top: 20px;box-sizing: border-box;">
          <span style="width: 100px;">用户电话：</span>
          <el-input v-model="addUserFrom.phone" maxlength="11" placeholder="请输入电话号码" show-word-limit type="text" />
        </div>
        <div class="flx-center" style="margin-top: 20px;box-sizing: border-box;">
          <span style="width: 100px;">用户密码：</span>
          <el-input v-model="addUserFrom.password" minlength="6" maxlength="16" placeholder="密码 字母+数字 6-16位"
            show-word-limit type="text" />
        </div>
      </div>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="dialogAdd = false">取消</el-button>
          <el-button @click="addUser" type="primary">
            确定
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.user-admin-box {
  position: relative;
  height: 100%;
  padding: 20px 30px;


  .box-hander {
    .el-input {
      width: 400px;

      .el-input-group__append {
        padding: 0 20;

        .el-button {
          background-color: #409eff !important;
          color: #fff;
        }
      }
    }

    .btn {
      margin-left: 20px;
    }
  }

  .page-box {
    margin-top: 10px;
  }

  .dialog-box {
    display: flex;

    div {
      flex: 1;
    }

    .left-box {
      padding: 10px 20px;
      box-sizing: border-box;
    }

    .right-box {
      padding: 10px 20px;
      box-sizing: border-box;
    }
  }
}
</style>
