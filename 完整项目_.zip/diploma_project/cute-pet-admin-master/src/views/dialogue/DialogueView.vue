<!-- 用户管理 -->

<script setup>
// ElConfigProvider 组件
import { ElConfigProvider } from 'element-plus';
// 引入中文包
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import { Search, UserFilled } from '@element-plus/icons-vue'
import { onMounted, ref } from 'vue'
import DialogueItem from './components/DialogueItem.vue';
import { getDialogue } from '@/api/dialogueAPI';
import { forbidUser } from '../../api/userAPI';

const condition = ref({
  searchType: 1, // 查询类型 1,2,3 id/昵称/电话
  searchIpt: '', // 查询内容
  audit: 1, // null/audit 所有用户或者待审核用户
  current: 1, // 查询页数
  size: 4, // 查询条数
  pages: 10, //总页数
  total: 100, //总条数
})
const dialogueList = ref([])

const infoDialogueList = async () => {
  const result = await getDialogue(condition.value)
  if (result.code == 1) {
    console.log(result);
    dialogueList.value = result.data.chatArr
    condition.value.current = result.data.current
    condition.value.pages = result.data.pages
    condition.value.total = result.data.total
  } else {
    ElMessage.error(result.message)
  }
}

const centerDialogVisible = ref(false)
const chatItem = ref([])
const openDialogVisible = (item) => {
  centerDialogVisible.value = true
  chatItem.value = item
}

const tapForbidUser = async (uid) => {
  const result = await forbidUser(uid)
  if (result.code == 1) {
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

const handleJSON = (val) => {
  console.log(JSON.parse(val));
  return JSON.parse(val).pic
}

onMounted(() => {
  infoDialogueList()
})
</script>

<template>
  <div class="pet-view-box">
    <!-- 列表/待审核 -->
    <el-tabs v-model="condition.audit" @tab-change="infoDialogueList()">
      <el-tab-pane label="待审核" :name="1"></el-tab-pane>
    </el-tabs>
    <!-- 表格 -->
    <div class="petList-box">
      <DialogueItem @childEventDialog="openDialogVisible(item)" @childEventTopic="infoDialogueList()" :chatList="item"
        v-for="item in dialogueList" :key="item.id" />
    </div>
    <!-- 分页 -->
    <div class="page-box">
      <el-config-provider :locale="zhCn">
        <el-pagination v-model:current-page="condition.current" v-model:page-size="condition.size"
          layout="total, prev, pager, next, jumper" :total="condition.total" @current-change="infoDialogueList()"
          background="#409eff" />
      </el-config-provider>
    </div>


    <el-dialog v-model="centerDialogVisible" :title="chatItem.userName + ' 和 ' + chatItem.anotherName + ' 的聊天记录'"
      width="600" align-center>
      <div class="dialog-box scrollbar">
        <div v-for="item in chatItem.chatCommentArr" :key="item.id" style="margin-bottom: 10px;">
          <!--left消息 -->
          <div v-if="item.userId == chatItem.userId" class="dialog clearfix">
            <div class="item-left">
              <el-avatar :size="50" :src="chatItem.userPic" />
            </div>
            <div class="item-right">
              <div class="user-name">
                <span>{{ chatItem.userName }}</span>
                <el-button @click="tapForbidUser(item.userId)" title="禁用" style="margin: 0 2px;" size="small"
                  type="danger" :icon="UserFilled" circle />
              </div>
              <div class="user-dialog">
                <span v-if="item.type == 0" class="dialog-text">{{ item.content }}</span>
                <span v-if="item.type == 1" class="user-src">
                  <el-image style="width: 100px; height: 100px" :src="item.content" :zoom-rate="1.2" :max-scale="7"
                    :min-scale="0.2" :preview-src-list="[item.content]" :initial-index="0" fit="cover">
                    <template #error>
                      <div class="image-slot"
                        style="display: flex;align-items: center;justify-content: center;width: 100%;height: 100%;">
                        宠物已删除
                      </div>
                    </template>
                  </el-image>
                </span>
                <div v-if="item.type == 2" class="pet-card">
                  <el-image style="width: 100px; height: 100px" :src="handleJSON(item.content)[0]" :zoom-rate="1.2"
                    :max-scale="7" :min-scale="0.2" :preview-src-list="handleJSON(item.content)" :initial-index="0"
                    fit="cover">
                    <template #error>
                      <div class="image-slot"
                        style="display: flex;align-items: center;justify-content: center;width: 100%;height: 100%;">
                        宠物已删除
                      </div>
                    </template>
                  </el-image>
                  <div>{{ JSON.parse(item.content).pet.petNick }}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- right消息 -->
          <div v-if="item.userId == chatItem.anotherId" class="dialog clearfix">
            <div class="item-left" style="float: right;margin-left: 10px;">
              <el-avatar :size="50" :src="chatItem.anotherPic" />
            </div>
            <div class="item-right" style="float: right;text-align: right;">
              <div class="user-name">
                <el-button @click="tapForbidUser(chatItem.anotherId)" title="禁用" style="margin: 0 2px;" size="small"
                  type="danger" :icon="UserFilled" circle />
                <span>{{ chatItem.anotherName }}</span>
              </div>
              <div class="user-dialog" style="text-align: right;">
                <span v-if="item.type == 0" class="dialog-text">{{ item.content }}</span>
                <span v-if="item.type == 1" class="user-src">
                  <el-image style="width: 100px; height: 100px" :src="item.content" :zoom-rate="1.2" :max-scale="7"
                    :min-scale="0.2" :preview-src-list="['{{item.content}}']" :initial-index="0" fit="cover"> <template
                      #error>
                      <div class="image-slot"
                        style="display: flex;align-items: center;justify-content: center;width: 100%;height: 100%;">
                        宠物已删除
                      </div>
                    </template></el-image>
                </span>
                <div v-if="item.type == 2" class="pet-card">
                  <el-image style="width: 100px; height: 100px" :src="handleJSON(item.content)[0]" :zoom-rate="1.2"
                    :max-scale="7" :min-scale="0.2" :preview-src-list="handleJSON(item.content)" :initial-index="0"
                    fit="cover">
                    <template #error>
                      <div class="image-slot"
                        style="display: flex;align-items: center;justify-content: center;width: 100%;height: 100%;">
                        宠物已删除
                      </div>
                    </template>
                  </el-image>
                  <div>{{ JSON.parse(item.content).pet.petNick }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="centerDialogVisible = false">
            确定
          </el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<style lang="scss" scoped>
.pet-view-box {
  position: relative;
  height: 100%;
  padding: 20px 30px 60px;
  overflow: hidden;

  .box-header {

    .el-input {
      width: 400px;

      .el-input-group__append {
        padding: 0 20;

        .el-button {
          background-color: #409eff !important;
          color: #fff;
        }
      }
    }

    .btn {
      margin-left: 20px;
    }
  }

  .petList-box {
    display: flex;
    flex-wrap: wrap;
  }

  .page-box {
    position: absolute;
    padding-bottom: 10px;
    bottom: 0px;
    background: #fff;
  }

  .dialog-box {
    height: 500px;
    overflow-y: auto;

    .dialog {

      .dialog-text {
        max-width: 400px;
      }

      .item-left {
        float: left;
        margin-right: 10px;
      }

      .item-right {

        .user-name {
          font-size: 20px;
          margin-bottom: 10px;
        }

        .user-dialog {
          .dialog-text {
            padding: 10px;
            width: 400px;
            text-align: left;
            background-color: #e0e0e0;
            border-radius: 5px;
          }

          .user-src {
            border-radius: 10px;
            padding: 10px;
            box-shadow: rgba($color: #000000, $alpha: 0.3) 0 0 5px 0;

            .el-image {
              border-radius: 10px;
            }
          }

          .pet-card {
            display: inline-block;
            padding: 10px;
            border-radius: 5px;
            box-shadow: rgba($color: #000000, $alpha: 0.3) 0 0 5px 0;
            text-align: left;
          }
        }
      }
    }
  }
}
</style>
