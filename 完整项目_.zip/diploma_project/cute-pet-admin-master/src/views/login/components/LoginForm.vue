<template>
  <el-form ref="loginFormRef" :model="loginForm" :rules="loginRules" size="large">
    <el-form-item prop="username">
      <el-input v-model="loginForm.username" placeholder="用户名：admin ">
        <template #prefix>
          <el-icon class="el-input__icon">
            <user />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
    <el-form-item prop="password">
      <el-input v-model="loginForm.password" type="password" placeholder="密码：123456" show-password
        autocomplete="new-password">
        <template #prefix>
          <el-icon class="el-input__icon">
            <lock />
          </el-icon>
        </template>
      </el-input>
    </el-form-item>
  </el-form>
  <div class="login-btn">
    <el-button @click="resetForm" :icon="CircleClose" round size="large"> 重置 </el-button>
    <el-button @click="login" :icon="UserFilled" round size="large" type="primary">
      登录
    </el-button>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { useRouter } from "vue-router";
import { CircleClose, UserFilled } from "@element-plus/icons-vue";
import { ElForm } from "element-plus";
import { loginAPI } from "@/api/userAPI";
import { ElConfigProvider } from 'element-plus';
// import md5 from "md5";

const router = useRouter();
// const userStore = useUserStore();
// const tabsStore = useTabsStore();
// const keepAliveStore = useKeepAliveStore();

// type FormInstance = InstanceType<typeof ElForm>;
const loginFormRef = ref();
const loginRules = reactive({
  username: [{ required: true, message: "请输入用户名", trigger: "blur" }],
  password: [{ required: true, message: "请输入密码", trigger: "blur" }]
});

// const loading = ref(false);
const loginForm = reactive({
  username: "",
  password: ""
});

const login = async () => {
  if (loginForm.username == '' || loginForm.password == '') return;
  const result = await loginAPI(loginForm)
  if (result.code == 1) {
    router.push('/index');
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

const resetForm = () => {
  loginForm.username = ''
  loginForm.password = ''
};
</script>

<style scoped lang="scss">
@import "../index.scss";
</style>
