<script setup>
import { Delete, Check, UserFilled } from '@element-plus/icons-vue'
import { ElConfigProvider } from 'element-plus';
import { auditPet } from '@/api/petAPI.js'
import { forbidUser } from '@/api/userAPI.js'
import { color } from 'echarts/core';
// ElMessage.success()
// ElMessage.error()
// import { defineProps, defineEmits } from 'vue';
const prop = defineProps({
  pet: Object
})
const emit = defineEmits(['childEvent']);
// 宠物审核
const tapAuditPet = async (pid, type) => {
  const result = await auditPet(pid, type)
  if (result.code == 1) {
    emit('childEvent')
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}

// 修改用户状态
const tapForbidUser = async (uid) => {
  const result = await forbidUser(uid)
  if (result.code == 1) {
    emit('childEvent')
    ElMessage.success(result.message)
    return
  }
  ElMessage.error(result.message)
}
</script>

<template>
  <div class="pet-card-box">
    <div v-if="prop.pet.status > 2" class="tips">待审核</div>
    <div class="block text-center">
      <el-carousel height="180px" indicator-position="none">
        <el-carousel-item v-for="(item, index) in prop.pet.petPic" :key="index">
          <el-image style="width: 280px; height: 180px" :src="item" />
        </el-carousel-item>
      </el-carousel>
      <div class="details">
        <span>宠物昵称：{{ prop.pet.petNick }}</span>
        <div style="display:flex;align-items: center;">
          <!-- 性别 -->
          <span>宠物性别：</span>
          <component v-if="prop.pet.petSex == '弟弟'" class="icon" is="Female" style="color:#16a9fa;"></component>
          <component v-else class="icon" is="Male" style="color:#ff3ec9;"></component>
        </div>

        <div>
          <!-- 品种 -->
          <span>品种：</span>
          <span>{{ prop.pet.petVariety }}</span>
        </div>

        <div>
          <span>状态：</span>
          <span>{{ prop.pet.petStatus }}</span>
        </div>

        <div>
          <span>地址：</span>
          <span>{{ prop.pet.petAddress }}</span>
        </div>
      </div>
      <!-- 宠物简介 -->
      <div class="synopsis">
        {{ prop.pet.petOwner }}
      </div>
    </div>

    <!-- 审核按钮 -->
    <div class="more flx-center">
      <el-avatar :size="40" :src="prop.pet.userPic" />
      <span style="margin:0 10px 0 5px;">{{ prop.pet.userName }}</span>
      <el-button v-if="prop.pet.status > 2" @click="tapAuditPet(prop.pet.id, 1)" title="审核通过" :size="30" type="success"
        :icon="Check" circle />
      <el-button @click="tapForbidUser(prop.pet.userId)" title="禁止用户" :size="30" type="danger" :icon="UserFilled"
        circle />
      <el-button @click="tapAuditPet(prop.pet.id, 2)" title="删除宠物" :size="30" type="danger" :icon="Delete" circle />
    </div>
  </div>
</template>

<style lang="scss" scoped>
.pet-card-box {
  position: relative;
  margin-right: 10px;
  padding: 10px;
  width: 290px;
  height: 100%;
  background-color: #fff;
  box-shadow: rgba($color: #000000, $alpha: 0.1) 0 0 2px 2px;
  border-radius: 5px;
  box-sizing: border-box;
  background: #fff;
  overflow: hidden;

  .tips {
    position: absolute;
    top: 6px;
    right: -22px;
    transform: rotateZ(45deg);
    width: 80px;
    height: 25px;
    line-height: 25px;
    background-color: red;
    z-index: 99;
    text-align: center;
    font-size: 12px;
    color: #fff;
  }

  .details {
    margin-top: 3px;
    font-size: 14px;
    width: 220px;


    .icon {
      width: 16px;
      height: 16px;
      border-radius: 50%;
    }
  }

  .synopsis {
    margin-top: 3px;
    padding: 5px;
    height: 80px;
    background-color: #f6f6f6;
    font-size: 14px;
    overflow-y: auto;

  }

  .bad-reviews {
    margin-top: 5px;
    padding: 5px;
    height: 115px;
    overflow-y: auto;

    /* 滚动条整体 */
    &::-webkit-scrollbar {
      width: 3px;
      height: 3px;
    }

    /* 两个滚动条交接处 -- x轴和y轴 */
    &::-webkit-scrollbar-corner {
      background-color: transparent;
    }

    /* 滚动条滑块 */
    &::-webkit-scrollbar-thumb {
      background-color: #eee;
      border-radius: 1px;
    }

    .comment {
      height: 52px;
      margin-bottom: 2px;
      background-color: #f9f9f9;
      overflow: hidden;
      font-size: 14px;

    }
  }

  .more {
    position: absolute;
    display: flex;
    bottom: 5px;
    font-size: 18px;
  }
}
</style>
