<!-- 用户管理 -->
<script setup>
// ElConfigProvider 组件
import { ElConfigProvider } from 'element-plus';
// 引入中文包
import zhCn from 'element-plus/es/locale/lang/zh-cn';
import { Search } from '@element-plus/icons-vue'
import { onMounted, ref } from 'vue'
import PetCard from './components/PetCard.vue'
import { getPetList } from '@/api/petAPI.js'

const condition = ref({
  searchType: 1, // 查询类型 1,2,3 id/昵称/电话
  searchIpt: '', // 查询内容
  audit: 0, // null/audit 所有用户或者待审核用户
  current: 1, // 查询页数
  size: 4, // 查询条数
  pages: 10, //总页数
  total: 100, //总条数
})
const petData = ref([])
const infoPetList = async () => {
  console.log("获取宠物列表");
  const result = await getPetList(condition.value)
  if (result.code == 1) {
    petData.value = result.data.petArr
    condition.value.current = result.data.current
    condition.value.pages = result.data.pages
    condition.value.total = result.data.total
  } else {
    ElMessage.error(result.message)
  }
}
onMounted(() => {
  infoPetList()
})
</script>

<template>
  <div class="pet-view-box">
    <div class="box-hander flx-center" style="justify-content: left;">
      <el-input v-model="condition.searchIpt" placeholder="搜素 请输入" class="input-with-select">
        <template #prepend>
          <el-select v-model="condition.searchType" style="width: 100px">
            <el-option label="用户id" :value="1" />
            <el-option label="用户电话" :value="2" />
            <el-option label="宠物昵称" :value="3" />
          </el-select>
        </template>
        <template #append>
          <el-button @click="infoPetList()" :icon="Search" />
        </template>
      </el-input>
    </div>
    <!-- 列表/待审核 -->
    <el-tabs v-model="condition.audit" @tab-change="infoPetList()">
      <el-tab-pane label="宠物列表" :name="0"></el-tab-pane>
      <el-tab-pane label="待审核" :name="1"></el-tab-pane>
    </el-tabs>
    <!-- 表格 -->
    <div class="petList-box">
      <pet-card :pet="item" @child-event="infoPetList()" v-for="item in petData" :key="item.id" />
    </div>
    <!-- 分页 -->
    <div class="page-box">
      <el-config-provider :locale="zhCn">
        <el-pagination v-model:current-page="condition.current" v-model:page-size="condition.size"
          layout="total, prev, pager, next, jumper" :total="condition.total" @current-change="infoPetList()"
          background="#409eff" />
      </el-config-provider>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.pet-view-box {
  position: relative;
  height: 100%;
  padding: 20px 30px 60px;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .box-hander {

    .el-input {
      width: 400px;

      .el-input-group__append {
        padding: 0 20;

        .el-button {
          background-color: #409eff !important;
          color: #fff;
        }
      }
    }

    .btn {
      margin-left: 20px;
    }
  }

  .petList-box {
    flex: 1;
    display: flex;

  }

  .page-box {
    position: absolute;
    padding-bottom: 10px;
    bottom: 0px;
    background: #fff;
  }
}
</style>
