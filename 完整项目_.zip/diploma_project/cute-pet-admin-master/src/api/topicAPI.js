import http from '../utils/http';
// 获取宠物列表
export const getTopicList = (condition) => {
  return http.post('/admin/audit-topic', condition)
}

// 话题审核
export const auditTopic = (tid, type) => {
  return http.post('/admin/audit-topic/topic', {
    tid, type
  })
}