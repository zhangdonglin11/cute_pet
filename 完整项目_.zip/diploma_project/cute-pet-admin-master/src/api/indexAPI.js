// 把封装好的 axios 引入
//import { post, get } from '../utils/https';
import http from '../utils/http';
// 创建一个业务接口对象
export const getIndexData = (time) => {
  return http.get('/admin/index',{
    params: {
      time
    }
  })
}

