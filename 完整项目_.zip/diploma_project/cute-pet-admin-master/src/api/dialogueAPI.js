import http from '../utils/http';
// 获取对话列表
export const getDialogue = (condition) => {
  return http.post('/admin/audit-dialogue', condition)
}

// 对话审核
export const auditDialogue = (cid, type) => {
  return http.post('/admin/audit-dialogue/dialogue', {
    cid, type
  })
}